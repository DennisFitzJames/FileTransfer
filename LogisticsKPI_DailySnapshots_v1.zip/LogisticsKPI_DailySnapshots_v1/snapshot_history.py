"""Opt-in, immutable, one-per-local-day snapshot history for non-date-scoped KPI exports.

Compatible with the Shared SAP Data Hub v0.6 publication model.  Existing
transaction-style daily History code in history.py is deliberately untouched.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path

SNAPSHOT_JOBS = ("lx03", "zmm4tb020", "zsd3tr009", "zbmt")


def _capture_time(config: dict) -> dt.time:
    value = config.get("snapshots", {}).get("capture_after_local", "07:00")
    try:
        value = dt.time.fromisoformat(value)
        if value.tzinfo is not None:
            raise ValueError("Capture time must be local")
        return value
    except (TypeError, ValueError) as exc:
        raise ValueError("snapshots.capture_after_local must be HH:MM (local time)") from exc


def snapshot_enabled(config: dict, job_id: str, clock: dt.datetime | None = None) -> bool:
    """Whether this report is eligible to write today's first valid snapshot."""
    if job_id not in SNAPSHOT_JOBS:
        return False
    prefs = config.get("snapshots", {})
    if not prefs.get("enabled", False):
        return False
    if not prefs.get("jobs", {}).get(job_id, {}).get("enabled", False):
        return False
    clock = clock or dt.datetime.now().astimezone()
    return clock.time().replace(tzinfo=None) >= _capture_time(config)


def snapshot_paths(publish_root: str | Path, job_id: str, date: dt.date):
    if job_id not in SNAPSHOT_JOBS:
        raise ValueError(f"{job_id!r} is not a snapshot report")
    if not isinstance(date, dt.date) or isinstance(date, dt.datetime):
        raise TypeError("date must be datetime.date")
    folder = Path(publish_root) / "History" / job_id / f"{date.year:04}" / f"{date.month:02}"
    name = f"{job_id}_{date.isoformat()}"
    return folder / (name + ".csv"), folder / (name + ".json")


def publish_daily_snapshot(publish_root, job_id, report_date, staged_csv,
                           summary, publish_file, captured_at):
    """Publish one snapshot on first successful capture of a local calendar day.

    CSV is copied atomically; JSON is the completion marker and is written last.
    Existing snapshots are NEVER overwritten.  An incomplete pair is flagged
    rather than silently replaced. `publish_file` is Hub._publish_staged.
    """
    csv_path, json_path = snapshot_paths(publish_root, job_id, report_date)
    if csv_path.exists() and json_path.exists():
        return "already_captured"
    if csv_path.exists() or json_path.exists():
        raise RuntimeError(f"Incomplete snapshot pair: {csv_path} / {json_path}; manual review required")
    if not staged_csv.is_file():
        raise FileNotFoundError(staged_csv)
    columns = [col["name"] for col in summary["columns"]]
    hasher = hashlib.sha256()
    with staged_csv.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            hasher.update(block)
    metadata = {
        "job_id": job_id,
        "report_date": report_date.isoformat(),
        "captured_at": captured_at,
        "row_count": summary["row_count"],
        "column_count": summary["column_count"],
        "empty_result": summary["empty_result"],
        "columns": columns,
        "sha256": hasher.hexdigest(),
        "type": "daily_snapshot_first_success",
        "source": "validated_live_export",
    }
    # Temporary manifest is created in the existing run-specific staging folder.
    meta_stage = staged_csv.with_name(staged_csv.stem + "_snapshot.json")
    try:
        meta_stage.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
        publish_file(staged_csv, csv_path)
        publish_file(meta_stage, json_path)
    finally:
        meta_stage.unlink(missing_ok=True)
    return "captured"
