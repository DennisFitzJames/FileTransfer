"""Safely apply a minimal, reversible Data Hub daily snapshot extension.

Usage:
  py -3 install_snapshot_patch.py --hub-root "C:\\...\\DataHub-main" --check
  py -3 install_snapshot_patch.py --hub-root "C:\\...\\DataHub-main" --apply
  py -3 install_snapshot_patch.py --hub-root "C:\\...\\DataHub-main" --enable-report lx03
  py -3 install_snapshot_patch.py --hub-root "C:\\...\\DataHub-main" --enable-all
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import shutil
import sys
from pathlib import Path

from snapshot_history import SNAPSHOT_JOBS

IMPORT_ANCHOR = "from history import HISTORY_JOBS, history_enabled, day_paths, check_date_range\n"
INSERT_IMPORT = "from snapshot_history import snapshot_enabled, publish_daily_snapshot\n"
# This exact existing v0.6 warning line remains unchanged by the prior
# staging-folder retention hotfix; refuse to modify unknown app.py layouts.
BLOCK_ANCHOR = '''                                self.log(f"WARNING: current {jid} published to Live but History failed: {history_exc}")\n'''
INSERT_BLOCK = '''                        if snapshot_enabled(self.config, jid):
                            # Snapshot is separate from the six date-scoped history reports.
                            # Live publication remains successful if History storage is unavailable.
                            try:
                                local_clock = dt.datetime.now().astimezone()
                                snapshot_result = publish_daily_snapshot(
                                    publish_root, jid, local_clock.date(), staged_csv,
                                    processed, self._publish_staged,
                                    local_clock.isoformat(timespec="seconds"))
                                if snapshot_result == "captured":
                                    self.log(f"Daily snapshot captured for {jid}: {local_clock.date()}")
                            except Exception as snapshot_exc:
                                self.log(f"WARNING: current {jid} published to Live but daily snapshot failed: {snapshot_exc}")
'''


def updated_app(source: str):
    if INSERT_IMPORT in source and "snapshot_result = publish_daily_snapshot(" in source:
        return source, False
    if INSERT_IMPORT in source or "snapshot_result = publish_daily_snapshot(" in source:
        raise ValueError("Partial snapshot patch detected: inspect app.py before proceeding")
    if source.count(IMPORT_ANCHOR) != 1 or source.count(BLOCK_ANCHOR) != 1:
        raise ValueError("Unrecognised Data Hub app.py version; no files changed. Please share your current app.py")
    amended = source.replace(IMPORT_ANCHOR, IMPORT_ANCHOR + INSERT_IMPORT)
    amended = amended.replace(BLOCK_ANCHOR, BLOCK_ANCHOR + INSERT_BLOCK)
    compile(amended, "app.py", "exec")
    return amended, True


def updated_config(existing: dict):
    if existing.get("snapshots"):
        prefs = existing["snapshots"]
        if not isinstance(prefs, dict):
            raise ValueError("Existing snapshots settings are not a dictionary")
        return existing, False
    prefs = {
        "enabled": False,
        "capture_after_local": "07:00",
        "jobs": {jid: {"enabled": False} for jid in SNAPSHOT_JOBS},
    }
    existing["snapshots"] = prefs
    return existing, True


def replace_json_safely(file: Path, data: dict):
    temp = file.with_name(file.name + ".snapshot_tmp")
    try:
        temp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        os.replace(temp, file)
    finally:
        temp.unlink(missing_ok=True)


def install(root: Path, apply: bool):
    app = root / "app.py"
    cfg = root / "config.json"
    module = root / "snapshot_history.py"
    if not app.is_file() or not cfg.is_file():
        raise FileNotFoundError("Expected app.py and config.json in the Data Hub root")
    source = app.read_text(encoding="utf-8")
    revised, app_changed = updated_app(source)
    settings = json.loads(cfg.read_text(encoding="utf-8"))
    settings, config_changed = updated_config(settings)
    missing_job_ids = [jid for jid in SNAPSHOT_JOBS if jid not in [job["id"] for job in settings["jobs"]]]
    if missing_job_ids:
        raise ValueError(f"Data Hub is missing report jobs: {missing_job_ids}")
    package_module = Path(__file__).with_name("snapshot_history.py")
    if module.exists() and module.read_bytes() != package_module.read_bytes():
        raise ValueError("Existing snapshot_history.py differs; manual review required")
    print(f"Data Hub: {root}")
    print(f"app.py insertion required: {app_changed}")
    print(f"config.json new snapshot settings required: {config_changed}")
    print(f"snapshot_history.py copy required: {not module.exists()}")
    if not apply:
        print("CHECK ONLY: no files modified")
        return
    if not (app_changed or config_changed or not module.exists()):
        print("Already installed; no files changed")
        return
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = root / "snapshot_patch_backups" / timestamp
    backup.mkdir(parents=True, exist_ok=False)
    shutil.copy2(app, backup / "app.py")
    shutil.copy2(cfg, backup / "config.json")
    if module.exists():
        shutil.copy2(module, backup / "snapshot_history.py")
    print(f"Backups written to {backup}")
    if not module.exists():
        shutil.copy2(package_module, module)
    if app_changed:
        temp = app.with_name(app.name + ".snapshot_tmp")
        try:
            temp.write_text(revised, encoding="utf-8")
            os.replace(temp, app)
        finally:
            temp.unlink(missing_ok=True)
    if config_changed:
        replace_json_safely(cfg, settings)
    print("Patch installed. All snapshots remain DISABLED until explicitly enabled.")


def enable(root: Path, jid: str | None):
    app = root / "app.py"
    if "snapshot_result = publish_daily_snapshot(" not in app.read_text(encoding="utf-8"):
        raise ValueError("Install the patch before enabling a report")
    cfg = root / "config.json"
    settings = json.loads(cfg.read_text(encoding="utf-8"))
    prefs = settings.get("snapshots")
    if not isinstance(prefs, dict):
        raise ValueError("Snapshots are not configured")
    ids = SNAPSHOT_JOBS if jid is None else (jid,)
    for job in ids:
        if job not in SNAPSHOT_JOBS:
            raise ValueError(f"Invalid snapshot report {job!r}")
        prefs["jobs"][job]["enabled"] = True
    prefs["enabled"] = True
    backup = cfg.with_name("config.json.before_snapshot_enable")
    if not backup.exists():
        shutil.copy2(cfg, backup)
    replace_json_safely(cfg, settings)
    print("Enabled for " + ", ".join(ids) + "; restart the Data Hub controller to load configuration")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--hub-root", required=True, type=Path)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--check", action="store_true")
    group.add_argument("--apply", action="store_true")
    group.add_argument("--enable-report", choices=SNAPSHOT_JOBS)
    group.add_argument("--enable-all", action="store_true")
    args = parser.parse_args()
    try:
        if args.enable_report or args.enable_all:
            enable(args.hub_root, args.enable_report)
        else:
            install(args.hub_root, args.apply)
    except (OSError, ValueError, SyntaxError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
