import datetime as dt
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path

from install_snapshot_patch import updated_app, updated_config
from snapshot_history import SNAPSHOT_JOBS, snapshot_enabled, snapshot_paths, publish_daily_snapshot


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.staged = self.root / 'job.csv'
        self.staged.write_text('col_a,col_b\n1,2\n', encoding='utf-8')
        self.summary = {'row_count':1,'column_count':2,'empty_result':False,
                        'columns':[{'name':'col_a'},{'name':'col_b'}]}
        self.when = dt.datetime(2026, 11, 6, 10, 30)
        self.cfg = {'snapshots':{
            'enabled':True, 'capture_after_local':'07:00',
            'jobs':{job:{'enabled':True} for job in SNAPSHOT_JOBS}}}

    def tearDown(self):
        self.temp.cleanup()

    @staticmethod
    def publish(src, dest):
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name+'.test.tmp')
        shutil.copyfile(src, tmp)
        os.replace(tmp, dest)

    def test_opt_in_and_cutoff(self):
        self.assertTrue(snapshot_enabled(self.cfg, 'lx03', self.when))
        self.assertFalse(snapshot_enabled(self.cfg, 'lx03', dt.datetime(2026,11,6,6,59)))
        self.assertFalse(snapshot_enabled(self.cfg, 'lt22', self.when))
        self.cfg['snapshots']['jobs']['lx03']['enabled']=False
        self.assertFalse(snapshot_enabled(self.cfg, 'lx03', self.when))
        self.cfg['snapshots']['jobs']['lx03']['enabled']=True
        self.cfg['snapshots']['enabled']=False
        self.assertFalse(snapshot_enabled(self.cfg, 'lx03', self.when))

    def test_first_success_captures_and_ignores_later(self):
        result = publish_daily_snapshot(self.root, 'lx03', self.when.date(),
                        self.staged, self.summary, self.publish, self.when.isoformat())
        self.assertEqual(result, 'captured')
        csv, meta = snapshot_paths(self.root, 'lx03', self.when.date())
        self.assertEqual(csv.read_bytes(), self.staged.read_bytes())
        obj = json.loads(meta.read_text())
        self.assertEqual(obj['row_count'], 1)
        self.assertEqual(obj['columns'], ['col_a','col_b'])
        self.assertEqual(obj['report_date'], '2026-11-06')
        self.assertEqual(len(obj['sha256']), 64)
        self.staged.write_text('col_a,col_b\n9,9\n')
        self.assertEqual(publish_daily_snapshot(self.root,'lx03',self.when.date(),
                         self.staged,self.summary,self.publish,self.when.isoformat()), 'already_captured')
        self.assertIn('1,2', csv.read_text())

    def test_bad_partial_pair_is_not_overwritten(self):
        csv, meta = snapshot_paths(self.root, 'zbmt', self.when.date())
        csv.parent.mkdir(parents=True, exist_ok=True)
        csv.write_text('partial')
        with self.assertRaisesRegex(RuntimeError, 'Incomplete snapshot pair'):
            publish_daily_snapshot(self.root,'zbmt',self.when.date(),
                                   self.staged,self.summary,self.publish,self.when.isoformat())
        self.assertFalse(meta.exists())
        self.assertEqual(csv.read_text(), 'partial')

    def test_date_and_report_validation(self):
        with self.assertRaises(ValueError):
            snapshot_paths(self.root, 'lt22', self.when.date())
        with self.assertRaises(TypeError):
            snapshot_paths(self.root,'lx03', self.when)

    def test_unknown_time_rejected(self):
        self.cfg['snapshots']['capture_after_local'] = 'tomorrow'
        with self.assertRaises(ValueError):
            snapshot_enabled(self.cfg,'lx03',self.when)

    def test_idempotent_patch_and_config(self):
        old = ('from history import HISTORY_JOBS, history_enabled, day_paths, check_date_range\n'
            'def f():\n'
            '    if True:\n'
            '        if True:\n'
            '            if True:\n'
            '                if True:\n'
            '                    if True:\n'
            '                        try:\n'
            '                            pass\n'
            '                        except Exception as history_exc:\n'
            '                                self.log(f"WARNING: current {jid} published to Live but History failed: {history_exc}")\n')
        new, changed = updated_app(old)
        self.assertTrue(changed)
        self.assertIn('snapshot_enabled(self.config, jid)',new)
        new2, changed2 = updated_app(new)
        self.assertFalse(changed2)
        self.assertEqual(new2,new)
        with self.assertRaises(ValueError):
            updated_app('not an app')
        cfg, changed = updated_config({'jobs':[]})
        self.assertTrue(changed)
        self.assertFalse(cfg['snapshots']['enabled'])
        _, changed = updated_config(cfg)
        self.assertFalse(changed)


if __name__ == '__main__':
    unittest.main(verbosity=2)
