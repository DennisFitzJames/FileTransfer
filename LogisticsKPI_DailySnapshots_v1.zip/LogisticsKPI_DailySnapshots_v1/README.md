# Logistics KPI — Data Hub daily snapshots v1

This **opt-in** extension preserves point-in-time daily snapshots for the four Logistics KPI reports that are *not* supported by the v0.6 date-scoped transaction History engine:

| Data Hub job ID | Report | New canonical History path |
|---|---|---|
| `lx03` | LX03 bin snapshot | `History/lx03/YYYY/MM/lx03_YYYY-MM-DD.csv` |
| `zmm4tb020` | ZMM4TB020 outbound TO snapshot | `History/zmm4tb020/YYYY/MM/zmm4tb020_YYYY-MM-DD.csv` |
| `zsd3tr009` | ZSD3TR009 billing snapshot | `History/zsd3tr009/YYYY/MM/zsd3tr009_YYYY-MM-DD.csv` |
| `zbmt` | ZBMT backlog snapshot | `History/zbmt/YYYY/MM/zbmt_YYYY-MM-DD.csv` |

**Do not copy the old `KPI Migration Staging` CSVs into these production folders.** The legacy converter output is still in a different, legacy-compatible schema. Canonicalization and the Power BI cutover are separate steps.

## Behaviour and safeguards

- Uses an already-successful, validated **live SAP export**, after CSV parsing, before the controller deletes its temporary files. Does **not** start extra SAP transactions.
- Only captures the **first successful export per local calendar day after 07:00** (default). Change `snapshots.capture_after_local` in `config.json` if the warehouse needs a different cutoff. This is not guaranteed to be exactly 07:00: it is the first eligible successful export after that time.
- Publishes a canonical CSV under `History/<job>/<year>/<month>/` plus a JSON manifest containing column names, row count, local capture timestamp, and a SHA-256 checksum.
- Atomic copy per file; publishes `.json` last as the completion marker. Files are **never overwritten** once captured. An incomplete `.csv`/`.json` pair causes a warning and requires manual investigation.
- A snapshot write failure **does not mark Live SAP data as failed**; see `logs/controller.log` for warnings.
- **Disabled by default**, including all four individual reports. Report by report opt-in, then all four when tested.
- No changes to `history.py`, the existing six date-scoped transaction history reports, LINEUP, FOOT, the old `.xlsx` archive, or existing Power BI datasets.
- This v1 patch does **not** add new History counts/cards to the Data Hub dashboard; verify snapshots in File Explorer or the log.
- Designed and tested against the `SharedSAPDataHub_v0.6.zip` controller. The patcher verifies exact insertion anchors before modifying a newer/customized local version and aborts on unexpected structure.

## Install (Windows)

### 1. Back up and stop the Data Hub

1. Confirm that your historical converter v1.1 has successfully completed the original staging conversion. Keep old XLSX and staging CSV files untouched.
2. Close the Data Hub controller window. If a Windows startup task restarts it, temporarily disable that task while editing the code.
3. Extract this patch ZIP to a separate working directory, e.g. `C:\DataHub_SnapshotPatch`. **Do not extract into the existing Data Hub application directory.**
4. Open Command Prompt in the extracted folder, containing `install_snapshot_patch.py`.

Commands below use your previously shared Data Hub folder. Adjust `--hub-root` if your local folder is elsewhere.

### 2. Test compatibility without changing files

```bat
py -3 test_snapshots.py
py -3 install_snapshot_patch.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --check
```

The check should say all three changes are required (or not required if already installed). **If it says `Unrecognised Data Hub app.py version`, stop.** Share your current `app.py`; do not bypass the check or replace your entire controller with a copy of v0.6.

### 3. Apply the patch, initially disabled

```bat
py -3 install_snapshot_patch.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --apply
py -3 -m py_compile "C:\Users\EB013665\DataHub\DataHub-main\app.py"
```

The installer creates timestamped backups of **your existing** `app.py` and `config.json` in `DataHub-main\snapshot_patch_backups\`. It copies one new module, `snapshot_history.py`, and inserts a small hook into your current `app.py`; it does **not** replace the entire file or erase your previous disk-cleanup changes. It adds disabled settings to `config.json`.

### 4. Enable LX03 for a one-report pilot

```bat
py -3 install_snapshot_patch.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --enable-report lx03
```

Now start the Data Hub normally. Wait for or manually run **one fresh, successful LX03 export after the configured 07:00 cutoff**. Verify in File Explorer:

```text
W:\Departments\SAPTemplatesAndTools\Shared SAP Exports\History\lx03\2026\11\lx03_2026-11-06.csv
W:\Departments\SAPTemplatesAndTools\Shared SAP Exports\History\lx03\2026\11\lx03_2026-11-06.json
```

Those filenames are examples for **6 November 2026**; use today's local date and month when testing. Check `logs\controller.log` for `Daily snapshot captured for lx03: YYYY-MM-DD`. A second successful LX03 export on that day should **not** change either archive file's modification time. Live must keep updating normally.

**If LX03 is not already scheduled/enabled in the Data Hub,** enable its ordinary SAP job before expecting daily snapshots. The snapshot configuration does not schedule an export by itself.

### 5. Enable the other three once LX03 passes

Stop the Data Hub controller, then:

```bat
py -3 install_snapshot_patch.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --enable-all
```

Restart Data Hub. After a successful run of each report, check for `.csv` and `.json` pairs in its corresponding History folder. Existing date-based transaction History jobs remain independently controlled by `history.enabled` in `config.json`.

### 6. Rollback

Stop the controller. Restore `app.py` and `config.json` from the timestamped directory identified at installation (copy the original files back), and remove the new `snapshot_history.py` module if it wasn't present before. Keep any already-captured `History` files as read-only records; rollback need not delete them. Start the controller again. Do not replace the full controller with the old downloaded v0.6 version, because your local copy may include newer fixes.

## Important follow-up: Power BI integration

After one week of successful snapshots, the next migration stage is to **reconcile and canonicalize the legacy archive**, not simply concatenate old and new files under `History`.

For each report, establish a single authoritative historical row set for a given `SnapshotDate`. If the old staging and new daily snapshot overlap on a date, do not import both into a fact table; choose and record the provenance. Verify column mappings against sample workbooks, especially MB51, ZMM4TR093, and the older ZBMT layout. Keep the existing Power BI report on its old sources until day-level row and KPI reconciliations pass.

Optimising Power BI refresh to process only recent data is a **separate** implementation step; adding snapshots alone does not give Desktop incremental refresh.
