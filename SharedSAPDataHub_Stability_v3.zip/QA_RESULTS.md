# Read-only development test results (12 November 2026)

- Source: exact user-uploaded `DataHub_Source_Review_20261112_142139.zip`; source parser SHA256 `79e0ba5ea14d83fadb980e4fe3c518cfd83041b38686fb98dd65949b3e7d49bb`.
- Report regression: 17/17 original 20–21 October raw report samples parse successfully; every sample matches its existing pinned CSV contract (including the 48-field ZMM4TR012 approved extension).
- Additional previously uploaded real SAP samples: 9/9 pass. TR093 623 and 767 records, TR093 1-row, LRF2 6 and 47 rows, MB51 51 rows, ZSD3TR009 182/226/236/119 rows.
- Baseline-to-patched comparison: 26/26 raw samples parsed. 24 matched *exactly* (including row values and header names). The two MB51 samples only changed names at the two established field positions to published `user`, `unl_point`; all actual values were identical.
- 10 mutated-case tests: approved aliases passed, unapproved labels and populated spacer fields failed closed.
- Full staging/contract alignment tested for MB51 (51x22), TR093 (1x23), and ZSD3TR009 (119x95).
- Installer tested: source hash check, apply with automatic backup, file integrity validation, rollback and restored original hashes.
- This verifies offline parsing and source compatibility only. Not tested: SAP GUI interactions, W: availability/permissions, missing input layouts from 12-Nov morning, schedule contention, Power BI Desktop model refresh.
