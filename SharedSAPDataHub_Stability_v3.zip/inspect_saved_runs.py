#!/usr/bin/env python3
"""Read-only Data Hub run-folder parser diagnostic. Never prints row contents."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description='Inspect recent saved raw TXT files without running SAP or publishing')
    p.add_argument('--hub-root',required=True,type=Path)
    p.add_argument('--job',default='all',help='Report job id, or all')
    p.add_argument('--limit',type=int,default=5,help='Recent raw runs per job (1..25)')
    args=p.parse_args()
    if not 1<=args.limit<=25: p.error('--limit must be 1..25')
    sys.path.insert(0,str(args.hub_root))
    try:
      from processing.parser import parse_file
    except Exception as exc:
      print(f'Cannot import installed parser: {exc}',file=sys.stderr)
      return 2
    base=args.hub_root/'runtime'/'runs'
    jobs=sorted(d for d in base.iterdir() if d.is_dir()) if base.exists() else []
    if args.job!='all':jobs=[j for j in jobs if j.name==args.job]
    if not jobs:
      print('No matching runtime/runs directories. Older failed files may have been cleared.')
      return 1
    for job in jobs:
      raws=sorted(job.glob(f'*/{job.name}.txt'),key=lambda q:q.stat().st_mtime,reverse=True)
      print(f'\n{job.name}: {len(raws)} saved raw runs, newest {min(args.limit,len(raws))}:')
      for raw in raws[:args.limit]:
        try:
          r=parse_file(raw,job.name)
          desc=f'PARSE OK: {r.row_count} records, {len(r.headers)} columns'
          contract=args.hub_root/'schema_contracts'/f'{job.name}.json'
          if contract.exists():
            wanted=json.loads(contract.read_text(encoding='utf8')).get('columns',[])
            desc+= ' | pinned schema '+('MATCH' if wanted==r.headers else 'DIFFERS (check approved aliases)')
        except Exception as exc:
          desc=f'PARSE ERROR: {exc}'
        # No private data values, only file path and summary; do not upload raws automatically.
        print('  '+str(raw)+'\n    '+desc)
    print('\nRead-only. SAP not started. No published files altered.')
    return 0
if __name__=='__main__':sys.exit(main())
