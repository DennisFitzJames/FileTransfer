# Shared SAP Data Hub — Observed-Layout Stability Update v3

**Prepared specifically for the Data Hub source collected on 12 November 2026, 14:21.** This package supersedes the *pending* parser hotfixes for the four affected reports. It is not a general SAP GUI software upgrade.

## What it does

* Replaces the scattered LRF2, TR093 and ZSD3TR009 header pre-processing logic with a **central reviewed heading registry**, applied **before** the parser identifies the report header.
* Canonicalises MB51's published `user`, `unl_point`, and `material_description` fields, including the observed `User name`, `Unloading Point`, and `Descr.` headings.
* Handles the **verified two ZMM4TR093 tab alignments**, including `Name(QNAME)` and `User` and the previously observed `Descr.` / `Stor. Bin`. It will not discard a nonempty unnamed column.
* Retains all 17 pinned CSV contracts and the existing strict publishing guard.
* Provides `inspect_saved_runs.py`, a read-only command for parsing retained `runtime/runs/<job>/<run_id>/<job>.txt` files and reporting specific failures **without starting SAP**.
* Bundles (but does not automatically install) the earlier coverage audit and Power Query billing-date fix.

## What it does **not** do

* It cannot safely guess a new ZSD3TR009 continuation panel or missing `Expedite` if that exact TXT isn't available. Previously observed valid wrapped panels are handled.
* It does not change the DockToStock SAP GUI exporter, or diagnose its exit-code-1 failure without `logs/dock_to_stock_last_run.log`.
* It does not toggle previous-day reconciliation, change your schedules or backfill missing history.
* It does not make unknown SAP layouts automatically safe. New unverified field changes still fail without publishing.

## Installation

1. Back up `C:\Users\EB013665\DataHub\DataHub-main` and keep a copy of your PBIX. Pause the Data Hub schedule, wait for existing jobs to finish, and close the Data Hub controller **before applying**.
2. Extract the entire ZIP into `C:\DataHub_Stability_v3`, ensuring `install_stability.py` is directly in that folder.
3. In **Command Prompt**, run:

   ```bat
   cd /d "C:\DataHub_Stability_v3"
   py -3 install_stability.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --check
   ```

4. **Only if `PASS` appears**, apply:

   ```bat
   py -3 install_stability.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --apply
   ```

5. The installer prints a rollback backup path under `runtime\stability_backups\...`. Save that path. Restart the Hub with schedule still paused. Manually run **LRF2, ZMM4TR093, MB51, ZSD3TR009**, then a representative LINEUP/FOOT report. Check the Live schema and data row counts. Finally resume scheduling.

**If `--check` fails**, stop and provide its console output. The installer verifies the SHA-256 fingerprints of the exact `parser.py` and `aliases.json` you uploaded. It refuses a different or modified version. This protects later code changes.

### Rollback

Pause scheduling and close the Hub, then replace `<PRINTED_BACKUP_DIRECTORY>` with the full backup path printed during `--apply`:

```bat
py -3 install_stability.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --rollback "<PRINTED_BACKUP_DIRECTORY>"
```

Rollback refuses to overwrite any files subsequently modified by another update. The installer alters **only four parser/registry files**:

* `processing\parser.py`
* `processing\header_variants.py` (new)
* `schema_contracts\header_variants.json` (new)
* `schema_contracts\aliases.json`

It does **not** change `app.py`, `exporters/`, `config.json`, `runtime/state.json`, or any files under `Raw`, `Live`, `History` or W:.

## Inspect previous failed runs (optional, read-only)

```bat
cd /d "C:\DataHub_Stability_v3"
py -3 inspect_saved_runs.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --job zmm4tr093 --limit 5
py -3 inspect_saved_runs.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --job zsd3tr009 --limit 5
py -3 inspect_saved_runs.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --job mb51 --limit 5
```

No SAP data values are printed, just the saved file paths and parser/contract status. The files may no longer exist if runtime was manually cleaned.

## The separate tasks still required

**1. DockToStock:** inspect `logs\dock_to_stock_last_run.log`. An exporter exit code 1 happens before parsing and requires a separate SAP automation diagnosis.

**2. Picking finalisation:** your collected configuration has `history.auto_reconcile_previous_day = false`. Once the ingestion update is stable, enable previous-day reconciliation in the Data Hub History settings if operational SAP load permits, and verify that the prior day's TR093 History partition is refreshed *successfully*. This setting currently affects all enabled date-history jobs, not only TR093. Do not enable without checking workload and the date selection. A completed yesterday export is preferable to trusting the last intraday run.

**3. Gaps:** use `tools\audit_kpi_dates.py` to review the legacy/Hub handover, then backfill SAP date-driven report-days through existing History commands. Point-in-time snapshot gaps cannot be invented. Re-audit afterward.

**4. Billing Power BI:** if your `FactBillings_ZSD3TR009` query still throws on `. ..  .`, back up the PBIX and optionally replace its Advanced Editor contents with `PowerQuery\FactBillings_ZSD3TR009_DateSafe.pq` (provided from the previous recovery package). Validate in your live model before publishing.

**5. Layouts without samples:** keep the strict checks enabled. For a new failure, run the read-only saved-run diagnostic and supply that run's exact TXT or safe field-level diagnostic. Do not turn off schema validation.

## QA scope

Tested offline against the **actual uploaded 12-Nov source**, 17 original SAP report samples plus 9 later examples (26 combined tests), and 10 positive/negative mutation tests. All 17 original samples produced identical rows and schema; only MB51's two expected published field names changed to its pinned contract, without changing values. Installation and rollback were tested against the exact uploaded source. **Live SAP, W: share, current scheduled jobs and Power BI remain untested until you verify them on your PC.**
