"""Shared SAP Data Hub: deterministic parsers for the 17 supplied text-export layouts.

All original tab positions are retained until the records have been checked.
Empty unnamed SAP spacer fields are removed from the published CSV; a populated
field without a heading is rejected instead of silently dropped.
No deduplication or historical merging occurs at this stage.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import os
import re
import tempfile
from collections import Counter
from dataclasses import dataclass
from pathlib import Path


class ParseError(ValueError):
    """The SAP export is unexpected, ambiguous, truncated or malformed."""


# Require multiple identifying tokens, rather than assuming a fixed line number.
HEADERS = {
    "coois_production_lineup": ("SchedStart", "Order", "Material description"),
    "coois_production_foot": ("SchedStart", "Order", "Material description"),
    "coois_capacities_lineup": ("Oper./Act.", "TrgtProc", "RemProc"),
    "coois_capacities_foot": ("Oper./Act.", "TrgtProc", "RemProc"),
    "coois_confirmations_foot": ("Confirm.", "ActyToConf", "FinalConf"),
    "lx02": ("Material", "StorageBin", "Available stock"),
    "lx03": ("StorageBin", "Total Stock", "Pick quantity"),
    "lrf2": ("User Name", "Queue", "Document"),
    "lt22": ("TO Number", "Source Bin", "Conf.date"),
    "mb51": ("Mat. Doc.", "Pstng Date", "MvT"),
    "zmm4tr093": ("Conf. Date", "TO Number", "Number of 3S LTs"),
    "zmm4tr003": ("Storage Ty", "Nett Diffe", "Total Valu"),
    "dock_to_stock": ("Carton LT", "Putaway Date", "Dock to Stock"),
    "zmm4tb020": ("Transfer Order", "Queue", "Material Nbr"),
    "zbmt": ("Document", "Item", "PurchOrder#/Item#"),
    "zsd3tr009": ("ShPnt", "Created on", "Delv/Item"),
    "zmm4tr012": ("Profit cen", "Order/Item", "Ship Qty"),
}

# ZSD3TR009 approved semantic output contract (in published order).
ZSD3TR009_STABLE_FIELDS = ('shpnt', 'created_on', 'delv_item', 'delivery_item_category', 'sales_item', 'sales_ord_item_category', 'trans_item', 'po', 'material', 'storage_lo', 'cust_mat_no', 'net_value', 'cur', 'cust', 'cust_name', 'soff', 'sgrp', 'ind', 'route', 'country', 'description', 'batch', 'qty', 'su', 'wgt_in_kg', 'moq', 'dly_unit', 'shipperq', 'db', 'm', 'i', 'a', 'or', 'pack_dt', 'late', 'status', 'pgi_date', 'mrp', 'profit_cen', 'prodcom', 'pc_descrip', 'hs_code', 'pc_cn_desc', 'customer', 'ship_to_name', 'ctr', 'name', 'shipment_n', 'high_lv_shpmnt', 'overallsta', 'carrier_no', 'carrier_name', 'del_type', 'specprocid', 'container', 'ext_id_1', 'ext_id_2', 'haz_matl', 'vol', 'vol_un', 'grs_wt', 'wt_un', 'mdq_sales', 'customer_po_number', 'estimated_number_of_boxes', 'weight_source', 'city', 'pickable_items', 'open_picks', 'main_items', 'delivery', 'item', 'ship_to_party_address_1', 'ship_to_party_address_2', 'ship_to_party_address_3', 'telephone1', 'post_code', 'sold_to_party_address_1', 'sold_to_party_address_2', 'sold_to_party_address_3', 'telephone1__2', 'city__2', 'post_code__2', 'net_price', 'unit', 'unit__2', 'dlv_prior', 'extra_mark', 'time', 'bldg_nbr', 'transfer_agent', 'load_id', 'old_loadid', 'extrn_load', 'expedite')

NO_DATA_MARKERS = ("list contains no data", "no data selected", "no list exists")
DATE_DMY = re.compile(r"^([0-3]\d)\.([01]\d)\.(\d{4})$")
NUM = re.compile(r"^-?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?$")
SAFE_NAME = re.compile(r"[^a-z0-9]+")
# These identify measures only; leading-zero IDs, batch numbers, transfer orders,
# document numbers, warehouse bins, and business keys MUST remain text.
MEASURE_NAMES = {
    "target_qty", "conf_qty", "del_qty", "total_stock", "pick_quantity",
    "available_stock", "stock_for_putaway", "quantity", "actual_qty",
    "srce_tgt_qty", "dest_targ_qty", "dest_qty", "op_qty", "yield", "scrap",
    "net_value", "net_price", "amount_lc", "ship_qty", "total_valu",
    "total_nbr", "no_stor_un", "nbr_of_bin", "nbr_of_cou",
    "nett_diffe", "absolute_d", "min_order_qty", "on_delivery", "on_delivery_qty",
    "unrest_use_delv_qty", "trgtproc", "remproc", "tgtsetup", "remsetup",
    "teardn_sch", "rem_teardn", "actytoconf", "tgt_proc", "rem_proc",
    "dock_to_stock_min", "dock_to_gr_min", "gr_to_putaway_min",
    "no_of_3s", "no_of_4s", "number_of_3s_lts", "number_of_4s_lts",
    "total", "tot_recor", "wgt_in_kg", "moq", "qty", "value", "cost",
}


def _clean(text: str) -> str:
    return text.strip().replace("\ufeff", "")


def _slug(s: str) -> str:
    s = SAFE_NAME.sub("_", s.casefold()).strip("_")
    return s


def _columns(headings):
    names, seen = [], Counter()
    for i, heading in enumerate(headings):
        root = _slug(heading) or f"unnamed_{i+1:03}"
        seen[root] += 1
        names.append(root if seen[root] == 1 else f"{root}__{seen[root]}")
    return names


def _is_measure(name: str) -> bool:
    root = name.split("__")[0]
    return root in MEASURE_NAMES or root.startswith("trgt") or root.startswith("rem_") or root.endswith("_qty") or root.endswith("_quantity") or root.startswith("percent_") or root.startswith("pct_")


def _normalise(value: str, field: str) -> str:
    s = _clean(value)
    if not s:
        return ""
    m = DATE_DMY.fullmatch(s)
    if m:
        try:
            return dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat()
        except ValueError:
            raise ParseError(f"Invalid calendar date in {field}: {s!r}") from None
    if _is_measure(field) and NUM.fullmatch(s):
        return s.replace(",", "")
    return s


def _decode(source: bytes):
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return source.decode(enc), enc
        except UnicodeDecodeError:
            pass
    raise ParseError("Export encoding is neither valid UTF-8 nor Windows-1252")


def _get_header(lines, job_id):
    markers = HEADERS.get(job_id)
    if not markers:
        raise ParseError(f"No parser registered for job {job_id}")
    for i, line in enumerate(lines[:160]):
        cells = [_clean(v) for v in line.split("\t")]
        if len(cells) >= 3 and all(any(m.casefold() in c.casefold() for c in cells) for m in markers):
            return i, cells
    raise ParseError(f"Could not identify expected {job_id} table header; verify SAP layout and export format")


def _is_data(job_id, cells):
    def c(i):
        return cells[i].strip() if len(cells) > i else ""
    if job_id.startswith("coois_production"):
        return c(6).isdigit()
    if job_id.startswith("coois_capacities") or job_id.startswith("coois_confirmations"):
        return c(1).isdigit() and c(2).isdigit()
    if job_id == "lx02":
        return bool(c(1) and c(9))
    if job_id == "lx03":
        return bool(c(1) and c(2))
    if job_id == "lrf2":
        return bool(c(1))
    if job_id == "lt22":
        return c(1).isdigit() and c(2).isdigit()
    if job_id == "mb51":
        return bool(c(1)) and c(7).isdigit()
    if job_id == "zmm4tr093":
        return bool(DATE_DMY.fullmatch(c(1))) and c(5).isdigit()
    if job_id == "zmm4tr003":
        return c(1).isdigit()
    if job_id == "dock_to_stock":
        return bool(c(1) or c(2) or c(4))  # LT identifiers, some optional
    if job_id == "zmm4tb020":
        return bool(c(2) and c(3).isdigit())
    if job_id == "zbmt":
        return c(3).isdigit()
    if job_id == "zsd3tr009":
        return bool(c(2)) and bool(DATE_DMY.fullmatch(c(3)))
    if job_id == "zmm4tr012":
        return bool(c(1) or c(3))
    return False


def _check_row(cells, limit, job_id, line):
    if len(cells) > limit:
        extra = cells[limit:]
        if any(x.strip() for x in extra):
            raise ParseError(f"{job_id} line {line}: {len(cells)} columns exceed {limit}; unexpected nonempty data")
        cells = cells[:limit]
    return cells + [""] * (limit - len(cells))


@dataclass
class Parsed:
    job_id: str
    headers: list[str]
    source_headers: list[str]
    rows: list[list[str]]
    encoding: str
    data_lines: int
    no_data: bool
    ignored_total_lines: int = 0

    @property
    def row_count(self):
        return len(self.rows)


def parse_file(path: str | Path, job_id: str) -> Parsed:
    path = Path(path)
    if not path.is_file() or path.stat().st_size == 0:
        raise ParseError("Missing or empty raw SAP export")
    source = path.read_bytes()
    txt, enc = _decode(source)
    lines = txt.splitlines()
    # Unified, report-scoped SAP display-heading normalisation. This happens
    # BEFORE header identification and the existing strict physical-row checks.
    from .header_variants import normalise_header_lines
    lines = normalise_header_lines(lines, job_id)
    header_i, main_head = _get_header(lines, job_id)
    header = main_head.copy()
    header_offset = 1
    mode = "single"
    if job_id in ("zbmt", "zsd3tr009"):
        # SAP can insert blank separator lines after the first heading row.
        # Keep all 30 ZSD continuation positions; do not shift data columns.
        continuation_i = header_i + 1
        while continuation_i < len(lines) and not lines[continuation_i].strip():
            continuation_i += 1
        continuation = (lines[continuation_i].split("\t")
                        if continuation_i < len(lines) else [])
        if job_id == "zbmt" and (len(continuation) != 8 or "MRP Name" not in continuation[0]):
            raise ParseError(
                f"ZBMT second header line missing or malformed: line {continuation_i + 1}, "
                f"fields={len(continuation)}"
            )
        if job_id == "zsd3tr009":
            # The wrapped panel may begin with Sold to party Address 3, OR
            # with Telephone1 if SAP fitted the address onto the first panel.
            # Width is intentionally not fixed: only approved semantic order
            # and fully validated (non-dropped) data positions are accepted.
            while len(continuation) > 45 and not continuation[-1].strip():
                continuation.pop()
            main_named = [v.strip() for v in main_head if v.strip()]
            second_named = [v.strip() for v in continuation if v.strip()]
            if (not 24 <= len(continuation) <= 45 or
                    not second_named or second_named[-1].casefold() != "expedite" or
                    (second_named[0].casefold() not in
                     ("sold to party address 3", "telephone1")) or
                    ("sold to party address 3" not in
                     [x.casefold() for x in main_named + second_named])):
                raise ParseError("ZSD3TR009 unapproved continuation panel or missing Expedite")
            full_header = main_head + [_clean(v) for v in continuation]
            semantic = [_columns(full_header)[idx] for idx, h in enumerate(full_header) if h.strip()]
            if tuple(semantic) != ZSD3TR009_STABLE_FIELDS:
                first = next((i for i,(actual,approved) in enumerate(zip(semantic, ZSD3TR009_STABLE_FIELDS),1)
                              if actual != approved), None)
                raise ParseError(
                    f"ZSD3TR009 unapproved business-column layout: first mismatch at {first}; "
                    f"actual named fields={len(semantic)}, approved={len(ZSD3TR009_STABLE_FIELDS)}")
        # The horizontal continuation fields are appended to the first panel.
        header += [_clean(v) for v in continuation]
        header_offset = continuation_i - header_i + 1
        mode = "wrapped"
    # KPI_LAYOUT_FIX_20261110_V1: SAP uses wider labels in the November layout.
    # Retain the established CSV field identifiers used by Power BI.
    if job_id == "zmm4tr012":
        header = [{"Ship-to-party": "Ship-to-pa",
                   "Product Desc": "Product De",
                   "Profit centre name": "Profit cen"}.get(item, item)
                  for item in header]
        # The historical Excel file also has a numeric value in an unlabelled
        # position after "Picked carton Ind". Keep it, never discard it.
        if (len(header) == 51 and not header[38] and
                header[37].strip().casefold() == "picked car" and
                header[39].strip().casefold() == "shipper le"):
            header[38] = "sap_unlabelled_039"
    names = _columns(header)
    if len(names) > 240:
        raise ParseError("Unexpectedly wide table")
    normalised_rows = []
    no_data = False
    ignored_totals = 0
    pending = None
    primary_limit = len(main_head)
    continuation_limit = len(header) - primary_limit

    for index in range(header_i + header_offset, len(lines)):
        raw_line = lines[index]
        line_no = index + 1
        if not raw_line.strip():
            continue
        if any(m in raw_line.casefold() for m in NO_DATA_MARKERS):
            no_data = True
            continue
        cells = raw_line.split("\t")
        if job_id == "zbmt":
            if pending is None:
                if not _is_data(job_id, cells):
                    raise ParseError(f"ZBMT unexpected primary line {line_no} ({len(cells)} columns)")
                if len(cells) == 60:
                    # Eight long ZBMT rows are split across a THIRD line before the 8-column continuation.
                    if index + 1 >= len(lines):
                        raise ParseError(f"ZBMT primary line {line_no} missing overflow continuation")
                    next_cells = lines[index + 1].split("\t")
                    if len(next_cells) != 11:
                        raise ParseError(f"ZBMT primary line {line_no} has unexpected width 60")
                    pending = cells  # next loop will stitch the 11-column overflow
                    continue
                pending = _check_row(cells, primary_limit, job_id, line_no)
                continue
            if len(pending) == 60 and len(cells) == 11:
                if cells[0].strip():
                    raise ParseError(f"ZBMT overflow at line {line_no} has nonempty spacer")
                pending = _check_row(pending + cells[1:], primary_limit, job_id, line_no)
                continue
            if len(cells) != continuation_limit or (len(pending) != primary_limit):
                raise ParseError(f"ZBMT missing or malformed 8-column continuation at line {line_no}")
            row = pending + cells
            pending = None
        elif job_id == "zsd3tr009":
            if pending is None:
                # Ignore currency-summary lines; they do not have delivery keys.
                # KPI_ZSD_SEMANTIC_LAYOUT_V14: SAP shifts the currency
                # summary amount by a tab when widening the header. Only
                # skip rows containing NO delivery key and nothing except
                # the explicit total amount, ISO currency and optional '*'.
                currency = cells[-1].strip() if cells else ""
                candidates = [i for i in range(max(0, len(cells) - 4), len(cells) - 1)
                              if NUM.fullmatch(cells[i].strip())]
                amount_pos = candidates[0] if len(candidates) == 1 else -1
                is_currency_total = (
                    25 <= len(cells) <= 40 and
                    bool(re.fullmatch(r"[A-Z]{3}", currency)) and
                    len(candidates) == 1 and
                    cells[1].strip() in ("", "*") and
                    all((not value.strip() or i in (1, amount_pos, len(cells)-1))
                        for i, value in enumerate(cells)))
                if is_currency_total:
                    ignored_totals += 1
                    continue
                if not _is_data(job_id, cells):
                    raise ParseError(f"ZSD3TR009 unexpected main line {line_no}")
                pending = _check_row(cells, primary_limit, job_id, line_no)
                continue
            # _check_row rejects populated overhangs while safely trimming
            # trailing empty SAP tabs (a formatting-only difference).
            row = pending + _check_row(cells, continuation_limit, job_id, line_no)
            pending = None
        else:
            if not _is_data(job_id, cells):
                raise ParseError(f"{job_id} unexpected table line {line_no} ({len(cells)} columns)")
            row = _check_row(cells, len(header), job_id, line_no)
        if len(row) != len(names):
            raise ParseError(f"{job_id} line {line_no}: table width mismatch")
        normalised_rows.append([_normalise(val, field) for field, val in zip(names, row)])
    if pending is not None:
        raise ParseError(f"{job_id} has an incomplete wrapped record at end of file")
    if no_data and normalised_rows:
        raise ParseError(f"{job_id} contains both data rows and a no-data marker")
    if not normalised_rows and not no_data:
        raise ParseError(f"{job_id} produced no data rows and no recognised no-data marker")
    if job_id == "zmm4tr093":
        # Compare physical rows with the number SAP wrote in the report preamble.
        for before in lines[:header_i]:
            m = re.search(r"Total Records\s*:\s*\t+(?:\s*\t+)*(\d[\d,]*)", before, re.I)
            if m and int(m.group(1).replace(",", "")) != len(normalised_rows):
                raise ParseError("ZMM4TR093 row count differs from Total Records metadata")
    # Remove *physically blank* SAP header positions only AFTER validating and
    # aligning every row. Never drop a populated cell without a column name.
    keep_positions = []
    for pos, sap_heading in enumerate(header):
        if sap_heading.strip():
            keep_positions.append(pos)
        else:
            first = next(((row_n + 1, row[pos])
                          for row_n, row in enumerate(normalised_rows)
                          if row[pos].strip()), None)
            if first is not None:
                left = header[pos - 1].strip() if pos else "(start)"
                right = header[pos + 1].strip() if pos + 1 < len(header) else "(end)"
                raise ParseError(
                    f"{job_id}: unnamed SAP column at position {pos + 1} "
                    f"contains data on data row {first[0]}; "
                    f"neighbouring headings={left!r} / {right!r}. "
                    "Do not drop this field: save the exact failing Raw TXT "
                    "for layout/column alignment review."
                )
    published_names = [names[pos] for pos in keep_positions]
    published_header = [header[pos] for pos in keep_positions]
    published_rows = [[row[pos] for pos in keep_positions] for row in normalised_rows]
    # KPI_TR093_SCHEMA_FIX_20261110_V3: the published schema uses
    # "unloading_point", whereas SAP headings may be "Unl. Point" or
    # "Unloading Point". Preserve the established field name without changing
    # field positions, row values, or other reports' schemas.
    if job_id == "zmm4tr093":
        if (len(published_names) != 23
                or published_names[20] != "to_prio"
                or published_names[21] not in ("unl_point", "unloading_point")
                or published_names[22] != "storagebin"):
            raise ParseError("ZMM4TR093 column 22 is not the verified Unloading Point field; publication refused")
        published_names[21] = "unloading_point"
    # KPI_LAYOUT_FIX_20261110_V1: normalize both verified ZMM layouts into a
    # stable additive schema. The extra unnamed SAP field is always LAST.
    # This is deliberately not mapped to any business measure until identified.
    if job_id == "zmm4tr012":
        legacy_columns = (
            "profit_cen", "order_item", "po_no", "delivery_p", "delivery_c",
            "ship_to_pa", "ship_to_cu", "sold_to_cu", "material", "product_de",
            "delv_item", "delv_creat", "delv_creat__2", "planned_gd",
            "shipment_n", "ship_point", "ship_cond", "distr_cha", "ship_qty",
            "sales_unit", "ship_value", "docu_curre", "cartons_st", "line_item",
            "delivery_hu", "3s_lts", "ship_date", "profit_cen__2", "plant_name",
            "picked_car", "full_carto", "partials_p", "full_palle", "cartons_on",
            "picked_car__2", "shipper_le", "shipper_wi", "shipper_he",
            "dimension", "shipper_vo", "volume_uom", "plant", "unique_ord",
            "unique_del", "ship_value__2", "storage_lo", "building_n")
        extra_col = "sap_unlabelled_039"
        if tuple(n for n in published_names if n != extra_col) != legacy_columns:
            raise ParseError("ZMM4TR012 unrecognised business-column layout; "
                             "the file was not published")
        if extra_col in published_names:
            extra_idx = published_names.index(extra_col)
            preserved = [row.pop(extra_idx) for row in published_rows]
            published_names.pop(extra_idx)
            published_header.pop(extra_idx)
        else:
            preserved = [""] * len(published_rows)
        published_names.append(extra_col)
        published_header.append("Unlabelled SAP column 39 (unverified)")
        for row, value in zip(published_rows, preserved):
            row.append(value)
    return Parsed(job_id, published_names, published_header, published_rows, enc,
                  len(published_rows), no_data, ignored_totals)


def process_to_csv(src: str | Path, job_id: str, csv_path: str | Path,
                   metadata_path: str | Path | None = None) -> dict:
    """Parse and stage CSV + metadata. Caller controls publication/atomicity."""
    parsed = parse_file(src, job_id)
    csv_path = Path(csv_path)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(parsed.headers)
        writer.writerows(parsed.rows)
    summary = {
        "job_id": job_id,
        "parser_version": "0.5.1",
        "source_encoding": parsed.encoding,
        "source_bytes": Path(src).stat().st_size,
        "source_sha256": __import__("hashlib").sha256(Path(src).read_bytes()).hexdigest(),
        "row_count": parsed.row_count,
        "column_count": len(parsed.headers),
        "empty_result": parsed.no_data,
        "ignored_currency_totals": parsed.ignored_total_lines,
        "columns": [{"index": i, "name": col, "sap_header": orig}
                    for i, (col, orig) in enumerate(zip(parsed.headers, parsed.source_headers))],
    }
    if metadata_path:
        metadata_path = Path(metadata_path)
        metadata_path.parent.mkdir(parents=True, exist_ok=True)
        metadata_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return summary
