"""Pre-parse recognition of *reviewed* SAP heading variants.

Keeps SAP's original row values, physical tab positions and archived raw files.
Only canonicalises headings after verifying an entire named-field sequence.
The existing parser's strict blank-column and row validation still runs.

Every approved display alias lives in schema_contracts/header_variants.json.
Ambiguous/missing fields or newly populated SAP spacer positions fail closed.
"""
from __future__ import annotations

import json
import re
from pathlib import Path


REGISTRY = Path(__file__).resolve().parent.parent / "schema_contracts" / "header_variants.json"
DATE = re.compile(r"^\d\d\.\d\d\.\d{4}$")


class HeaderVariantError(ValueError):
    """Unknown or misaligned SAP display layout."""


def _key(value):
    return " ".join(value.split()).casefold()


def _load():
    document = json.loads(REGISTRY.read_text(encoding="utf-8"))
    if document.get("version") != 1 or not isinstance(document.get("jobs"), dict):
        raise HeaderVariantError("Approved SAP header registry has the wrong version")
    return document["jobs"]


def _matched_headings(fields, rule, jid):
    expected = rule["canonical"]
    named_indices = [pos for pos, value in enumerate(fields) if value.strip()]
    if len(named_indices) != len(expected):
        raise HeaderVariantError(
            f"{jid}: {len(named_indices)} named SAP headings; expected {len(expected)}. "
            "Possible added or missing column: raw file retained")
    allowed = {}
    for term in expected:
        allowed[_key(term)] = term
    for standard, options in rule.get("aliases", {}).items():
        if standard not in expected:
            raise HeaderVariantError(f"{jid}: alias registry references unknown field {standard!r}")
        for option in options:
            key = _key(option)
            if key in allowed and allowed[key] != standard:
                raise HeaderVariantError(f"{jid}: ambiguous alias registry label {option!r}")
            allowed[key] = standard
    for ordinal, pos in enumerate(named_indices):
        actual, approved = fields[pos].strip(), expected[ordinal]
        if allowed.get(_key(actual)) != approved:
            raise HeaderVariantError(
                f"{jid}: named heading {ordinal+1} in physical tab {pos+1} "
                f"is {actual!r}; expected {approved!r} or its approved aliases. "
                "No values were published")
        fields[pos] = approved
    return named_indices


def _find_unique(lines, jid, predicate):
    matching = [i for i, line in enumerate(lines[:160]) if predicate(line.split("\t"))]
    if len(matching) > 1:
        raise HeaderVariantError(f"{jid}: multiple possible SAP table headers; unsafe to infer")
    return matching[0] if matching else None


def normalise_header_lines(lines: list[str], job_id: str) -> list[str]:
    """Return a transformed COPY of source lines. Original TXT is never edited."""
    rules = _load()
    if job_id not in rules:
        return lines
    lines = list(lines)
    if job_id == "lrf2":
        idx = _find_unique(lines, job_id, lambda c: len(c) >= 5 and
                           [x.strip() for x in c[-3:]] == ["Queue", "Document", "P"])
        if idx is None:
            return lines   # existing parser explains a genuinely absent table
        fields = lines[idx].split("\t")
        if len(fields) != 5 or fields[0].strip():
            raise HeaderVariantError("LRF2: unrecognised field positions")
        _matched_headings(fields, rules[job_id], job_id)
        lines[idx] = "\t".join(fields)
        return lines

    if job_id == "zmm4tr093":
        idx = _find_unique(lines, job_id,
                           lambda c: "Conf. Date" in [x.strip() for x in c] and
                           "TO Number" in [x.strip() for x in c] and
                           "Number of 3S LTs" in [x.strip() for x in c])
        if idx is None:
            return lines
        fields = lines[idx].split("\t")
        if not (24 <= len(fields) <= 28 and len(fields) > 6 and
                fields[1].strip() == "Conf. Date"):
            raise HeaderVariantError("ZMM4TR093: unknown physical header width/anchors")
        _matched_headings(fields, rules[job_id], job_id)
        # The earlier SAP layout has a redundant EMPTY tab before TO Number.
        # Remove only that physical slot, and only when empty on EVERY data row.
        to_pos = next(i for i,v in enumerate(fields) if v == "TO Number")
        if to_pos == 6:
            if fields[5].strip():
                raise HeaderVariantError("ZMM4TR093: populated extra heading before TO Number")
            fields.pop(5)
            for row_index in range(idx+1, len(lines)):
                row_text = lines[row_index]
                if not row_text.strip():
                    continue
                if "list contains no data" in row_text.casefold():
                    continue
                vals = row_text.split("\t")
                if (len(vals) < 7 or vals[5].strip() or
                        not DATE.fullmatch(vals[1].strip()) or not vals[6].strip().isdigit()):
                    raise HeaderVariantError(
                        f"ZMM4TR093: line {row_index+1} does not have the verified blank "
                        "slot and transfer-order field; nothing published")
                vals.pop(5)
                lines[row_index] = "\t".join(vals)
        elif to_pos != 5:
            raise HeaderVariantError(
                f"ZMM4TR093: TO Number at unexpected physical tab {to_pos+1}; "
                "unrecognised layout")
        # Keep the remaining blank physical positions until the parser validates
        # that none have ever contained data. Never blindly drop a spacer.
        lines[idx] = "\t".join(fields)
        return lines

    if job_id == "mb51":
        idx = _find_unique(lines, job_id, lambda c:
                           all(x in [v.strip() for v in c] for x in
                               ("Mat. Doc.", "Pstng Date", "MvT")))
        if idx is None:
            return lines
        fields = lines[idx].split("\t")
        if len(fields) != 23 or fields[0].strip():
            raise HeaderVariantError("MB51: unknown physical column structure")
        named = _matched_headings(fields, rules[job_id], job_id)
        if named != list(range(1, 23)):
            raise HeaderVariantError("MB51: unexpected noncontiguous data fields")
        lines[idx] = "\t".join(fields)
        return lines

    if job_id == "zsd3tr009":
        idx = _find_unique(lines, job_id,
                           lambda c: "ShPnt" in [v.strip() for v in c] and
                           "Delv/Item" in [v.strip() for v in c])
        if idx is None:
            return lines
        fields = lines[idx].split("\t")
        if not (85 <= len(fields) <= 120 and len(fields) > 3 and
                fields[2].strip() == "ShPnt"):
            raise HeaderVariantError("ZSD3TR009: unapproved panel start")
        if fields[3].strip() not in ([rules[job_id]["canonical_first_date"]] +
                                     rules[job_id]["date_aliases"]):
            raise HeaderVariantError("ZSD3TR009: unknown date heading")
        fields[3] = rules[job_id]["canonical_first_date"]
        lines[idx] = "\t".join(fields)
        return lines
    return lines
