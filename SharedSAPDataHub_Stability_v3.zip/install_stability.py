#!/usr/bin/env python3
"""Guarded parser+registry update for exact 12-Nov-2026 Data Hub source snapshot.

Never writes published Raw/Live/History, SAP config, app.py, or scheduler state.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

PACKAGE=Path(__file__).resolve().parent
SOURCES={
    'processing/parser.py':'79e0ba5ea14d83fadb980e4fe3c518cfd83041b38686fb98dd65949b3e7d49bb',
    'schema_contracts/aliases.json':'8907a9895412900c088efd4afd4ebf99f4ff4ac5d32a53ea2d03a3599396b3e1',
}
DESTS=['processing/parser.py','schema_contracts/aliases.json',
       'processing/header_variants.py','schema_contracts/header_variants.json']

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def validate_payload():
    for rel in DESTS:
        path=PACKAGE/'payload'/rel
        if not path.is_file():
            raise ValueError(f'Package missing {rel}')
    for rel in ('processing/parser.py','processing/header_variants.py'):
        compile((PACKAGE/'payload'/rel).read_text(encoding='utf8'),rel,'exec')
    for rel in ('schema_contracts/aliases.json','schema_contracts/header_variants.json'):
        json.loads((PACKAGE/'payload'/rel).read_text(encoding='utf8'))

def check(root):
    validate_payload()
    if not (root/'app.py').is_file() or not (root/'processing'/'schema_contracts.py').is_file():
        raise ValueError('This is not the expected Data Hub root with Schema Contracts v2')
    for rel,known in SOURCES.items():
        dest=root/rel
        if not dest.is_file():
            raise ValueError(f'Missing installed source: {dest}')
        actual=digest(dest)
        revised=digest(PACKAGE/'payload'/rel)
        if actual==revised:
            print(f'ALREADY UPDATED: {rel}')
        elif actual==known:
            print(f'COMPATIBLE: {rel}')
        else:
            raise ValueError(f'{rel} does not match the uploaded 12-Nov source snapshot. '
                             f'Found SHA256 {actual}. Do not force; recollect source.')
    for rel in DESTS:
        if rel in SOURCES:continue
        path=root/rel
        if path.exists() and digest(path)!=digest(PACKAGE/'payload'/rel):
            raise ValueError(f'{path} already exists with different content. Do not overwrite.')
    print('PASS: source compatibility and payload syntax/JSON checks')

def atomic_copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix='.stability_',suffix='.tmp',dir=dst.parent,delete=False) as f:
        temporary=Path(f.name)
        f.write(Path(src).read_bytes())
        f.flush()
        os.fsync(f.fileno())
    try:os.replace(temporary,dst)
    finally:temporary.unlink(missing_ok=True)

def apply(root):
    check(root)
    if all((root/rel).is_file() and digest(root/rel)==digest(PACKAGE/'payload'/rel) for rel in DESTS):
        print('Already installed; nothing to change.')
        return
    backup=root/'runtime'/'stability_backups'/('source_20261112_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S'))
    if backup.exists():raise ValueError(f'Backup directory unexpectedly exists: {backup}')
    backup.mkdir(parents=True)
    meta=[]
    for rel in DESTS:
        src=root/rel
        entry={'path':rel,'existed':src.exists(),
               'before_sha256':digest(src) if src.exists() else None,
               'installed_sha256':digest(PACKAGE/'payload'/rel)}
        if src.exists():
            dest=backup/'original'/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dest)
        meta.append(entry)
    (backup/'backup_manifest.json').write_text(json.dumps({'entries':meta},indent=2),encoding='utf8')
    done=[]
    try:
        for rel in DESTS:
            atomic_copy(PACKAGE/'payload'/rel,root/rel)
            done.append(rel)
        for rel in DESTS:
            if digest(root/rel)!=digest(PACKAGE/'payload'/rel):
                raise ValueError(f'Installed file hash mismatch: {rel}')
    except BaseException:
        for entry in reversed(meta):
            rel=entry['path']
            if rel not in done:continue
            dst=root/rel
            if entry['existed']:
                atomic_copy(backup/'original'/rel,dst)
            else:
                dst.unlink(missing_ok=True)
        raise
    print('SUCCESS: four parser/registry files installed; no published data changed.')
    print('ROLLBACK BACKUP:',backup)

def rollback(root,backup):
    manifest=backup/'backup_manifest.json'
    if not manifest.is_file(): raise ValueError('Missing backup_manifest.json; refuse rollback')
    entries=json.loads(manifest.read_text(encoding='utf8'))['entries']
    if [e['path'] for e in entries]!=DESTS:
        raise ValueError('Backup not from this installer')
    for e in entries:
        dest=root/e['path']
        if not dest.is_file() or digest(dest)!=e['installed_sha256']:
            raise ValueError(f'Installed {dest} has changed; refusing rollback overwrite')
        if e['existed'] and digest(backup/'original'/e['path'])!=e['before_sha256']:
            raise ValueError(f'Backup copy failed integrity check: {e["path"]}')
    for e in reversed(entries):
        dest=root/e['path']
        if e['existed']: atomic_copy(backup/'original'/e['path'],dest)
        else: dest.unlink()
    print('ROLLBACK COMPLETE. Restart Data Hub only after checking compatibility.')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--hub-root',required=True,type=Path)
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--check',action='store_true')
    group.add_argument('--apply',action='store_true')
    group.add_argument('--rollback',type=Path,help='Timestamped backup folder printed by apply')
    args=p.parse_args()
    try:
        if args.check:check(args.hub_root)
        elif args.apply:apply(args.hub_root)
        else:rollback(args.hub_root,args.rollback)
    except Exception as exc:
        print(f'STOP: {exc}',file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':sys.exit(main())
