"""Fail-closed published CSV schema stability layer for the Shared SAP Data Hub.

Unlike blind position-based renaming, a candidate column can be aligned with a
published field only through exact identity, punctuation/case equivalence, or an
explicit, report-scoped approved alias. Row values are never discarded.
"""
from __future__ import annotations

import csv
import json
import os
import re
import tempfile
from collections import Counter
from pathlib import Path


class ContractError(ValueError):
    """The export's schema cannot be reconciled without risking data integrity."""


def canonical(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.casefold()).strip("_")


def _read_json(path: Path) -> dict:
    try:
        document = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        raise ContractError(f"Cannot read {path}: {exc}") from exc
    if not isinstance(document, dict):
        raise ContractError(f"{path}: expected a JSON object")
    return document


def _column_names(columns, location: str) -> list[str]:
    if not isinstance(columns, list) or not columns:
        raise ContractError(f"{location}: missing columns")
    names = []
    for item in columns:
        name = item.get("name") if isinstance(item, dict) else item
        if not isinstance(name, str) or not name.strip():
            raise ContractError(f"{location}: empty or invalid column name")
        names.append(name)
    if len(set(names)) != len(names):
        raise ContractError(f"{location}: duplicate column names; cannot map unambiguously")
    return names


def _read_csv_headers(path: Path) -> list[str]:
    try:
        with path.open("r", newline="", encoding="utf-8-sig") as handle:
            return next(csv.reader(handle))
    except (OSError, StopIteration, csv.Error) as exc:
        raise ContractError(f"Cannot read CSV header {path}: {exc}") from exc


def _validate_contract_document(path: Path, jid: str) -> list[str]:
    doc = _read_json(path)
    if doc.get("job_id") != jid or doc.get("contract_version") != 1:
        raise ContractError(f"{path}: wrong job id or contract version")
    return _column_names(doc.get("columns"), str(path))


def _known_alias_groups(hub_root: Path, jid: str) -> list[list[str]]:
    path = hub_root / "schema_contracts" / "aliases.json"
    if not path.is_file():
        raise ContractError(f"Missing approved alias registry {path}; installation incomplete")
    doc = _read_json(path)
    if doc.get("version") != 1 or not isinstance(doc.get("jobs"), dict):
        raise ContractError("Alias registry has unsupported format")
    groups = doc["jobs"].get(jid, [])
    if not isinstance(groups, list):
        raise ContractError(f"Alias groups for {jid}: expected a list")
    seen: dict[str, int] = {}
    out = []
    for index, group in enumerate(groups):
        if not isinstance(group, list) or len(group) < 2:
            raise ContractError(f"Alias group {jid}/{index} invalid")
        keys = [canonical(v) for v in group if isinstance(v, str)]
        if len(keys) != len(group) or not all(keys) or len(set(keys)) != len(keys):
            raise ContractError(f"Alias group {jid}/{index} has duplicate/invalid keys")
        for key in keys:
            if key in seen:
                raise ContractError(f"Alias {key!r} assigned to multiple groups in {jid}")
            seen[key] = index
        out.append(keys)
    return out


def _semantic_key(name: str, aliases: list[list[str]]) -> str:
    key = canonical(name)
    for group in aliases:
        if key in group:
            return "alias:" + "|".join(sorted(group))
    return "name:" + key


def _mapping(candidate: list[str], expected: list[str], aliases: list[list[str]], jid: str) -> list[int]:
    """Map each expected field to candidate position, or reject ambiguity.

    A field with a duplicate physical SAP label (e.g. dest_qty__2) must not
    change position because an exchange of indistinguishable fields cannot be
    proven safe from heading text alone.
    """
    actual_keys = [_semantic_key(n, aliases) for n in candidate]
    expected_keys = [_semantic_key(n, aliases) for n in expected]
    if len(candidate) != len(expected):
        raise ContractError(
            f"{jid}: field count changed: Live={len(expected)}, parsed={len(candidate)}. "
            "Unknown or omitted columns require review; nothing published")
    if len(set(actual_keys)) != len(actual_keys) or len(set(expected_keys)) != len(expected_keys):
        raise ContractError(f"{jid}: column alias collision; cannot safely align fields")
    if set(actual_keys) != set(expected_keys):
        mismatches = [f"{i+1}: Live={old!r}, parsed={new!r}"
                      for i, (old, new) in enumerate(zip(expected, candidate)) if old != new]
        missing = sorted(set(expected_keys) - set(actual_keys))
        added = sorted(set(actual_keys) - set(expected_keys))
        raise ContractError(
            f"{jid}: unapproved schema change: " + "; ".join(mismatches[:12]) +
            f"; missing semantic identities={missing[:8]}; new identities={added[:8]}. "
            "Approve a verified report-scoped alias or investigate the raw SAP layout; nothing published")
    positions = {k: i for i, k in enumerate(actual_keys)}
    order = [positions[k] for k in expected_keys]
    if order != list(range(len(candidate))):
        def duplicate_roots(seq):
            # Slug output duplicates (e.g. price and price__2) reflect ambiguous
            # repeated SAP labels, even when published names are unique.
            roots = [re.sub(r"_\d+$", "", canonical(n)) for n in seq]
            counts = Counter(roots)
            return {root for root, count in counts.items() if count > 1}
        duplicated = duplicate_roots(candidate) | duplicate_roots(expected)
        if duplicated:
            for target_index, source_index in enumerate(order):
                old_root = re.sub(r"_\d+$", "", canonical(expected[target_index]))
                new_root = re.sub(r"_\d+$", "", canonical(candidate[source_index]))
                if target_index != source_index and (old_root in duplicated or new_root in duplicated):
                    raise ContractError(f"{jid}: duplicate-labelled fields moved; positional identity is unprovable")
    return order


def align_staged_to_live(
    hub_root: str | Path,
    publish_root: str | Path,
    jid: str,
    staged_csv: str | Path,
    staged_meta: str | Path,
    summary: dict,
    *,
    dry_run: bool = False,
) -> dict:
    """Align staged output to a locked schema before Hub._stage_processed checks it.

    Validates CSV/JSON and pinned contract; returns a new summary only after
    rewriting the staging CSV and JSON (never Live, Raw or History). All
    candidates are checked and mapped; no data values are dropped.
    """
    hub_root = Path(hub_root)
    publish_root = Path(publish_root)
    staged_csv = Path(staged_csv)
    staged_meta = Path(staged_meta)
    if not isinstance(summary, dict) or summary.get("job_id") != jid:
        raise ContractError(f"{jid}: staged summary job ID mismatch")
    current = _column_names(summary.get("columns"), "staged summary")
    if _read_csv_headers(staged_csv) != current:
        raise ContractError(f"{jid}: staged CSV header differs from parser's schema JSON")
    if _column_names(_read_json(staged_meta).get("columns"), str(staged_meta)) != current:
        raise ContractError(f"{jid}: staged metadata differs from parser's returned schema")

    contract_file = hub_root / "schema_contracts" / f"{jid}.json"
    expected = _validate_contract_document(contract_file, jid) if contract_file.exists() else None
    live_base = publish_root / "Live" / jid
    live_meta = live_base / f"{jid}_schema.json"
    live_csv = live_base / f"{jid}_latest.csv"
    if live_meta.exists() != live_csv.exists():
        raise ContractError(f"{jid}: existing Live CSV/schema pair is incomplete; fix publication before refreshing")
    if live_meta.exists():
        live = _column_names(_read_json(live_meta).get("columns"), str(live_meta))
        if _read_csv_headers(live_csv) != live:
            raise ContractError(f"{jid}: existing Live CSV headers differ from Live schema JSON")
        if expected is None:
            # Existing v0.6 guard remains in place. We do NOT silently create
            # persistent contracts from unreviewed live files.
            expected = live
        elif expected != live:
            # One previously approved, additive Data Hub v1.1 schema migration:
            # ZMM4TR012 appends its preserved unlabelled SAP column at the end.
            # The older pinned contract may predate the one-time promotion;
            # use the verified newer Live contract, never an arbitrary change.
            if jid == "zmm4tr012" and live == expected + ["sap_unlabelled_039"]:
                expected = live
            else:
                raise ContractError(
                    f"{jid}: published Live schema differs from the pinned contract. "
                    "Manual integrity review required; do not overwrite Live")
    if expected is None:
        return summary  # first publication; v0.6 parser + strict guard still protect it
    aliases = _known_alias_groups(hub_root, jid)
    # The Data Hub v1.1 controller explicitly approves this ONE 47->48
    # appended ZMM4TR012 field, preserving values from physical column 39.
    # Do not block the transition before the original controller guard runs.
    if jid == "zmm4tr012" and current == expected + ["sap_unlabelled_039"]:
        return summary
    order = _mapping(current, expected, aliases, jid)
    if order == list(range(len(current))) and current == expected:
        return summary
    new_summary = dict(summary)
    cols = summary["columns"]
    new_cols = []
    for target_index, candidate_index in enumerate(order):
        entry = dict(cols[candidate_index])
        entry["index"] = target_index
        entry["name"] = expected[target_index]
        new_cols.append(entry)
    new_summary["columns"] = new_cols
    new_summary["column_count"] = len(new_cols)
    new_summary["contract_alignment"] = {
        "type": "approved_identity_or_alias",
        "renamed": [(current[src], expected[dest]) for dest, src in enumerate(order)
                    if current[src] != expected[dest]],
        "reordered": order != list(range(len(current))),
    }
    if dry_run:
        return new_summary
    # Write staging output safely; a failed conversion leaves the originals
    # and published datasets unchanged. Rename each temp after completion.
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8-sig", newline="", dir=staged_csv.parent,
                                     prefix=".contract_", suffix=".csv", delete=False) as handle:
        tmp_csv = Path(handle.name)
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(expected)
        try:
            with staged_csv.open("r", encoding="utf-8-sig", newline="") as original:
                reader = csv.reader(original)
                next(reader)
                for line_n, row in enumerate(reader, 2):
                    if len(row) != len(current):
                        raise ContractError(f"{jid}: staged CSV line {line_n} has {len(row)} cells, expected {len(current)}")
                    writer.writerow([row[src] for src in order])
        except BaseException:
            tmp_csv.unlink(missing_ok=True)
            raise
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=staged_meta.parent,
                                         prefix=".contract_", suffix=".json", delete=False) as handle:
            tmp_meta = Path(handle.name)
            json.dump(new_summary, handle, indent=2, ensure_ascii=False)
        os.replace(tmp_csv, staged_csv)
        os.replace(tmp_meta, staged_meta)
    finally:
        tmp_csv.unlink(missing_ok=True)
        if "tmp_meta" in locals():
            tmp_meta.unlink(missing_ok=True)
    return new_summary
