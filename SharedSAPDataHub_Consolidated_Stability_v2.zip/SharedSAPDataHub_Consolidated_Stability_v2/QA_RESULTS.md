# QA Results — Consolidated Schema Stability v2.0

Tested against a simulated local Data Hub constructed from the supplied v0.6 controller, a parser reconstructed with the v1.1–v1.4 patches, and 17 saved real Raw report samples. Also directly parsed the provided recent LRF2, ZMM4TR093, and ZSD3TR009 TXT files.

| Test | Result |
|---|---|
| All 17 reference Raw samples | Pass, original field names/rows retained |
| New LRF2 `User` heading | Pass — 4 stable columns |
| New TR093 abbreviated headings | Pass — 23 stable columns |
| New ZSD3TR009 wrapped November layout | Pass — 119 rows / 95 columns |
| Installer `--check` on simulated Hub | Pass; no files modified |
| Installer `--apply` on simulated Hub | Pass; app and parser backed up |
| Central schema pins from CSV+metadata | Pass; 17 contracts pinned |
| Published Live CSV and JSON consistency | Pass |
| Strict-schema alias `unl_point → unloading_point` | Pass; stage CSV+schema aligned |
| Arbitrary unapproved renamed field | Rejected safely |
| Repeated `--check` after install | Pass; idempotent detection |
| Read-only job audit | Pass |
| `--rollback` | Pass; original app/parser restored |

**Limitations:** The tests are not an execution on the user's Windows/SAP environment or actual current W: drive. The MB51 mismatch still needs the exact failed Raw TXT and Live schema for a safe mapping. Only known and verified SAP export layouts are approved; completely novel variants can continue to trigger a protective error.
