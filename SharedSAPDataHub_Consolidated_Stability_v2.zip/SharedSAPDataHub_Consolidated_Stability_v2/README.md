# Shared SAP Data Hub — Consolidated Schema Stability v2.0

## What this ZIP does

**One installer**, not two manual patch sequences. The installer combines:

1. **LRF2 compatibility**: the SAP header `User` maps to the existing published `user_name` field. The old `User Name` header remains supported.
2. **ZMM4TR093 compatibility**: verified `Descr.` / `Material Description`, `Stor. Bin` / `StorageBin`, `Unl. Point` / `Unloading Point`, and `User` / `Name(QNAME)` variants map to the established 23-field published schema. The previous empty-tab alignment check is retained.
3. **Central pinned schema contracts**: for every report that has a verified existing Live CSV/schema pair, pin its column names and order. After parsing, approved aliases and unambiguous field orders are normalised back to that contract. Unknown names, ambiguous fields and unexpected data remain blocked.
4. **Power BI FactTR093 correction**: `PowerQuery/FactTR093.pq` references the published `unloading_point` instead of the obsolete `unl_point`. **This file is included for you to paste into Power BI separately if necessary**; an installer cannot rewrite the PBIX automatically.

The previously approved ZMM4TR012 one-field additive transition (`sap_unlabelled_039`) remains supported; genuinely new columns still require review.

The installer **does not change** SAP export settings, `config.json`, any already published Live/Raw/History data, or Power BI. It adds `processing/schema_contracts.py` and `schema_contracts/*.json`, and makes narrowly anchored additions to `processing/parser.py` and `app.py`. It does not replace those entire modules with old versions.

## Prerequisites

- Data Hub v0.6/v0.6.1 family, with the **v1.4 ZSD3TR009 semantic-layout fix already installed**. This is the reported state of your controller. If missing, the installer refuses to proceed; do not force it.
- Working W: drive access to the configured Data Hub publish root.
- Python 3, no extra packages required.
- Administrative write access to your local Data Hub folder.
- The Data Hub controller must be **fully stopped before `--apply`**; pause Task Scheduler jobs, let any running exports finish, and back up your entire Data Hub folder.

## Installation (only two commands)

Unzip to `C:\SAP_DataHub_Stability_v2` (the directory must contain `install_all.py`). In Command Prompt:

```bat
cd /d "C:\SAP_DataHub_Stability_v2"
py -3 install_all.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --check
```

The check is read-only and reports:

- Whether the LRF2 and TR093 parser corrections are needed
- Whether the central schema contract layer is already installed
- How many valid existing W: Live contracts are available
- Whether the anonymised LRF2 and TR093 samples parse with stable output columns
- Differences found in saved **last-successful** Raw exports; those are not necessarily the *failed* attempts

If the check completes successfully and contains no unexpected review findings, stop the controller and run:

```bat
py -3 install_all.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --apply
```

The installer records its backup location under
`<DataHub>\runtime\schema_contract_backups\unified_v2_<timestamp>\`.

**If you have already installed v1.5 or central Schema Contracts v1.0:** the installer recognises existing compatible installations and skips them. It refuses partial/inconsistent installations; it will not overwrite your existing alias registry or pinned schema contracts.

## Validate and restart

1. Keep scheduling paused, restart the controller manually.
2. Run **LRF2** and **ZMM4TR093**; check their Live CSV/schema JSON and publication status.
3. Run **ZSD3TR009** and check its Live publication.
4. Run **MB51** only after reviewing any current `REVIEW` result; MB51's previously reported mismatch is not yet diagnosed by an actual failed Raw TXT. Do not assume this installer resolves MB51.
5. Resume scheduling only for verified jobs. Complete the Power BI source migration afterwards.

To audit a specific TXT without modifying published files:

```bat
py -3 install_all.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --audit-job mb51 --raw "C:\KPI_Test\mb51.txt"
```

To audit each job's most recent **published** Raw TXT:

```bat
py -3 install_all.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --audit-all
```

## Power BI: FactTR093

If your `FactTR093` query still refers to `unl_point`, open Power BI Desktop → Transform data → FactTR093 → Advanced Editor and paste the included `PowerQuery/FactTR093.pq` (after saving the old M code). The expected published Data Hub column is **`unloading_point`**. No Data Hub installation can directly change a Power BI Desktop query.

## Why not blindly label every physical position?

The original SAP `Text with Tabs` exports have varying counts of *physical tab positions*. When column widths change, SAP may add an empty tab, alter which header line contains a field, or wrap a record differently. Consequently, **physical tab position 22 is not always logical business field 22**. The parser must first identify and validate the report layout and align values. After that, the *logical published fields* can take their fixed names from the pinned contract.

A simple label shortening therefore no longer needs to change Power BI's column name, but a changed field count, new business field, unexpected value in an unlabeled column or unverifiable reorder is still rejected. These safeguards prevent a successful-looking but financially incorrect KPI refresh.

This significantly reduces failures but cannot guarantee the SAP application will never produce a truly new layout. Adding a new **approved** layout/alias is intentionally a reviewable change, not an automatic silent guess.

## Rollback

With the controller stopped, use the exact backup folder printed by `--apply`:

```bat
py -3 install_all.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --rollback "C:\Users\EB013665\DataHub\DataHub-main\runtime\schema_contract_backups\unified_v2_YYYYMMDD_HHMMSS_NNNNNN"
```

Rollback verifies installed source-file hashes and restores the **original app.py and parser.py bytes**; it refuses rollback if those files were modified in the meantime. The newly added contract files are left in place but are unused by the restored controller. Restart the controller after rollback.

### Important note about MB51

We do **not** have the failed MB51 TXT and Live schema pair. We cannot safely approve MB51's actual field mismatch, nor guarantee its current error disappears, until its true header/data layout is examined. The installer is intentionally prevented from inferring this from field position alone.
