"""Guarded, parser-only compatibility update for two verified SAP TXT headings.

LRF2: 'User' is an approved alias of the established 'User Name' heading.
ZMM4TR093: 'Descr.' and 'Stor. Bin' are approved aliases of established
'Material Description' and 'StorageBin' headings.

This does not change any physical data positions or bypass the Data Hub's
existing strict schema, row-count, or unlabelled-field checks.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import sys
import types

TAG = "KPI_LRF2_TR093_HEADER_ALIASES_V15"
NEEDED_TAGS = ("KPI_LAYOUT_FIX_20261110_V2", "KPI_TR093_SCHEMA_FIX_20261110_V3", "KPI_ZSD_SEMANTIC_LAYOUT_V14")
ANCHOR = '    lines = txt.splitlines()\n'

COMPAT = '''    # KPI_LRF2_TR093_HEADER_ALIASES_V15
    # Match specific, reviewed SAP header shapes ONLY; change heading labels
    # in a local memory copy, never data cells or source TXT files.
    if job_id == "lrf2":
        candidates = []
        for _i, _line in enumerate(lines[:160]):
            _fields = _line.split("\\t")
            if (len(_fields) == 5 and _fields[2].strip() == "Queue"
                    and _fields[3].strip() == "Document" and _fields[4].strip() == "P"):
                candidates.append((_i, _fields))
        if len(candidates) > 1:
            raise ParseError("LRF2: multiple candidate report headers; refusing ambiguous file")
        if candidates:
            _i, _fields = candidates[0]
            if _fields[1].strip() not in ("User", "User Name"):
                raise ParseError("LRF2: unapproved processor identifier heading")
            _fields[1] = "User Name"
            lines[_i] = "\\t".join(_fields)
    elif job_id == "zmm4tr093":
        candidates = []
        for _i, _line in enumerate(lines[:160]):
            _fields = _line.split("\\t")
            if (len(_fields) == 26 and _fields[1].strip() == "Conf. Date"
                    and "TO Number" in [v.strip() for v in _fields]
                    and "Number of 3S LTs" in [v.strip() for v in _fields]):
                candidates.append((_i, _fields))
        if len(candidates) > 1:
            raise ParseError("ZMM4TR093: multiple candidate headers; refusing ambiguous file")
        if candidates:
            _i, _fields = candidates[0]
            # Only the 11-Nov verified 26-position layout has these placements.
            if (_fields[20].strip() == "Descr." or _fields[25].strip() == "Stor. Bin"):
                if not (_fields[2].strip() == "User" and _fields[4].strip() == "Conf.t."
                        and _fields[5].strip() == "TO Number"
                        and _fields[7].strip() == "TO Item"
                        and _fields[19].strip() == "Material"
                        and _fields[20].strip() in ("Descr.", "Material Description")
                        and _fields[24].strip() in ("Unl. Point", "Unloading Point")
                        and _fields[25].strip() in ("Stor. Bin", "StorageBin")
                        and not _fields[3].strip() and not _fields[6].strip()):
                    raise ParseError("ZMM4TR093: abbreviated headings in unapproved tab layout")
                _fields[20] = "Material Description"
                _fields[25] = "StorageBin"
                lines[_i] = "\\t".join(_fields)
'''

# The new layer is inserted immediately after the read-only TXT is split into
# lines. Earlier v1.1-1.4 report-specific code follows unchanged.

def patch_source(original: str) -> str:
    if TAG in original:
        raise RuntimeError("This v1.5 patch is already installed")
    missing = [tag for tag in NEEDED_TAGS if tag not in original]
    if missing:
        raise RuntimeError(f"Required prior parser updates not found: {missing}")
    if original.count(ANCHOR) != 1:
        raise RuntimeError("Expected parser insertion point is missing/ambiguous")
    updated = original.replace(ANCHOR, ANCHOR + COMPAT, 1)
    compile(updated, "processing/parser.py", "exec")
    return updated


def in_memory_parser(source: str):
    module = types.ModuleType("_datahub_lrf2_tr093_v15_preview")
    module.__file__ = "processing/parser.py"
    sys.modules[module.__name__] = module
    try:
        exec(compile(source, module.__file__, "exec"), module.__dict__)
        return module
    finally:
        sys.modules.pop(module.__name__, None)


def columns_from_schema(path: Path) -> list[str]:
    doc = json.loads(path.read_text(encoding="utf-8-sig"))
    return [c["name"] if isinstance(c, dict) else c for c in doc["columns"]]


def verify_raw(parser, job: str, path: Path):
    if not path.is_file():
        raise RuntimeError(f"Missing test TXT: {path}")
    parsed = parser.parse_file(path, job)
    if not parsed.rows or parsed.no_data:
        raise RuntimeError(f"{job}: expected a populated sample, got {len(parsed.rows)} rows")
    if job == "lrf2":
        expected = ["user_name", "queue", "document", "p"]
    else:
        expected = ["conf_date", "user", "conf_t", "to_number", "to_item", "src_st_typ",
                    "source_bin", "dest_st_ty", "dest_bin", "queue", "number_of_3s_lts",
                    "number_of_4s_lts", "tot_recor", "addit_no", "dest_qty", "dest_qty__2",
                    "material", "material_description", "batch", "order", "to_prio",
                    "unloading_point", "storagebin"]
    if parsed.headers != expected:
        diffs = [(i, a, b) for i, (a, b) in enumerate(zip(parsed.headers, expected), 1) if a != b]
        raise RuntimeError(f"{job}: candidate schema != approved contract; differences={diffs}, lengths={len(parsed.headers)}/{len(expected)}")
    if len(parsed.rows) != parsed.row_count or any(len(r) != len(expected) for r in parsed.rows):
        raise RuntimeError(f"{job}: inconsistent row lengths")
    print(f"PASS {job}: {len(parsed.rows)} records / {len(parsed.headers)} columns / approved stable names")
    return expected


def check_published(root: Path, jid: str, expected: list[str]):
    config = json.loads((root / "config.json").read_text(encoding="utf-8-sig"))
    publish = Path(config["storage"]["publish_root"])
    target = publish / "Live" / jid
    schema_path = target / f"{jid}_schema.json"
    csv_path = target / f"{jid}_latest.csv"
    if not publish.is_dir():
        raise RuntimeError(f"Configured publishing root inaccessible: {publish}")
    if schema_path.is_file() and csv_path.is_file():
        actual = columns_from_schema(schema_path)
        with csv_path.open("r", encoding="utf-8-sig", newline="") as stream:
            csv_header = next(csv.reader(stream))
        if actual != csv_header:
            raise RuntimeError(f"{jid}: existing Live CSV and JSON do not agree")
        if actual != expected:
            raise RuntimeError(f"{jid}: published schema differs from verified contract: stored={actual}; expected={expected}")
        print(f"PASS {jid}: W: Live CSV/schema agree with approved stable names")
    elif schema_path.exists() or csv_path.exists():
        raise RuntimeError(f"{jid}: only one of Live CSV/schema exists; review first")
    else:
        print(f"WARNING {jid}: no published Live pair; cannot verify against W: (no files changed)")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--hub-root", required=True, type=Path)
    ap.add_argument("--lrf2", required=True, type=Path, help="Newest failed LRF2 TXT")
    ap.add_argument("--tr093", required=True, type=Path, help="Newest failed ZMM4TR093 TXT")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = ap.parse_args()
    source_path = args.hub_root / "processing" / "parser.py"
    if not source_path.is_file():
        raise SystemExit(f"FAILED: missing parser.py: {source_path}")
    try:
        original = source_path.read_text(encoding="utf-8-sig")
        updated = patch_source(original)
        parser = in_memory_parser(updated)
        for job, raw in (("lrf2", args.lrf2), ("zmm4tr093", args.tr093)):
            headers = verify_raw(parser, job, raw)
            check_published(args.hub_root, job, headers)
    except Exception as exc:
        raise SystemExit(f"FAILED - no changes: {exc}") from None
    print("PASS: patch compatible, both TXT files parsed, published schema verified")
    if args.check:
        print("CHECK ONLY: no files modified")
        return
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_dir = args.hub_root / "runtime" / "kpi_layout_fix_backups" / ("lrf2_tr093_v15_" + stamp)
    backup_dir.mkdir(parents=True, exist_ok=False)
    backup = backup_dir / "parser.py"
    shutil.copy2(source_path, backup)
    staged = source_path.with_name(".parser.py.lrf2_tr093_v15.tmp")
    try:
        staged.write_text(updated, encoding="utf-8", newline="\n")
        os.replace(staged, source_path)
    finally:
        staged.unlink(missing_ok=True)
    print(f"INSTALLED: {source_path}")
    print(f"BACKUP: {backup}")
    print("No original Raw TXT, published CSV, schema JSON, History or app.py was modified")


if __name__ == "__main__":
    main()
