"""One-step, fail-closed Shared SAP Data Hub schema-stability installer.

Combines the verified LRF2/ZMM4TR093 header changes with the centrally pinned
published schema-contract layer. Requires the previously installed v1.4 ZSD
semantic parser; never replaces the entire Data Hub app/parser with a template.
No third-party dependencies, SAP invocation, or network calls.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import types

from patch_lrf2_tr093 import TAG as V15_TAG, patch_source as patch_v15
from schema_contracts import (_column_names, _read_csv_headers, _read_json,
                              align_staged_to_live)

HERE = Path(__file__).resolve().parent
APP_IMPORT = "from processing.parser import ParseError, process_to_csv\n"
ADAPTER_IMPORT = "from processing.schema_contracts import align_staged_to_live\n"
STAGE_ANCHOR = "        summary = process_to_csv(source, jid, staged_csv, staged_metadata)\n"
STAGE_INSERT = "        summary = align_staged_to_live(ROOT, publish_root, jid, staged_csv, staged_metadata, summary)\n"
REQUIRED_PREVIOUS_TAG = "KPI_ZSD_SEMANTIC_LAYOUT_V14"
CONTRACT_DIR = "schema_contracts"
MOD_PATH = "processing/schema_contracts.py"
MANIFEST_KEY = "combined_schema_v2"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parser_module(source: str):
    name = "_datahub_unified_schema_preview"
    module = types.ModuleType(name)
    module.__file__ = "processing/parser.py"
    sys.modules[name] = module
    try:
        exec(compile(source, module.__file__, "exec"), module.__dict__)
        return module
    finally:
        sys.modules.pop(name, None)


def patch_app(source: str) -> tuple[str, bool]:
    has_imp = ADAPTER_IMPORT in source
    has_call = STAGE_INSERT in source
    if has_imp != has_call:
        raise RuntimeError("app.py contains a partial schema-contract modification; manual review required")
    if has_imp:
        return source, False
    if source.count(APP_IMPORT) != 1 or source.count(STAGE_ANCHOR) != 1:
        raise RuntimeError("app.py staging anchors not recognised; refusing to replace controller")
    patched = source.replace(APP_IMPORT, APP_IMPORT + ADAPTER_IMPORT, 1)
    patched = patched.replace(STAGE_ANCHOR, STAGE_ANCHOR + STAGE_INSERT, 1)
    compile(patched, "app.py", "exec")
    return patched, True


def get_config(root: Path) -> tuple[dict, Path]:
    cfg = _read_json(root / "config.json")
    jobs = cfg.get("jobs")
    if not isinstance(jobs, list) or not jobs or any("id" not in j for j in jobs):
        raise RuntimeError("Unrecognised config.json jobs")
    out = cfg.get("storage", {}).get("publish_root")
    if not isinstance(out, str) or not out:
        raise RuntimeError("No configured publish root")
    publish = Path(out)
    if not publish.is_dir():
        raise RuntimeError(f"Published root is unavailable: {publish} (check W: mapping)")
    return cfg, publish


def live_schema(publish: Path, jid: str) -> list[str] | None:
    base = publish / "Live" / jid
    meta = base / f"{jid}_schema.json"
    csv_file = base / f"{jid}_latest.csv"
    if meta.is_file() != csv_file.is_file():
        raise RuntimeError(f"{jid}: Live CSV/schema JSON incomplete; please investigate before install")
    if not meta.is_file():
        return None
    names = _column_names(_read_json(meta).get("columns"), str(meta))
    csv_names = _read_csv_headers(csv_file)
    if names != csv_names:
        raise RuntimeError(f"{jid}: Live CSV and JSON have different field names; no changes made")
    return names


def pinned_baselines(cfg: dict, publish: Path) -> tuple[dict[str,list[str]],list[str]]:
    got, missing = {}, []
    for j in cfg["jobs"]:
        jid = j["id"]
        names = live_schema(publish, jid)
        if names is None:
            missing.append(jid)
        else:
            got[jid] = names
    return got, missing


def verify_two_reports(parser, baselines: dict[str,list[str]], test_files: dict[str,Path]) -> None:
    for jid, raw in test_files.items():
        result = parser.parse_file(raw, jid)
        if result.no_data or not result.rows:
            raise RuntimeError(f"{jid}: bundled test report unexpectedly empty")
        if any(len(r) != len(result.headers) for r in result.rows):
            raise RuntimeError(f"{jid}: incorrect row width")
        expected = (['user_name', 'queue', 'document', 'p'] if jid == 'lrf2'
                    else ['conf_date', 'user', 'conf_t', 'to_number', 'to_item',
                          'src_st_typ', 'source_bin', 'dest_st_ty', 'dest_bin',
                          'queue', 'number_of_3s_lts', 'number_of_4s_lts',
                          'tot_recor', 'addit_no', 'dest_qty', 'dest_qty__2',
                          'material', 'material_description', 'batch', 'order',
                          'to_prio', 'unloading_point', 'storagebin'])
        if result.headers != expected:
            raise RuntimeError(f"{jid}: verified layout does not generate the intended published field names")
        live = baselines.get(jid)
        if live is not None and live != expected:
            raise RuntimeError(f"{jid}: actual W: Live schema differs from known layout; "+
                               f"stored={live}, expected={expected}. Do not force.")
        print(f"  PASS {jid:12}: {len(result.rows)} bundled sample row(s), {len(result.headers)} stable fields" +
              (" (matched W: Live)" if live else " (no Live schema yet)"))


def check_contracts_if_present(root: Path, baselines: dict[str, list[str]]):
    directory = root / CONTRACT_DIR
    module = root / MOD_PATH
    if directory.exists() != module.exists():
        raise RuntimeError("Partial existing central schema-contract installation; manual review needed")
    if not directory.exists():
        return False
    if not (directory / 'aliases.json').is_file():
        raise RuntimeError("Central contract alias registry missing")
    registry = _read_json(directory / 'aliases.json')
    if registry.get('version') != 1 or not isinstance(registry.get('jobs'),dict):
        raise RuntimeError("Unrecognised existing alias registry")
    required = _read_json(HERE / 'aliases.json')['jobs']
    for jid, groups in required.items():
        actual = registry['jobs'].get(jid, [])
        for group in groups:
            if group not in actual and list(reversed(group)) not in actual:
                raise RuntimeError(f"Existing central schema-contract registry lacks approved alias {jid}: {group}")
    for jid, names in baselines.items():
        contract = directory / f'{jid}.json'
        if not contract.is_file():
            # A newly published job can be enrolled with the existing installer.
            print(f"  NOTICE {jid}: Live exists, but no pinned contract yet; not overwriting")
            continue
        doc = _read_json(contract)
        if (doc.get('contract_version') != 1 or doc.get('job_id') != jid or
                _column_names(doc.get('columns'), str(contract)) != names):
            raise RuntimeError(f"{jid}: pinned contract differs from Live; manual review required")
    return True


def preflight_raw(publish: Path, parser, baselines: dict[str,list[str]]):
    issues = []
    print("\nLast-published Raw preflight (historical snapshots, NOT today's failed TXT):")
    for jid, locked in baselines.items():
        raw = publish / 'Raw' / jid / f'{jid}_latest.txt'
        if not raw.is_file():
            print(f"  SKIP {jid:26} no last-published Raw TXT")
            continue
        try:
            parsed = parser.parse_file(raw, jid)
            fields = parsed.headers
            if fields == locked:
                print(f"  PASS {jid:26} {len(parsed.rows):6} rows, {len(fields):3} fields")
            else:
                indices = [(i, a, b) for i,(a,b) in enumerate(zip(locked, fields),1) if a!=b]
                print(f"  REVIEW {jid:24} named field differences: {indices[:4]}, width {len(locked)}/{len(fields)}")
                issues.append(jid)
        except Exception as exc:
            print(f"  REVIEW {jid:24} {str(exc)[:140]}")
            issues.append(jid)
    return issues


def validate(root: Path) -> dict:
    if not root.is_dir():
        raise RuntimeError(f"Data Hub root does not exist: {root}")
    parser_file = root / 'processing' / 'parser.py'
    app_file = root / 'app.py'
    if not parser_file.is_file() or not app_file.is_file():
        raise RuntimeError("Expected Data Hub app.py and processing/parser.py not found")
    parser_source = parser_file.read_text(encoding='utf-8-sig')
    app_source = app_file.read_text(encoding='utf-8-sig')
    if REQUIRED_PREVIOUS_TAG not in parser_source:
        raise RuntimeError("The verified v1.4 ZSD3TR009 parser fix is missing. Refusing to guess how to upgrade this parser.")
    parser_changed = V15_TAG not in parser_source
    if parser_changed:
        parser_new = patch_v15(parser_source)
    else:
        parser_new = parser_source
    compile(parser_new, str(parser_file), 'exec')
    app_new, app_changed = patch_app(app_source)
    parser = parser_module(parser_new)
    cfg, publish = get_config(root)
    baselines, missing = pinned_baselines(cfg, publish)
    if not baselines:
        raise RuntimeError("No validated Live schemas found. Cannot establish stable report contracts.")
    existing_contracts = check_contracts_if_present(root, baselines)
    if existing_contracts and app_changed:
        raise RuntimeError("Central contract files exist but app.py does not call them; manual repair needed")
    if not existing_contracts and not app_changed:
        raise RuntimeError("App is already patched but central files are missing; manual repair needed")
    print(f"Data Hub: {root}")
    print(f"Published data: {publish}")
    print(f"Existing Live contracts: {len(baselines)}; missing Live: {len(missing)}")
    if missing:
        print("No Live yet (first publication remains strictly checked): " + ', '.join(missing))
    print(f"Parser v1.5 update: {'APPLY' if parser_changed else 'ALREADY INSTALLED'}")
    print(f"Central schema contracts: {'ALREADY INSTALLED' if existing_contracts else 'INSTALL'}")
    print("\nBundled synthetic (anonymised) fixtures:")
    verify_two_reports(parser, baselines, {
        'lrf2': HERE / 'fixtures/lrf2_renamed_header.txt',
        'zmm4tr093': HERE / 'fixtures/tr093_abbreviated_header.txt',
    })
    print("\nParser API and app.py syntax: PASS")
    issues = preflight_raw(publish, parser, baselines)
    if issues:
        print("\nNOTICE: older Raw files with current parser differences: " + ', '.join(issues))
        print("These are NOT automatically approved; sample/check exact failed Raw before re-enabling their schedules.")
    return locals()


def _write_json(path: Path, doc: dict) -> None:
    path.write_text(json.dumps(doc, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def _atomic_text(path: Path, content: str) -> None:
    tmp = path.with_name('.' + path.name + '.combined_tmp')
    try:
        tmp.write_text(content, encoding='utf-8', newline='\n')
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def apply(root: Path, ctx: dict):
    parser_file = ctx['parser_file']; app_file = ctx['app_file']
    cfg = ctx['cfg']; baselines = ctx['baselines']; published = ctx['publish']
    existing = ctx['existing_contracts']
    changed_files = {}
    if ctx['parser_changed']:
        changed_files['processing/parser.py'] = (parser_file, ctx['parser_new'])
    if ctx['app_changed']:
        changed_files['app.py'] = (app_file, ctx['app_new'])
    if not changed_files and existing:
        print('Already installed. No changes necessary. You may run --audit-all.')
        return

    stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup = root / 'runtime' / 'schema_contract_backups' / ('unified_v2_' + stamp)
    backup.mkdir(parents=True, exist_ok=False)
    record = {'package': MANIFEST_KEY, 'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'changed_files': {}, 'new_files': [], 'backup_dir': str(backup)}
    for name, (path, _) in changed_files.items():
        dest = backup / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
        record['changed_files'][name] = {'before_sha256': digest(path)}
    _write_json(backup / 'manifest.json', record)

    created = []
    try:
        # Install central code/config before app.py imports it. Controller must be stopped.
        if not existing:
            reg = root / CONTRACT_DIR
            reg.mkdir(exist_ok=False)
            created.append(reg)
            shutil.copy2(HERE / 'aliases.json', reg / 'aliases.json')
            for jid, names in baselines.items():
                _write_json(reg / f'{jid}.json', {
                    'contract_version': 1, 'job_id': jid, 'columns': names,
                })
            module = root / MOD_PATH
            shutil.copy2(HERE / 'schema_contracts.py', module)
            created.append(module)
        # Apply parser first, app last. Only known anchor text is modified.
        for name in ('processing/parser.py', 'app.py'):
            if name in changed_files:
                path, content = changed_files[name]
                _atomic_text(path, content)
                record['changed_files'][name]['after_sha256'] = digest(path)
        record['new_files'] = [str(x.relative_to(root)) for x in created]
        _write_json(backup / 'manifest.json', record)
    except BaseException:
        for name, info in record['changed_files'].items():
            original = backup / name
            target = root / name
            if original.is_file():
                shutil.copy2(original, target)
        for target in reversed(created):
            if target.is_dir():
                shutil.rmtree(target)
            else:
                target.unlink(missing_ok=True)
        raise
    print('\nINSTALLED: combined Data Hub stability patch')
    print('BACKUP: ' + str(backup))
    print('Live/History/Raw/Power BI and config.json were not modified.')
    print('Restart controller with scheduling paused; run LRF2 and TR093 pilots, then ZSD3TR009.')


def audit_job(root: Path, jid: str, raw: Path | None):
    cfg, publish = get_config(root)
    if jid not in [j['id'] for j in cfg['jobs']]:
        raise RuntimeError(f'Unknown job {jid}')
    candidate = raw or (publish / 'Raw' / jid / f'{jid}_latest.txt')
    if not candidate.is_file():
        raise RuntimeError(f'Missing raw TXT: {candidate}')
    source = (root / 'processing/parser.py').read_text(encoding='utf-8-sig')
    parser = parser_module(source)
    with tempfile.TemporaryDirectory(prefix='hub_schema_audit_') as tmp:
        tmp = Path(tmp)
        summary = parser.process_to_csv(candidate, jid, tmp/'staged.csv', tmp/'staged.json')
        if not (root / MOD_PATH).is_file():
            raise RuntimeError('Central schema-contract module is not installed')
        # Use the installation's own code and pinned contracts for the real audit.
        spec = importlib.util.spec_from_file_location('_installed_schema_contracts_audit', root / MOD_PATH)
        installed = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(installed)
        adjusted = installed.align_staged_to_live(root, publish, jid, tmp/'staged.csv',
                                                  tmp/'staged.json', summary, dry_run=True)
        old = [c['name'] for c in summary['columns']]
        new = [c['name'] for c in adjusted['columns']]
        print(f"PASS {jid}: {summary['row_count']} records, {len(old)} columns; " +
              ('approved alias/reorder applied' if old != new else 'stable published schema'))
        if old != new:
            print('Approved translation:')
            print('  ' + '; '.join(f'{a} -> {b}' for a,b in zip(old,new) if a!=b))


def rollback(root: Path, directory: Path):
    manifest = _read_json(directory/'manifest.json')
    if manifest.get('package') != MANIFEST_KEY:
        raise RuntimeError('Not a backup from this consolidated installer')
    targets = manifest.get('changed_files',{})
    for name, info in targets.items():
        path = root/name
        before = directory/name
        if not path.is_file() or not before.is_file():
            raise RuntimeError(f'Missing {name}: cannot rollback')
        if digest(path) != info.get('after_sha256'):
            raise RuntimeError(f'{name} changed since installation; refusing unsafe rollback')
        if digest(before) != info.get('before_sha256'):
            raise RuntimeError(f'Backup {name} checksum failed')
    # If new modules changed since install, avoid deleting them.
    for name in manifest.get('new_files',[]):
        if not (root/name).exists():
            raise RuntimeError(f'Expected installed resource absent: {name}')
    for name in targets:
        path = root/name
        temp = path.with_name('.' + path.name + '.unified_rollback_tmp')
        try:
            shutil.copyfile(directory/name, temp)
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)
    # Leave contract resources in place: safely unused when original app restored.
    print('ROLLED BACK patched app/parser files. Pinned schema files remain (unused if app restored).')
    print('Restart the Data Hub controller to pick up restored files.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--hub-root',type=Path,required=True)
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--check',action='store_true',help='Read-only compatibility and sample checks')
    group.add_argument('--apply',action='store_true',help='Back up and atomically install all required changes')
    group.add_argument('--audit-all',action='store_true',help='Audit every published job against saved last Raw TXT')
    group.add_argument('--audit-job',metavar='JOB',help='Read-only check of one job and optional explicit TXT')
    group.add_argument('--rollback',type=Path,metavar='BACKUP_DIR')
    p.add_argument('--raw',type=Path,help='Explicit TXT for --audit-job')
    args=p.parse_args()
    if args.raw and not args.audit_job:
        p.error('--raw requires --audit-job')
    root=args.hub_root.resolve()
    try:
        if args.check or args.apply:
            ctx=validate(root)
            if args.check:
                print('\nCHECK ONLY: No Data Hub or W: files modified.')
            else:
                apply(root,ctx)
        elif args.rollback:
            rollback(root,args.rollback.resolve())
        elif args.audit_job:
            audit_job(root,args.audit_job,args.raw)
        else:
            cfg,publish=get_config(root)
            issues=[]
            for jid in [j['id'] for j in cfg['jobs']]:
                try:
                    audit_job(root,jid,None)
                except Exception as e:
                    issues.append(jid)
                    print(f'REVIEW {jid}: {e}')
            print(f'\nAUDIT COMPLETE: {len(cfg["jobs"])-len(issues)}/{len(cfg["jobs"])} matched, {len(issues)} to review.')
    except Exception as exc:
        print(f'FAILED (installation aborted or rollback needed): {exc}',file=sys.stderr)
        raise SystemExit(1)

if __name__=='__main__':
    main()
