# Shared SAP Data Hub: source review collector v1

This is a **read-only collection tool**. It does not change Data Hub code, configuration, schedules, W: Live or History, or SAP exports. It makes a small ZIP containing the installed source files we need to design and verify the central ingestion-stability fix.

## Run it

1. Extract this folder to `C:\DataHub_Stability_Collector`.
2. Double-click `RUN_COLLECTION.cmd`, or run:

   ```bat
   cd /d "C:\DataHub_Stability_Collector"
   py -3 collect_datahub_source.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main"
   ```
3. When it finishes, a file named `DataHub_Source_Review_YYYYMMDD_HHMMSS.zip` will appear in the same folder.
4. **Review the ZIP contents before uploading.** Please upload that ZIP in the conversation. If source files contain any hard-coded credentials or sensitive information, do not upload them without removing those details.

## Included

- `app.py`, `history.py`, `schema_contracts.py` where present
- Python files directly under `processing/`, `exporters/` and `tests/`
- Approved alias lists and pinned schema JSONs under `schema_contracts/`
- A **filtered** summary of job IDs, refresh intervals, strict-schema and reconciliation switches (never the full config)
- Source file hashes to identify the exact installed build

## Excluded by design

The script never copies `config.json` verbatim, credentials, state, full logs, SAP TXT, Excel or CSV exports, `runtime`, `Live`, `Raw`, or `History`. It doesn't access the W: drive and doesn't make network requests.

## What happens next

After reviewing this installed source alongside the saved SAP exports, we can construct and regression-test **one** controlled patch that handles known heading abbreviations and wrapping without relaxing data validation. The remaining DockToStock exporter error will need its failed-run log, which this tool deliberately does **not** collect.

No need to stop Data Hub or apply another patch just to run this collector. The later installation will be separate and gated by check-only validation, backup and rollback.
