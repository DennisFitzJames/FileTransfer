@echo off
setlocal
set "HUB=C:\Users\EB013665\DataHub\DataHub-main"
if not "%~1"=="" set "HUB=%~1"
py -3 "%~dp0collect_datahub_source.py" --hub-root "%HUB%"
if errorlevel 1 (
  echo Collection failed. No Data Hub files were changed.
) else (
  echo.
  echo The DataHub_Source_Review_*.zip is beside this script.
  echo Please review the ZIP before uploading it to ChatGPT.
)
pause
