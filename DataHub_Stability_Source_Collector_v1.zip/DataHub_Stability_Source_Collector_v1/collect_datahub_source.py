#!/usr/bin/env python3
"""Create a read-only, code-only review bundle for the SAP Data Hub.

No network calls. Does not edit the Data Hub. Excludes raw data, runtime,
logs, CSV, Excel, confidential full config and credentials by design.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile

VERSION = "1.0"
DEFAULT_ROOT = r"C:\Users\EB013665\DataHub\DataHub-main"
MAX_FILE_BYTES = 2_000_000
MAX_FILES = 150

# Explicit allowlist. Never recurse through an arbitrary source directory.
DIRECT_FILES = (
    "app.py",
    "history.py",
    "schema_contracts.py",
    "requirements.txt",
)
PYTHON_FOLDERS = ("processing", "exporters", "tests")
CONTRACT_FOLDER = "schema_contracts"


def sha256(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()


def narrow_public_config(config: dict) -> dict:
    """Only operational switches, never paths, users, commands or credentials."""
    out: dict = {"note": "Filtered settings only; original config.json NOT included."}
    for section, allowed in {
        "processing": ("enabled", "strict_schema"),
        "history": ("enabled", "auto_reconcile_previous_day", "reconcile_hour_local"),
        "snapshots": ("enabled", "capture_after_local"),
        "scheduler": ("paused",),
    }.items():
        val = config.get(section)
        if isinstance(val, dict):
            selected = {k: val[k] for k in allowed if k in val and isinstance(val[k], (bool, str, int, float, type(None)))}
            if selected:
                out[section] = selected
    history = config.get("history", {})
    if isinstance(history, dict) and isinstance(history.get("jobs"), dict):
        out.setdefault("history", {})["jobs"] = {
            str(job): {"enabled": opts["enabled"]}
            for job, opts in history["jobs"].items()
            if isinstance(opts, dict) and isinstance(opts.get("enabled"), bool)
        }
    jobs = config.get("jobs", [])
    if isinstance(jobs, list):
        out["jobs"] = [
            {k: item[k] for k in ("id", "enabled", "refresh_minutes")
             if k in item and isinstance(item[k], (str, bool, int, float))}
            for item in jobs if isinstance(item, dict)
        ]
    return out


def safe_relative_files(root: Path):
    found = {}
    for item in DIRECT_FILES:
        candidate = root / item
        if candidate.is_file() and not candidate.is_symlink():
            found[item] = candidate
    for folder in PYTHON_FOLDERS:
        base = root / folder
        if base.is_dir() and not base.is_symlink():
            for file in sorted(base.glob("*.py")):
                if file.is_file() and not file.is_symlink():
                    found[file.relative_to(root).as_posix()] = file
    contract_root = root / CONTRACT_FOLDER
    if contract_root.is_dir() and not contract_root.is_symlink():
        for file in sorted(contract_root.glob("*.json")):
            if file.is_file() and not file.is_symlink():
                found[file.relative_to(root).as_posix()] = file
    return found


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only Data Hub code collector (no export data or passwords)")
    parser.add_argument("--hub-root", default=DEFAULT_ROOT, help="Local Data Hub source folder")
    parser.add_argument("--output", default="", help="Optional output ZIP path")
    args = parser.parse_args()
    root = Path(args.hub_root).expanduser().resolve()
    for required in ("app.py", "processing/parser.py", "exporters/runner.py"):
        if not (root / required).is_file():
            print(f"ERROR: Missing {required} in {root}", file=sys.stderr)
            return 2
    output = Path(args.output).expanduser().resolve() if args.output else (
        Path(__file__).resolve().parent / f"DataHub_Source_Review_{dt.datetime.now():%Y%m%d_%H%M%S}.zip"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    paths = safe_relative_files(root)
    if len(paths) > MAX_FILES:
        print(f"ERROR: Too many source files ({len(paths)}), refusing archive", file=sys.stderr)
        return 2
    objects = {}
    manifest = {
        "collector_version": VERSION,
        "created_at_local": dt.datetime.now().isoformat(timespec="seconds"),
        "purpose": "Review currently installed Data Hub source before designing a compatibility patch",
        "code_only": True,
        "excluded": ["config.json", "runtime/", "logs/", "Raw/", "Live/", "History/", "*.csv", "*.xlsx", "*.txt", "credentials", "state.json"],
        "files": [],
        "warnings": [],
    }
    for name, path in sorted(paths.items()):
        stat = path.stat()
        if stat.st_size > MAX_FILE_BYTES:
            manifest["warnings"].append(f"Skipped {name}: file too large ({stat.st_size} bytes)")
            continue
        blob = path.read_bytes()
        # Prevent arbitrary binary code in the bundle; only UTF-8 text sources.
        try:
            blob.decode("utf-8-sig")
        except UnicodeError:
            manifest["warnings"].append(f"Skipped {name}: not UTF-8 text")
            continue
        objects[f"datahub_code/{name}"] = blob
        manifest["files"].append({"path": name, "bytes": len(blob), "sha256": sha256(blob)})
    cfg_path = root / "config.json"
    if cfg_path.is_file():
        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8-sig"))
            if isinstance(cfg, dict):
                config_public = narrow_public_config(cfg)
                objects["config_safe_summary.json"] = (json.dumps(config_public, indent=2) + "\n").encode("utf-8")
            else:
                manifest["warnings"].append("config.json is not an object; no summary included")
        except (OSError, ValueError) as exc:
            manifest["warnings"].append(f"Could not safely summarise config.json: {type(exc).__name__}")
    else:
        manifest["warnings"].append("No config.json found")
    manifest["file_count"] = len(manifest["files"])
    objects["MANIFEST.json"] = (json.dumps(manifest, indent=2) + "\n").encode("utf-8")
    objects["README.txt"] = (
        "READ-ONLY SAP DATA HUB CODE REVIEW BUNDLE\n\n"
        "Contains selected Python source, schema-contract JSON files, and an intentionally\n"
        "filtered settings summary. It does NOT include the full config.json, credentials,\n"
        "SAP TXT/CSV data, logs, History, Live, or runtime state.\n\n"
        "Review the ZIP contents for sensitive information before uploading it.\n"
        "The full Data Hub was not changed by this collection.\n"
    ).encode("utf-8")
    if output.exists():
        print(f"ERROR: Refusing to overwrite existing ZIP: {output}", file=sys.stderr)
        return 2
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as zf:
        for name, blob in sorted(objects.items()):
            zf.writestr(name, blob)
    print("SUCCESS: Read-only collection complete.")
    print(f"Data Hub source: {root}")
    print(f"Selected source files: {len(manifest['files'])}")
    print(f"ZIP to upload: {output}")
    print("Excluded: full config, credentials, raw SAP data, logs, Live/History, state")
    if manifest["warnings"]:
        print("Warnings:")
        for warning in manifest["warnings"]:
            print(f"  - {warning}")
    print("Please REVIEW the ZIP contents before uploading.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
