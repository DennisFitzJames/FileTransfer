#!/usr/bin/env python3
"""Read-only logistics KPI date coverage audit.

Does not alter SAP, Data Hub, legacy caches, or Power BI. Only writes --report if supplied.
Requires Python 3.9+ and standard library only.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import re
import sys
from pathlib import Path

JOBS = (
    ('lx03', 'LX03', 'SNAPSHOT'),
    ('zmm4tb020', 'ZMM4TB020', 'SNAPSHOT'),
    ('zsd3tr009', 'ZSD3TR009', 'SNAPSHOT'),
    ('zbmt', 'ZBMT', 'SNAPSHOT'),
    ('zmm4tr093', 'ZMM4TR093', 'DATE'),
    ('zmm4tr003', 'ZMM4TR003', 'DATE'),
    ('dock_to_stock', 'ZMM4TR083', 'DATE'),
    ('mb51', 'MB51', 'DATE'),
    ('lt22', 'LT22', 'DATE'),
    ('zmm4tr012', 'ZMM4TR012', 'DATE'),
)
DEFAULT_HUB = r'W:\Departments\SAPTemplatesAndTools\Shared SAP Exports\History'
DEFAULT_CACHE = r'W:\Departments\SAPTemplatesAndTools\KPI PowerBI Cache'
DAY = dt.timedelta(days=1)


def parse_date(s: str) -> dt.date:
    s = str(s).strip().lstrip('\ufeff')
    if 'T' in s:
        s = s.split('T')[0]
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d.%m.%Y'):
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    raise ValueError('Unrecognised date: '+repr(s))


def days(start: dt.date, end: dt.date):
    d = start
    while d <= end:
        yield d
        d += DAY


def read_manifest(path: Path) -> dict[str, set[dt.date]]:
    # File produced by the original Logistics KPI legacy converter.
    result = {j: set() for j, _, _ in JOBS}
    alias = {label.upper(): job for job, label, _ in JOBS}
    with path.open('r', encoding='utf-8-sig', newline='') as h:
        reader = csv.DictReader(h)
        required = {'report', 'date', 'status'}
        if not required.issubset(reader.fieldnames or []):
            raise RuntimeError(f'{path}: expected columns {sorted(required)}')
        for row in reader:
            if row['status'].upper() != 'CONVERTED':
                continue
            report = row['report'].upper().strip()
            jid = alias.get(report)
            if jid is None:
                continue
            try:
                result[jid].add(parse_date(row['date']))
            except ValueError as e:
                raise RuntimeError(f'{path}: invalid manifest date for {report}: {e}') from e
    return result


def read_cache_dates(root: Path) -> dict[str, set[dt.date]]:
    result = {j: set() for j, _, _ in JOBS}
    for jid in result:
        p = root / (jid + '_legacy.csv')
        if not p.is_file():
            raise RuntimeError(f'Missing legacy cache CSV: {p}')
        with p.open('r', encoding='utf-8-sig', newline='') as h:
            rows = csv.reader(h)
            try:
                names = next(rows)
                idx = names.index('SnapshotDate')
            except (StopIteration, ValueError) as e:
                raise RuntimeError(f'{p}: missing SnapshotDate header') from e
            for i, row in enumerate(rows, 2):
                if len(row) <= idx:
                    raise RuntimeError(f'{p}: short row at line {i}')
                try:
                    result[jid].add(parse_date(row[idx]))
                except ValueError as e:
                    raise RuntimeError(f'{p}: invalid SnapshotDate at line {i}: {e}') from e
    return result


def read_hub_dates(root: Path) -> tuple[dict[str, dict[dt.date, str]], dict[str, dict]]:
    found = {}
    details = {}
    for jid, _, _ in JOBS:
        found[jid], details[jid] = {}, {}
        folder = root / jid
        if not folder.exists():
            continue
        if not folder.is_dir():
            raise RuntimeError(f'Not a directory: {folder}')
        by_date: dict[dt.date, set[str]] = {}
        paths = {}
        for p in folder.rglob('*'):
            if not p.is_file() or p.suffix.lower() not in ('.csv', '.json'):
                continue
            m = re.fullmatch(re.escape(jid) + r'_(\d{4}-\d{2}-\d{2})\.(csv|json)', p.name, re.I)
            if not m:
                continue
            d = parse_date(m.group(1))
            by_date.setdefault(d, set()).add(m.group(2).lower())
            if m.group(2).lower() == 'json':
                paths[d] = p
        for d, suffixes in by_date.items():
            status = 'HUB' if suffixes == {'csv','json'} else 'INCOMPLETE'
            found[jid][d] = status
            if status == 'HUB':
                try:
                    metadata = json.loads(paths[d].read_text(encoding='utf-8-sig'))
                    details[jid][d] = metadata
                    expected_date = metadata.get('report_date') or metadata.get('snapshot_date')
                    if expected_date and parse_date(expected_date) != d:
                        found[jid][d] = 'METADATA_MISMATCH'
                except (OSError, ValueError, json.JSONDecodeError) as e:
                    found[jid][d] = 'INVALID_JSON'
                    details[jid][d] = {'error': str(e)}
    return found, details


def config_status(hub_root: Path | None) -> list[str]:
    if hub_root is None:
        return ['Data Hub config not supplied; cannot confirm previous-day reconciliation settings.']
    p = hub_root / 'config.json'
    if not p.is_file():
        return [f'Data Hub config not found at {p}']
    try:
        cfg = json.loads(p.read_text(encoding='utf-8-sig'))
        h = cfg.get('history', {})
        s = cfg.get('snapshots', {})
        return [
            f'history.enabled = {h.get("enabled", "NOT_SET")}',
            f'history.auto_reconcile_previous_day = {h.get("auto_reconcile_previous_day", "NOT_SET")}',
            f'history.reconcile_hour_local = {h.get("reconcile_hour_local", "NOT_SET")}',
            f'history.jobs.zmm4tr093.enabled = {h.get("jobs", {}).get("zmm4tr093", {}).get("enabled", "NOT_SET")}',
            f'snapshots.enabled = {s.get("enabled", "NOT_SET")}',
            f'snapshots.capture_after_local = {s.get("capture_after_local", "NOT_SET")}',
        ]
    except (OSError, ValueError) as e:
        return [f'Cannot read Data Hub config: {e}']


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--history-root', default=DEFAULT_HUB, help='Shared SAP Exports\\History')
    src = p.add_mutually_exclusive_group()
    src.add_argument('--manifest', help='Original migration_manifest.csv with CONVERTED rows')
    src.add_argument('--legacy-cache-root', help='Folder with <job>_legacy.csv; larger/slower')
    p.add_argument('--hub-root', help='Local DataHub-main directory for config checks')
    p.add_argument('--cutover', default='2026-11-07', help='Global Power BI cutover date YYYY-MM-DD')
    p.add_argument('--start', default='2026-11-04')
    p.add_argument('--end', default=(dt.date.today()-DAY).isoformat())
    p.add_argument('--weekdays-only', action='store_true', help='Do not list Saturdays and Sundays as gaps')
    p.add_argument('--report', help='Optional output TXT on local disk (never in publish folders)')
    args = p.parse_args(argv)
    start, end, cutover = map(parse_date, (args.start, args.end, args.cutover))
    if start > end:
        p.error('--start must not be after --end')
    root = Path(args.history_root)
    if not root.is_dir():
        p.error(f'Cannot access Data Hub History root: {root}')
    if args.manifest:
        old = read_manifest(Path(args.manifest))
        legacy_source = f'legacy manifest: {args.manifest}'
    else:
        old_root = Path(args.legacy_cache_root or DEFAULT_CACHE)
        if not old_root.is_dir():
            p.error(f'Cannot access legacy cache: {old_root}. Supply --manifest or --legacy-cache-root.')
        old = read_cache_dates(old_root)
        legacy_source = f'legacy cache: {old_root}'
    hub, details = read_hub_dates(root)
    lines = [
        'LOGISTICS KPI READ-ONLY DATE COVERAGE AUDIT',
        f'History: {root}',
        f'Legacy source: {legacy_source}',
        f'Cutover: {cutover} | window: {start} to {end} | weekdays only: {args.weekdays_only}',
        '',
        'Data Hub settings:',
        *('  '+x for x in config_status(Path(args.hub_root) if args.hub_root else None)),
        '',
        'Status codes: LEGACY = active legacy day; HUB = complete CSV+JSON; '
        'MISSING = no active file; INCOMPLETE = no valid CSV+JSON pair.',
        'Historical archive dates are evidence of a saved file, not proof a day was operational.',
        ''
    ]
    for jid, display, kind in JOBS:
        old_dates = old[jid]
        hub_dates = hub[jid]
        missing = []
        issues = []
        lines.append(f'[{display} / {jid}] {kind}')
        lines.append(f'  Legacy last date: {max(old_dates).isoformat() if old_dates else "NONE"} | Hub first complete date: {min((d for d,v in hub_dates.items() if v=="HUB"), default=None)}')
        for date in days(start, end):
            if args.weekdays_only and date.weekday() >= 5:
                continue
            day_mode = 'LEGACY' if date < cutover else 'HUB'
            if day_mode == 'LEGACY':
                status = 'LEGACY' if date in old_dates else 'MISSING'
            else:
                status = hub_dates.get(date, 'MISSING')
            if status == 'MISSING':
                missing.append(date)
            elif status not in ('HUB', 'LEGACY'):
                issues.append((date, status))
            notes = ''
            if status == 'HUB' and jid == 'zmm4tr093' and date == end:
                meta = details[jid].get(date, {})
                exported = meta.get('exported_at') or meta.get('captured_at')
                if exported:
                    try:
                        timestamp = dt.datetime.fromisoformat(exported)
                        notes = (' [AFTER-DAY REFRESH]' if timestamp.date() > date else
                                 ' [SAME-DAY; NOT VERIFIED AS FINAL]')
                    except ValueError:
                        notes = f' [unrecognised exported_at={exported}]'
                else:
                    notes = ' [no published export time]'
            lines.append(f'  {date.isoformat()} {date.strftime("%a"):3} {status}{notes}')
        lines.append(f'  Days without active files: {len(missing)}' + (': '+', '.join(str(d) for d in missing) if missing else ''))
        if issues:
            lines.append('  PARTIAL/INVALID FILES: '+', '.join(str(d)+'='+state for d,state in issues))
        if kind == 'SNAPSHOT':
            lines.append('  NOTE: Missing snapshot days cannot be reconstructed from today\'s live state.')
        else:
            lines.append('  NOTE: Date-scoped SAP backfill may recover genuinely missing historical days.')
        lines.append('')
    lines.append('IMPORTANT: An empty but valid report day should have a completed CSV+JSON pair.')
    lines.append('This audit DOES NOT repair, move, or delete data; it does not validate SAP record completeness.')
    report = '\n'.join(lines) + '\n'
    print(report)
    if args.report:
        dest = Path(args.report)
        if dest.resolve().is_relative_to(root.resolve()):
            p.error('--report may not be placed inside the Hub History folder')
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(report, encoding='utf-8')
        print(f'Report saved to {dest}')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, RuntimeError, ValueError, csv.Error) as exc:
        print(f'AUDIT FAILED: {exc}', file=sys.stderr)
        sys.exit(2)
