# Local verification

- `audit_kpi_dates.py` passes Python syntax compilation.
- Ran against the original `migration_manifest.csv`: it reports latest legacy dates of 2026-11-06 for LX03, ZMM4TB020, ZSD3TR009 and ZBMT and 2026-11-05 for the six transaction jobs.
- Synthetic History folders: a complete CSV+JSON pair is `HUB`; a CSV without JSON is `INCOMPLETE`; an absent date is `MISSING`.
- Both legacy manifest and legacy cache modes executed successfully in local synthetic tests; a missing History root causes a nonzero exit code.
- The billing Power Query is based on the exact historical `FactBillings_ZSD3TR009.pq` supplied with the migration package; its field mapping and existing type conversions are preserved, with one new preprocessing step for explicit dot/blank date placeholders.
- Sample SAP TXT files include the `. ..  .` date-like placeholder; this is why an ordinary `type date` conversion can fail.
- **Limitations:** Cannot execute Power BI M engine, SAP GUI or access the user's W: drive in this environment. Test the supplied M query in a backup PBIX and review a subset of business results. This package does not claim to fix current failed parser layouts or exporter exit code 1.
