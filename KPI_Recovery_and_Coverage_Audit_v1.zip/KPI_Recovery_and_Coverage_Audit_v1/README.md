# Logistics KPI — recovery checks (12 November 2026)

**Purpose:** Provide an immediate Power BI date-placeholder correction and a **read-only** audit of legacy vs. Data Hub History coverage. This is **not** another Data Hub parser patch; the latest failed SAP TXT files and the DockToStock exporter log have not been supplied, so it would be unsafe to invent parser fixes.

## A. Fix the Power BI ZSD3TR009 DateFormat error

1. Save a backup copy of your `.pbix`.
2. Power BI Desktop → **Transform data → FactBillings_ZSD3TR009 → Advanced Editor**.
3. Back up the current M code, then paste the entire contents of `PowerQuery/FactBillings_ZSD3TR009_DateSafe.pq`.
4. Refresh the query and check data for `Created on`, `Creation Date`, `Pland Gds Mvmnt Date`, and `SnapshotDate` against the prior version; then Refresh All.

**What changed:** Immediately after `Base = fnKpiHistory(...)`, the replacement query converts only empty or dot/space/tab-only text in the three known date fields to `null`. SAP can export a visually blank date as `. ..  .`. Every other value still goes through the **existing strict** date type conversion. This will not conceal arbitrary malformed or misaligned dates.

If there is another invalid date string, refresh will still fail and you should capture that value and source filename for a separate review. A successful refresh is not evidence that every date in the file is legitimate; check a sample of rows.

## B. Audit date coverage across all 10 KPI reports

Requires Python 3.9+ (the same machine that can read W:). Extract this ZIP to `C:\KPI_Recovery_Audit`.

### Preferred: use the original legacy conversion manifest

If you still have `migration_manifest.csv` from the migration, put a copy at `C:\KPI_Recovery_Audit\migration_manifest.csv` and run:

```bat
cd /d C:\KPI_Recovery_Audit
py -3 audit_kpi_dates.py --manifest "C:\KPI_Recovery_Audit\migration_manifest.csv" --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --start 2026-11-04 --end 2026-11-11 --weekdays-only --report "C:\KPI_Recovery_Audit\coverage_report.txt"
```

### Alternative: use the current legacy Power BI cache

This is slower because it reads the `SnapshotDate` column from every row of the 10 legacy cache CSVs:

```bat
cd /d C:\KPI_Recovery_Audit
py -3 audit_kpi_dates.py --legacy-cache-root "W:\Departments\SAPTemplatesAndTools\KPI PowerBI Cache" --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --start 2026-11-04 --end 2026-11-11 --weekdays-only --report "C:\KPI_Recovery_Audit\coverage_report.txt"
```

The script uses the known shared History path by default:
`W:\Departments\SAPTemplatesAndTools\Shared SAP Exports\History`

If you use a different location, supply `--history-root "<actual History folder>"`. The audit stops rather than quietly claiming every date is missing if the root is not accessible.

Outputs for each report:
- latest available legacy date
- earliest completed Data Hub History date
- date-by-date active coverage under the **currently configured 7 November 2026 cutover**
- missing/incomplete CSV+JSON pairs (a `.csv` without its matching `.json` does **not** count as complete)
- TR093 previous-day manifest's `exported_at` timing when present
- local Data Hub `history`/`snapshots` settings when `--hub-root` is supplied

`--weekdays-only` suppresses weekend gaps; omit it to inspect all calendar days. A missing day may represent a closed warehouse or truly no activity, not necessarily a lost report. Reconcile against business operating days and SAP run logs before classifying it as a defect. Valid **empty** result days should still have a complete CSV+JSON pair.

**Safety:** No SAP sessions are started; no existing source, cache, Live, History or config files are edited. Only `--report` creates a local text report.

### Recovery rules

- **Date-scoped transaction jobs** (`zmm4tr093`, `zmm4tr003`, `dock_to_stock`, `mb51`, `lt22`, `zmm4tr012`): use Data Hub's historical-date/backfill function for individual missing dates, once the corresponding exporter and parser succeed. Inspect each CSV/JSON pair afterward.
- **Point-in-time snapshot jobs** (`lx03`, `zmm4tb020`, `zsd3tr009`, `zbmt`): these cannot generally be recreated for past dates from today's SAP state. Recover from original dated files or backup captures, if they exist; otherwise record the gap clearly rather than fabricate it.
- The first four snapshot jobs capture the **first successful export after 07:00**, not TR093.
- TR093 is **date-scoped**; on each refresh, today's full-day partition is replaced. The optional `history.auto_reconcile_previous_day` enables an additional **next-day** report for all six enabled transaction History jobs. Check its status and SAP load impact before enabling globally. The default config was `false`.
- A next-day TR093 History file is not automatically selected by Power BI. Verify that the report or measures filter the correct `SnapshotDate` (yesterday) for yesterday's KPI view.

## C. Do not treat all four SAP failures as the same issue

| Error | Where it occurs | What is needed |
|---|---|---|
| TR093 abbreviated headings in unapproved tab layout | Report-specific parser | Exact failing raw TXT; confirm safe logical alignment/field identities |
| ZSD3TR009 unapproved continuation panel / missing Expedite | Report-specific parser | Exact failing raw TXT; verify both panels, complete row alignment and last field |
| MB51 `descr` vs. `material_description` | Published schema contract | Exact failing raw TXT; approve **MB51-only** alias only if validated |
| DockToStock exporter exit code 1 | SAP GUI exporter, **before parsing** | `DataHub-main\logs\dock_to_stock_last_run.log`, especially the final traceback/error lines |

The existing strict-schema guard is protecting published data. Do not disable it or manually overwrite Live CSV/History to work around these failures.

## D. Sustainable extraction design

Test one troublesome report (e.g. TR093 or MB51) using **SAP ALV grid technical column IDs** or a stable spreadsheet format rather than display headings; validate data and row counts against the old path in parallel. Dynamic list reports may need their own approach. SAP documents Text with Tabs shortening headings and wrapping problems. A wholesale move to Unconverted TXT is **not** necessary to validate this option and may require rewriting all 17 parsers.

For a full architecture correction, make the parser output immutable business column IDs *after logical data-column alignment*. Keep approved aliases/variants at the extraction boundary, with unknown layout quarantine and a complete reason code rather than cascading hard failures. Retain a verified raw fixture for every approved layout, with nightly parser regression tests and report health monitoring.
