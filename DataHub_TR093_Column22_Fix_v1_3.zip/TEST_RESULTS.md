# Verification — ZMM4TR093 column 22 fix v1.3

The patch was applied to an isolated copy of the v1.2 parser and tested against three genuine ZMM4TR093 TXT files.

| Raw export | Parsed rows | Output fields | Column 22 | Result |
|---|---:|---:|---|---|
| 21 October 2026 (previous baseline) | 247 | 23 | `unloading_point` | Pass |
| 10 November 2026, 11:02 | 623 | 23 | `unloading_point` | Pass |
| 10 November 2026, 11:36 | 767 | 23 | `unloading_point` | Pass |

For each file, the parsed **row values** before and after the fix were compared directly and matched exactly. All 22 other published column names also matched exactly. Both installer paths (`--check` and `--apply`) ran successfully against a disposable Data Hub test installation; a timestamped backup was created on `--apply`.

The only intended field change is ZMM4TR093 column 22: `unl_point` → `unloading_point`, restoring the currently published schema. The user's existing W: drive datasets were not accessed or changed during testing. Final Live publication must be verified on their Data Hub PC.
