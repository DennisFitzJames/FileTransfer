"""Targeted Data Hub ZMM4TR093 schema contract fix (2026-11-10).

Canonicalises only published field 22: unl_point -> unloading_point.
Requires the prior v1.2 SAP layout parser patch. No external dependencies.
"""
from __future__ import annotations

import argparse
import datetime as dt
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import types

TAG = "KPI_TR093_SCHEMA_FIX_20261110_V3"
PREVIOUS_TAG = "KPI_LAYOUT_FIX_20261110_V2"

ANCHOR = '''    published_rows = [[row[pos] for pos in keep_positions] for row in normalised_rows]
    # KPI_LAYOUT_FIX_20261110_V1: normalize both verified ZMM layouts into a
'''

INSERT = '''    published_rows = [[row[pos] for pos in keep_positions] for row in normalised_rows]
    # KPI_TR093_SCHEMA_FIX_20261110_V3: the published schema uses
    # "unloading_point", whereas SAP headings may be "Unl. Point" or
    # "Unloading Point". Preserve the established field name without changing
    # field positions, row values, or other reports' schemas.
    if job_id == "zmm4tr093":
        if (len(published_names) != 23
                or published_names[20] != "to_prio"
                or published_names[21] not in ("unl_point", "unloading_point")
                or published_names[22] != "storagebin"):
            raise ParseError("ZMM4TR093 column 22 is not the verified Unloading Point field; publication refused")
        published_names[21] = "unloading_point"
    # KPI_LAYOUT_FIX_20261110_V1: normalize both verified ZMM layouts into a
'''

EXPECTED_COLUMNS = (
    "conf_date", "user", "conf_t", "to_number", "to_item", "src_st_typ",
    "source_bin", "dest_st_ty", "dest_bin", "queue", "number_of_3s_lts",
    "number_of_4s_lts", "tot_recor", "addit_no", "dest_qty", "dest_qty__2",
    "material", "material_description", "batch", "order", "to_prio",
    "unloading_point", "storagebin",
)


def make_patch(source: str) -> str:
    if TAG in source:
        raise RuntimeError("The v1.3 schema fix is already installed. Nothing was changed.")
    if PREVIOUS_TAG not in source:
        raise RuntimeError("The required v1.2 layout fix was not found. Nothing was changed.")
    if source.count(ANCHOR) != 1:
        raise RuntimeError("The expected parser insertion point was not found exactly once. Nothing was changed.")
    patched = source.replace(ANCHOR, INSERT, 1)
    compile(patched, "processing/parser.py", "exec")
    return patched


def load_parser_from_source(source: str):
    # Load patched code in memory to check an actual raw SAP export before writing anything.
    module_name = "_tr093_schema_fix_preview"
    mod = types.ModuleType(module_name)
    mod.__file__ = "processing/parser.py"
    sys.modules[module_name] = mod  # dataclasses need the module registered
    try:
        exec(compile(source, mod.__file__, "exec"), mod.__dict__)
        return mod
    finally:
        sys.modules.pop(module_name, None)


def verify_raw(patched: str, path: Path):
    if not path.is_file():
        raise RuntimeError(f"Raw TXT not found: {path}")
    mod = load_parser_from_source(patched)
    result = mod.parse_file(path, "zmm4tr093")
    if tuple(result.headers) != EXPECTED_COLUMNS:
        raise RuntimeError(
            f"Candidate parser output still differs from the expected published schema: {result.headers}"
        )
    if result.no_data or not result.rows:
        raise RuntimeError("Raw TXT contains no ZMM4TR093 records; check using a populated export")
    print(f"PASS: raw TXT parsed as {len(result.rows)} records, {len(result.headers)} columns")
    print("PASS: column 22 name is unloading_point; other 22 names are unchanged")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--hub-root", required=True, type=Path)
    ap.add_argument("--raw", type=Path, help="Saved failed ZMM4TR093 TXT to verify before applying")
    choice = ap.add_mutually_exclusive_group(required=True)
    choice.add_argument("--check", action="store_true", help="In-memory check only; does not change files")
    choice.add_argument("--apply", action="store_true", help="Back up and update only processing/parser.py")
    args = ap.parse_args()

    target = args.hub_root / "processing" / "parser.py"
    if not target.is_file():
        raise SystemExit(f"ERROR: parser not found: {target}")
    original = target.read_text(encoding="utf-8-sig")
    try:
        updated = make_patch(original)
        if args.raw:
            verify_raw(updated, args.raw)
        else:
            print("No raw TXT supplied; source compatibility and syntax only were checked")
    except Exception as exc:
        raise SystemExit(f"FAILED (no changes): {exc}") from None

    print("PASS: targeted parser change is compatible and syntactically valid")
    if args.check:
        print("CHECK ONLY: no files were modified")
        return

    backup_dir = args.hub_root / "runtime" / "kpi_layout_fix_backups" / (
        "tr093_column22_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    )
    backup_dir.mkdir(parents=True, exist_ok=False)
    backup_path = backup_dir / "parser.py"
    shutil.copy2(target, backup_path)

    staged = target.with_name(".parser.py.tr093_column22.tmp")
    try:
        staged.write_text(updated, encoding="utf-8", newline="\n")
        os.replace(staged, target)
    finally:
        staged.unlink(missing_ok=True)

    print(f"INSTALLED: {target}")
    print(f"BACKUP:    {backup_path}")
    print("No existing Live, Raw or History files were changed")


if __name__ == "__main__":
    main()
