# Data Hub — ZMM4TR093 column 22 schema compatibility fix v1.3

## Root cause

The read-only schema diagnostic established that the existing published ZMM4TR093 column 22 is `unloading_point`, but the v1.2 parser publishes `unl_point` when it sees the SAP caption `Unl. Point`. All other 22 names match and both layouts have 23 fields.

**Do not overwrite the existing Live schema or disable `strict_schema`.** This fix changes only the *parsed output name* of column 22 to the existing `unloading_point` field, retaining row values and source positions. It applies to both previously supported ZMM4TR093 SAP header variants. The descriptive raw heading in metadata is not changed.

## Install (Python standard library only)

1. Back up your Data Hub folder. Pause scheduling, let current runs complete, and close the Data Hub controller.
2. Extract this ZIP to `C:\KPI_TR093_Column22_Fix_v1_3`. Save one failed original export to `C:\KPI_Test\zmm4tr093.txt` (any valid populated 10 November ZMM4TR093 export).
3. From Command Prompt, run the **read-only compatibility and sample check**:

   ```bat
   cd /d C:\KPI_TR093_Column22_Fix_v1_3
   py -3 install_tr093_column22_fix.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\zmm4tr093.txt" --check
   ```

   Expect a successful parse with **23 columns**, column 22 `unloading_point`, and `CHECK ONLY: no files were modified`. If this fails, **do not apply**; send the exact console error.

4. With the controller still closed, apply:

   ```bat
   py -3 install_tr093_column22_fix.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\zmm4tr093.txt" --apply
   ```

   The installer backs up the existing `processing\parser.py` under `runtime\kpi_layout_fix_backups\tr093_column22_<timestamp>\parser.py` and updates only that parser file. It does **not** alter published data, schemas, config, other reports, or Power BI.

5. Restart Data Hub with scheduling paused; run **ZMM4TR093** once manually. Check the controller reports success, the Live CSV has 23 columns including `unloading_point` at column 22, and any appropriate History publication completes. Compare row count to SAP `Total Records`. Resume scheduling when successful.

## Rollback

Pause scheduling and close the controller. Copy `parser.py` from the timestamped backup printed by the installer back to `processing\parser.py`; restart the controller.

## Conditions and boundaries

- Requires the v1.2 layout parser fix (`KPI_LAYOUT_FIX_20261110_V2`). If the source differs, the installer refuses to patch.
- Supports both `Unl. Point` and `Unloading Point` as SAP captions, while maintaining the **published name** `unloading_point`.
- Does not disable checks for extra/missing columns, bad records, or changed SAP layouts.
- Does not republish any previously rejected run automatically; you need a successful manual or scheduled export after installing.
