"""Read-only preflight, guarded install, and backup/rollback for MB51+ZSD.

The SAP DockToStock exporter is intentionally NOT modified because GUI evidence
is incomplete. Requires exact previously released Stability v3 files.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import shutil
import tempfile
import time
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
HEADER_V3_SHA = "0ff1c1c1ec93ccf33b8679f6f988e0866f34c7bf8da9242ea1993bdbfad2da9b"
PARSER_V3_SHA = "1a0bc5ce78fe8038e90d0c0d202ba2e1ad85a3410abe319f080515ff15c02af4"
PARSER_V31_SHA = "e86ac4e37bbc0533d1c2f3691e9746dff1560a80de505d9854070f405b69a016"
REGISTRY_SHA = "4b62d8af19176a40ee59c6c61042b3544652ded22232f9ebb8172eb6ee5fe074"
MB51_NAMES = ('material','batch','plnt','sloc','mvt','s','mat_doc','item','pstng_date','time','quantity','eun','text','user','amount_lc','crcy','cost_ctr','vendor','customer','order','unl_point','material_description')
HEAD = Path('processing/header_variants.py')
PARSER = Path('processing/parser.py')
REGISTRY = Path('schema_contracts/header_variants.json')
CONTRACT = Path('schema_contracts/mb51.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(root, *, strict=True):
    if not root.is_dir():
        raise RuntimeError(f'Data Hub directory does not exist: {root}')
    required = [HEAD, PARSER, REGISTRY, CONTRACT, Path('processing/schema_contracts.py')]
    for relative in required:
        if not (root / relative).is_file():
            raise RuntimeError(f'Missing Data Hub file: {root / relative}')
    if sha(root / HEAD) != HEADER_V3_SHA:
        raise RuntimeError('Unknown processing/header_variants.py fingerprint. No changes made; send the check output and current code.')
    if sha(root / REGISTRY) != REGISTRY_SHA:
        raise RuntimeError('Heading registry was edited after v3. No changes made; review current aliases first.')
    parser_sha = sha(root / PARSER)
    if parser_sha not in (PARSER_V3_SHA, PARSER_V31_SHA):
        raise RuntimeError('Unknown processing/parser.py version. No changes made; do not overwrite newer/custom changes.')
    state = 'v3' if parser_sha == PARSER_V3_SHA else 'v3.1'
    doc = json.loads((root / CONTRACT).read_text(encoding='utf-8-sig'))
    names = tuple(c['name'] if isinstance(c,dict) else c for c in doc.get('columns',[]))
    if doc.get('job_id') != 'mb51' or names != MB51_NAMES:
        raise RuntimeError('MB51 pinned published schema differs from the tested 22-field contract; no changes made.')
    for f in [HEAD, PARSER]:
        if not (PACKAGE / 'payload' / f).is_file():
            raise RuntimeError(f'Installer payload missing: {f}')
    if (sha(PACKAGE / 'payload' / PARSER) != PARSER_V31_SHA or
            sha(PACKAGE / 'payload' / HEAD) == HEADER_V3_SHA):
        raise RuntimeError('Installer payload invalid')
    print(f'PASS: v3 heading registry and MB51 22-field pinned contract')
    print(f'PASS: parser is Stability {state}; ' + ('v3.1 will be installed' if state == 'v3' else 'v3.1 already installed'))
    print('PASS: latest compatible v3 heading normaliser identified')
    print('CHANGES: MB51 header normaliser' + (' + ZSD v3.1 parser' if state == 'v3' else ' only'))
    print('UNCHANGED: exporter, SAP shortcuts, config, schedules, Live, History, Power BI')
    return state


def restore_file(src, dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=dst.parent, prefix='.recover-', delete=False) as tf:
        tmp=Path(tf.name)
        tf.write(src.read_bytes())
        tf.flush()
        os.fsync(tf.fileno())
    os.replace(tmp,dst)


def apply(root):
    state = check(root)
    changed = [HEAD] + ([PARSER] if state=='v3' else [])
    label=time.strftime('%Y%m%d_%H%M%S')
    backup = root/'runtime'/'stability_backups'/f'nov17_v32_{label}'
    if backup.exists():
        raise RuntimeError(f'Backup path already exists: {backup}')
    backup.mkdir(parents=True)
    doc={'version':1,'source':{},'installed':{},'changed':[str(x).replace('\\','/') for x in changed]}
    for f in changed:
        original=root/f
        destination=backup/f
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(original,destination)
        doc['source'][str(f).replace('\\','/')]=sha(original)
        doc['installed'][str(f).replace('\\','/')]=sha(PACKAGE/'payload'/f)
    (backup/'MANIFEST.json').write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8')
    installed=[]
    try:
        # Recheck before first modification: fail closed if any source changed
        for f in changed:
            key=str(f).replace('\\','/')
            if sha(root/f)!=doc['source'][key]:
                raise RuntimeError(f'Source changed during installation: {f}')
        for f in changed:
            restore_file(PACKAGE/'payload'/f,root/f)
            installed.append(f)
    except Exception:
        for f in reversed(installed):
            restore_file(backup/f,root/f)
        raise
    print(f'INSTALLED: {len(changed)} code file(s). Rollback backup: {backup}')
    print('Restart the Data Hub with scheduling paused. Test MB51 and ZSD3TR009.')
    print('DockToStock is NOT fixed by this patch: inspect the actual SAP screen after running ZMM4TR083.')


def rollback(root, backup):
    if not backup.is_dir():
        raise RuntimeError(f'Backup directory missing: {backup}')
    if root.resolve() not in backup.resolve().parents:
        raise RuntimeError('Backup path is outside the selected Data Hub folder')
    doc=json.loads((backup/'MANIFEST.json').read_text('utf-8'))
    changed=[Path(f) for f in doc['changed']]
    for f in changed:
        key=str(f).replace('\\','/')
        if not (backup/f).is_file() or sha(root/f)!=doc['installed'][key] or sha(backup/f)!=doc['source'][key]:
            raise RuntimeError(f'Refusing rollback: code has changed or backup is corrupted: {f}')
    for f in changed:
        restore_file(backup/f,root/f)
    print(f'ROLLBACK COMPLETE: restored {len(changed)} code file(s). Restart Data Hub.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hub-root',type=Path,required=True)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true')
    mode.add_argument('--apply',action='store_true')
    mode.add_argument('--rollback',type=Path,metavar='BACKUP_DIR')
    args=parser.parse_args()
    try:
        if args.check:check(args.hub_root)
        elif args.apply:apply(args.hub_root)
        else:rollback(args.hub_root,args.rollback)
        return 0
    except Exception as exc:
        print(f'FAILED: {type(exc).__name__}: {exc}')
        return 1


if __name__=='__main__':
    raise SystemExit(main())
