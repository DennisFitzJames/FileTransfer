# Offline regression and installer results — 17 November 2026

**PASS** for the exact uploaded samples and source versions tested:

| Test | Outcome |
|---|---|
| Original raw TXT samples for all 17 Data Hub reports | 17/17 identical rows, headings and no-data status vs Stability v3.1 parser |
| MB51 13-Nov empty export | 0 rows, 22 locked columns, SAP no-data marker recognised |
| MB51 17-Nov empty export | 0 rows, 22 locked columns, SAP no-data marker recognised |
| MB51 original 11-Nov populated export | 51 rows, 22 locked columns, unchanged |
| MB51 synthetic 51-row export with a blank tab after Material | Same 51 rows and canonical headings, cell-for-cell |
| ZSD3TR009 13-Nov export | 203 rows, 95 columns, 6 currency total lines excluded |
| Invalid MB51 variants (populated spacer, wrong heading, wrong document anchor, data overhang) | All 4 rejected |
| Installer `--check`, `--apply` and `--rollback` against v3 and v3.1 | Both paths PASS |
| Installer encountering unknown parser version | Rejected safely |

Data Hub source: user-uploaded 12-Nov source review. Parser candidates: the exact Stability v3 and ZSD Panel v3.1 packages. Test files are not distributed.

**Not tested or claimed:** live SAP GUI export navigation, controller scheduling, published W: drive, Power BI refresh. DockToStock remains a SAP UI failure as evidenced by the two provided logs; the patch **does not** modify it.
