# Data Hub November 17 recovery update — v3.2

Built from the **actual Data Hub source uploaded 12 November**, Stability v3, and the tested v3.1 parser. The two newly uploaded MB51 exports (13 and 17 November) are empty-result reports with one extra **blank** physical tab between `Material` and `Batch`. The 13 November ZSD sample is correctly parsed by v3.1.

## What is fixed

- **MB51**: accepts the one *verified empty* tab position after `Material` only when the full 22-heading sequence and nonempty row positions align; preserves `user`, `unl_point`, and `material_description` and all existing values. Both new zero-result MB51 reports parse as **zero records, 22 columns** and contain an explicit SAP `List contains no data` marker. Never creates dummy records.
- **ZSD3TR009**: if the Hub still has Stability **v3** parser, safely upgrades it to **v3.1**; if v3.1 is installed, leaves it unchanged. Your 13 November sample parses as **203 records, 95 columns; six currency-total lines excluded**.
- **Everything else unchanged**: no changes to SAP exporters, `app.py`, controller, schema contracts, configuration, history, Power BI or network data.

**DockToStock remains unresolved.** Both supplied log files (13 and 17 Nov) show SAP GUI refuses `sendVKey(45)` (Ctrl+Shift+F9) with **"The virtual key is not enabled"** after executing ZMM4TR083. This is not a header or parser issue. We must establish whether SAP is showing a no-results screen, a different list type, or a changed export menu. Do **not** change the keyboard shortcut blindly or manufacture an empty dataset.

## Installation

1. Make a copy of `C:\Users\EB013665\DataHub\DataHub-main`; pause scheduling and let jobs finish. Keep this backup and your PBIX untouched.
2. Extract all contents to `C:\DataHub_Nov17_v3_2`, such that `install_nov17.py` is directly in that folder.
3. Run the read-only preflight:

```bat
cd /d C:\DataHub_Nov17_v3_2
py -3 install_nov17.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --check
```

4. **Only if the check passes**, close the Data Hub controller and apply:

```bat
py -3 install_nov17.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --apply
```

5. Keep the scheduler paused. Restart the controller and run **MB51** and **ZSD3TR009** manually. Confirm schema and Live CSV behavior, especially that a zero-result MB51 is *expected for the specified reporting date and movements* before accepting an empty publish. If the data should not be empty, investigate the SAP selection immediately rather than treating an empty file as success. Resume scheduling only after checks pass.

The installer checks file hashes of `processing\header_variants.py`, `processing\parser.py`, and the central heading registry before touching anything. It supports **exactly** parser v3 or v3.1. A different parser or edited registry fails safely.

### Rollback

The installer prints a backup path under `runtime\stability_backups\nov17_v32_...`. Keep that path. With scheduling paused and the controller closed:

```bat
py -3 install_nov17.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --rollback "<THE PRINTED FULL BACKUP PATH>"
```

Rollback refuses if a later patch has changed the installed files.

## DockToStock: one manual SAP check needed

1. In SAP GUI, open `ZMM4TR083` and use the **same six selection fields** as your Data Hub job: receiving plant 0787, receiving storage WI10, putaway plant 0787, putaway storage WI10, building B67 and posting date the run is checking (13 or 17 November 2026).
2. Press Execute (F8). Look at the resulting SAP screen **before attempting export**. Does it show an actual result list, a **no-data** message, or another screen? If there is a list, check which **List → Export → Local File** or other menu/toolbar export entry works.
3. Send **a screenshot of that SAP screen with sensitive details obscured**, or record the exact SAP status message, result type, and working export menu path. With this evidence we can correct DockToStock's *exporter* safely rather than guessing.

These steps are diagnostic only. No need to change the Power BI queries, historical dates or SAP export format yet.

## Scope and limitations

Offline tests passed. Installer and rollback were exercised in a disposable Hub copy with the collected 12 November source and current v3/v3.1 files. **Actual SAP GUI and W: network shares could not be tested here.** An empty MB51 TXT proves zero rows were exported, but not that the user intended a zero-result date selection. A completed report's SAP data should always be reconciled to the relevant SAP transaction before publishing it as an authoritative KPI.
