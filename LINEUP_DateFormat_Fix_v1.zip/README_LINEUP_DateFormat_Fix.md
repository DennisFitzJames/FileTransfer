# LINEUP Shared SAP Data Hub — date compatibility fix

## Cause

The Data Hub publishes ISO `YYYY-MM-DD` dates. LINEUP's `app/schedule_orders.py` still parses production dates as `DD.MM.YYYY`. The migration adapter was passing ISO through unchanged; `target_finish_day_offset` was blank and LINEUP displayed `UNKNOWN — No SAP scheduled finish day`.

## What changed

Only `app/datahub_adapter.py` needs replacing. Its import now:

- Converts all four COOIS Production dates (`scheduled_start`, `scheduled_finish`, `actual_start`, `actual_finish`) to LINEUP's original `DD.MM.YYYY` format.
- Converts the date portion of Capacities timestamps (`earliest_start`, `latest_finish`, `actual_start`, `actual_finish`) in the same way, retaining the time.
- Preserves blanks and accepts already-legacy dates. Unexpected nonempty date formats fail validation instead of silently producing an unknown scheduling target.
- Leaves the shared Data Hub's published CSVs unchanged.

## Installation (your LINEUP PC)

1. Back up `C:\LINEUP\app\datahub_adapter.py`.
2. On your **new LINEUP GitHub repository**, replace `app/datahub_adapter.py` with the file from this ZIP. Commit the change.
3. Download/transfer just that updated file to `C:\LINEUP\app\datahub_adapter.py`. Do **not** replace `C:\LINEUP\data`, config, logs, or the whole installation.
4. Optionally copy `tests/test_datahub_date_formats.py` into `C:\LINEUP\tests\` and run from `C:\LINEUP`:

   ```bat
   py -3 -m unittest discover -s tests -p test_datahub_date_formats.py -v
   ```

5. Ensure no LINEUP processing is currently running, then run **one manual processing cycle**:

   ```bat
   cd /d C:\LINEUP
   run_lineup_background.bat
   ```

6. Inspect a real order in `data\processed\production_list_clean.csv` and confirm its `scheduled_finish` now resembles `11.12.2026`, not `2026-12-11`.
7. Inspect `data\processed\master_schedule.csv` for the same order. Review the planned schedule and due-status calculations. In `data\processed\scheduled_orders.csv`, verify `target_finish_day_offset` and `due_status` no longer default to UNKNOWN solely because of a missing date. Other causes of UNKNOWN may remain.
8. Refresh the browser page. **No Flask server restart or network address change should be required** for this patch: LINEUP's scheduled processing runs in a separate Python process.
9. The existing 10-minute Task Scheduler check and Data Hub 30-minute SAP exports continue unchanged. Don't run the manual pipeline concurrently with an automatic LINEUP processing cycle.

## Verification performed

- 5 Python unit tests passed.
- Converted the original `Raw.zip` COOIS Production LINEUP sample: **2,614 rows**.
- Converted the original `Raw.zip` COOIS Capacities LINEUP sample: **6,726 rows**.
- All date-bearing fields inspected had the expected LINEUP date format; record counts remained unchanged.
- Live Windows/SAP and browser testing is still required on your PC.
