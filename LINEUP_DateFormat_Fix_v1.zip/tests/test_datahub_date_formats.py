"""Run from LINEUP root: py -3 -m unittest discover -s tests -p test_datahub_date_formats.py"""
import importlib.util
import sys
import unittest
from pathlib import Path

ADAPTER = Path(__file__).resolve().parents[1] / 'app' / 'datahub_adapter.py'
spec = importlib.util.spec_from_file_location('datahub_adapter', ADAPTER)
module = importlib.util.module_from_spec(spec)
sys.modules['datahub_adapter'] = module
spec.loader.exec_module(module)


class TestDateCompatibility(unittest.TestCase):
    def test_iso_to_legacy(self):
        self.assertEqual(module._to_lineup_date('2026-12-11'), '11.12.2026')
        self.assertEqual(module._to_lineup_date('2027-02-01'), '01.02.2027')

    def test_blank_or_legacy(self):
        self.assertEqual(module._to_lineup_date(''), '')
        self.assertEqual(module._to_lineup_date('11.12.2026'), '11.12.2026')

    def test_invalid_fails(self):
        with self.assertRaises(module.DataHubInputError):
            module._to_lineup_date('2026-15-89')

    def test_production_dates(self):
        input_row = {
            'order': '200234602651', 'material': 'EB0767-000',
            'schedstart': '2026-11-24', 'sched_fin': '2026-12-11',
            'act_start': '', 'act_finish': '2026-12-01',
        }
        converted = module.build_production([input_row])[0]
        self.assertEqual(converted['scheduled_start'], '24.11.2026')
        self.assertEqual(converted['scheduled_finish'], '11.12.2026')
        self.assertEqual(converted['actual_start'], '')
        self.assertEqual(converted['actual_finish'], '01.12.2026')

    def test_capacity_date_time(self):
        input_row = {
            'order': '200234602651', 'oper_act': '0010',
            'earl_start': '2026-11-24', 'earl_start__2': '07:15:00',
            'lat_finish': '2026-12-11', 'lat_finish__2': '00:00:00',
            'act_start': '', 'act_start__2': '',
            'act_finish': '2026-12-01', 'act_finish__2': '14:00:00',
        }
        converted = module.build_capacities([input_row])[0]
        self.assertEqual(converted['earliest_start'], '24.11.2026 07:15:00')
        self.assertEqual(converted['latest_finish'], '11.12.2026 00:00:00')
        self.assertEqual(converted['actual_start'], '')
        self.assertEqual(converted['actual_finish'], '01.12.2026 14:00:00')


if __name__ == '__main__':
    unittest.main()
