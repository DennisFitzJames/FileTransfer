#!/usr/bin/env python3
"""Guarded ZSD3TR009 panel-split correction for Shared SAP Data Hub Stability v3.

Only replaces processing/parser.py after validating: exact installed version,
verified raw example, pinned contract and actual published Live schema.
Published files, schedules and configuration are never modified.
"""
from __future__ import annotations
import argparse
import csv
import datetime as dt
import hashlib
import importlib
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
REL = Path('processing/parser.py')
OLD = '1a0bc5ce78fe8038e90d0c0d202ba2e1ad85a3410abe319f080515ff15c02af4'
HEADER_SHA = '0ff1c1c1ec93ccf33b8679f6f988e0866f34c7bf8da9242ea1993bdbfad2da9b'
REGISTRY_SHA = '4b62d8af19176a40ee59c6c61042b3544652ded22232f9ebb8172eb6ee5fe074'

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def copy_atomic(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='wb', prefix='.zsd31_', suffix='.tmp',
                                     dir=destination.parent, delete=False) as f:
        tmp = Path(f.name)
        f.write(Path(source).read_bytes())
        f.flush()
        os.fsync(f.fileno())
    try:
        os.replace(tmp, destination)
    finally:
        tmp.unlink(missing_ok=True)

def candidate_parser(root, raw):
    """Run parser in a separate temporary package, never editing installed code."""
    with tempfile.TemporaryDirectory(prefix='datahub_zsd31_check_') as td:
        home = Path(td)
        (home / 'processing').mkdir()
        (home / 'schema_contracts').mkdir()
        (home / 'processing' / '__init__.py').write_text('', encoding='utf-8')
        shutil.copy2(PACKAGE/'payload'/REL, home/REL)
        shutil.copy2(root/'processing/header_variants.py', home/'processing/header_variants.py')
        shutil.copy2(root/'schema_contracts/header_variants.json',
                     home/'schema_contracts/header_variants.json')
        sys.path.insert(0, str(home))
        try:
            from processing.parser import parse_file
            return parse_file(raw, 'zsd3tr009')
        finally:
            sys.path.pop(0)
            for name in ('processing.parser', 'processing.header_variants', 'processing'):
                sys.modules.pop(name, None)

def column_list(obj, source):
    if not isinstance(obj, dict) or not isinstance(obj.get('columns'), list):
        raise ValueError(f'Unexpected columns schema: {source}')
    vals = [v.get('name') if isinstance(v, dict) else v for v in obj['columns']]
    if not all(isinstance(v, str) and v for v in vals):
        raise ValueError(f'Invalid column names in {source}')
    return vals

def validate(root, raw):
    original = root/REL
    new = PACKAGE/'payload'/REL
    if not new.is_file():
        raise ValueError('Missing parser payload')
    compile(new.read_text(encoding='utf-8'), str(new), 'exec')
    for file, expected in [
        (root/'processing/header_variants.py', HEADER_SHA),
        (root/'schema_contracts/header_variants.json', REGISTRY_SHA),
    ]:
        if not file.is_file() or sha(file) != expected:
            raise ValueError(f'Installed v3 dependency differs: {file}; do not force')
    if not original.is_file():
        raise ValueError('Data Hub parser.py is missing')
    installed_sha = sha(original)
    new_sha = sha(new)
    if installed_sha not in (OLD, new_sha):
        raise ValueError(f'Installed parser is not the tested Stability v3 version: {installed_sha}; do not force')
    if not raw.is_file() or raw.stat().st_size < 30:
        raise ValueError(f'Raw TXT missing/empty: {raw}')
    parsed = candidate_parser(root, raw)
    pinned = root/'schema_contracts/zsd3tr009.json'
    if not pinned.is_file():
        raise ValueError('Missing pinned ZSD3TR009 contract')
    pinned_cols = column_list(json.loads(pinned.read_text(encoding='utf-8')), str(pinned))
    if parsed.headers != pinned_cols:
        raise ValueError('Candidate output does not match the pinned ZSD3TR009 column contract')
    config_file = root/'config.json'
    if not config_file.is_file():
        raise ValueError('Missing config.json, needed for actual Live schema comparison')
    config = json.loads(config_file.read_text(encoding='utf-8-sig'))
    publish_root = config.get('storage', {}).get('publish_root')
    if not isinstance(publish_root, str) or not publish_root.strip():
        raise ValueError('Configured publish root is missing')
    live = Path(publish_root)/'Live'/'zsd3tr009'
    schema_file = live/'zsd3tr009_schema.json'
    csv_file = live/'zsd3tr009_latest.csv'
    if not schema_file.is_file() or not csv_file.is_file():
        raise ValueError('Live CSV/schema missing or inaccessible; no safe installation without comparison')
    live_cols = column_list(json.loads(schema_file.read_text(encoding='utf-8-sig')), str(schema_file))
    with csv_file.open('r', encoding='utf-8-sig', newline='') as f:
        csv_cols = next(csv.reader(f), None)
    if live_cols != pinned_cols or csv_cols != pinned_cols:
        raise ValueError('Published Live CSV/schema and local pinned contract disagree; no code changed')
    if parsed.row_count <= 0 or len(parsed.headers) != 95:
        raise ValueError('Supplied test TXT did not produce a populated 95-field report')
    print(f'PASS: installed parser SHA256 {installed_sha}')
    print(f'PASS: candidate parses TXT -> {parsed.row_count} records, '
          f'{len(parsed.headers)} columns, {parsed.ignored_total_lines} totals excluded')
    print('PASS: candidate columns match both actual W: Live files and pinned contract')
    return installed_sha, new_sha

def apply(root, raw):
    old_sha, new_sha = validate(root, raw)
    if old_sha == new_sha:
        print('ALREADY INSTALLED; nothing to change.')
        return
    dest = root/REL
    backup = root/'runtime'/'stability_backups'/('zsd_panel_v31_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    backup.mkdir(parents=True, exist_ok=False)
    original = backup/'parser.py'
    shutil.copy2(dest, original)
    manifest = {'original_sha256':old_sha,'updated_sha256':new_sha,'path':str(REL)}
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2), encoding='utf-8')
    try:
        copy_atomic(PACKAGE/'payload'/REL, dest)
        if sha(dest) != new_sha:
            raise ValueError('Post-install file hash mismatch')
    except BaseException:
        copy_atomic(original, dest)
        raise
    print('SUCCESS: only processing\\parser.py changed; no published files modified')
    print('ROLLBACK BACKUP:', backup)

def rollback(root, backup):
    info_file = backup/'manifest.json'
    if not info_file.is_file():
        raise ValueError('No backup manifest; refuse rollback')
    info = json.loads(info_file.read_text(encoding='utf8'))
    if info.get('path') != str(REL) or info.get('updated_sha256') != sha(PACKAGE/'payload'/REL):
        raise ValueError('Backup does not belong to this update')
    original = backup/'parser.py'
    if not original.is_file() or sha(original) != info['original_sha256']:
        raise ValueError('Backup is missing or has changed')
    dest = root/REL
    if not dest.is_file() or sha(dest) != info['updated_sha256']:
        raise ValueError('Installed parser was subsequently modified; rollback refused')
    copy_atomic(original, dest)
    print('ROLLED BACK parser only, verified original SHA256:', sha(dest))

def main():
    ap=argparse.ArgumentParser(description='Stability v3: ZSD3TR009 header continuation update')
    ap.add_argument('--hub-root',required=True,type=Path)
    ap.add_argument('--raw',type=Path, help='Known failing ZSD3TR009 raw TXT (required except rollback)')
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true')
    mode.add_argument('--apply',action='store_true')
    mode.add_argument('--rollback',type=Path,metavar='BACKUP_DIR')
    args=ap.parse_args()
    root=args.hub_root.resolve()
    try:
        if args.rollback:
            rollback(root,args.rollback.resolve())
        elif not args.raw:
            raise ValueError('--raw is required for --check or --apply')
        elif args.check:
            validate(root,args.raw.resolve())
        else:
            apply(root,args.raw.resolve())
    except (ValueError,OSError,ImportError,KeyError,StopIteration) as e:
        print('FAILED:',e,file=sys.stderr)
        raise SystemExit(1)

if __name__ == '__main__':
    main()
