# Shared SAP Data Hub — ZSD3TR009 panel-boundary fix v3.1

**Built against the exact `processing/parser.py` supplied in Stability v3.**
This corrects the only job that failed your four-report post-installation test. Do **not** reinstall Stability v3 or the older ZSD3TR009 patches.

## Root cause

SAP changes where the **95 existing business headings** are split over two lines based on the width of the exported list. Earlier continuation panels began with `Sold to party Address 3` or `Telephone1`; the 12 November TXT begins with `Sold to party Address 2`. All 95 business fields are still in the same order, including `Expedite`.

The v3 parser incorrectly required the continuation to start with one of two named headings. v3.1 removes that specific assumption. Instead, the **complete ordered list of 95 business headings must match the pinned published contract**. It still checks the original tab positions, checks delivery/item/time alignment, refuses data in unnamed fields, and checks for unexpected data overhanging the panel. No columns or values are invented or discarded.

## Installation

**Before applying**: pause Data Hub scheduling, allow active exports to finish, close the controller and retain a Data Hub backup.

1. Extract `SAP_DataHub_ZSD_Panel_Fix_v3_1.zip` to `C:\KPI_ZSD_Panel_v3_1`.
2. Save the uploaded `zsd3tr009 3 (1).txt` as `C:\KPI_Test\zsd3tr009.txt` (do not edit the TXT).
3. Run a read-only check from Command Prompt:

```bat
cd /d C:\KPI_ZSD_Panel_v3_1
py -3 install_zsd_panel_v31.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\zsd3tr009.txt" --check
```

Expected: `PASS`, **172 records**, **95 columns**, **4 excluded currency-total lines**. This check also ensures the current installed `parser.py` is **exactly** the Stability v3 code, that the other v3 registry files have not changed, and that the candidate output columns match the **actual W: Live CSV and schema JSON** and local pinned contract. Nothing is modified.

4. If all PASS checks succeed, apply the single-file correction:

```bat
py -3 install_zsd_panel_v31.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\zsd3tr009.txt" --apply
```

The installer automatically backs up `processing\parser.py` under `runtime\stability_backups\zsd_panel_v31_...` and prints the full path. Save that path.

5. Restart the Data Hub **with scheduling paused** and manually run **ZSD3TR009**. Confirm a successful job and a new Live CSV/schema timestamp, with exactly 95 columns. Compare several delivery/item/address records. Its daily History snapshot follows the existing **first-successful-after-07:00** policy; a snapshot already taken today will not be overwritten. Then resume scheduling.

**If `--check` fails, do not run `--apply`.** Send back its exact error. Do not disable strict schema checks, edit published schemas, or switch export format mid-test.

## Rollback

Pause scheduling, let jobs finish, close the controller. Run the following, replacing the example backup path with the **exact path printed during installation**:

```bat
py -3 install_zsd_panel_v31.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --rollback "C:\Users\EB013665\DataHub\DataHub-main\runtime\stability_backups\zsd_panel_v31_YOUR_TIMESTAMP"
```

The rollback refuses if the parser has been modified since this patch was installed. It restores the code only, not any successfully published Live/History files.

## Scope

- **Changed:** `processing\parser.py` only.
- **Unchanged:** `app.py`, all exporters, all scheduling/reconciliation settings, `header_variants.py`, all JSON registries/contracts, Live/Raw/History, Power BI.
- **No SAP TXT data included in this ZIP** (run the check against your own local saved TXT).
- Tested offline with all 17 original reports and all five saved ZSD3TR009 exports, plus specific malformed-input rejection tests. Details in `QA_RESULTS.md`.
