# ZSD3TR009 v3.1 offline validation

**Source parser:** exact Stability v3 file (`SHA-256: 1a0bc5ce78fe8038e90d0c0d202ba2e1ad85a3410abe319f080515ff15c02af4`).

## Real SAP ZSD3TR009 TXT samples

| Export | Rows | Named published columns | Excluded currency totals | Result |
|---|---:|---:|---:|---|
| October earlier | 182 | 95 | 5 | PASS |
| 10 Nov first | 226 | 95 | 4 | PASS |
| 10 Nov second | 236 | 95 | 4 | PASS |
| 10 Nov 15:03 | 119 | 95 | 4 | PASS |
| **12 Nov 14:59 uploaded** | **172** | **95** | **4** | **PASS** |

The v3 parser rejects the new 12 Nov sample with `unapproved continuation panel or missing Expedite`. The v3.1 candidate passes it while returning the same canonical column sequence as the prior four exports.

Across the **21 deliveries shared** with the previous 10 Nov export, all 21 matched on the 22 checked fields, including delivery/item keys, date, both address panels, time, building number and additional continuation fields. Fields that can legitimately change between exports were not treated as invariant proof of completeness.

**Other Data Hub jobs:** all 17 original raw samples successfully parsed. No code path for another job was modified.

## Negative/layout tests

All **10 deliberately invalid** variants were rejected: missing Expedite; renamed Expedite; missing known heading; extra named heading; wrong heading order; nonempty unnamed tab; invalid delivery identifier; invalid item; invalid time; unexpected nonempty continuation overflow.

Two synthetic variations shifting the boundary backward by one and two physical columns were accepted; **all 172 rows and 95 canonical fields were byte-for-byte identical** to the main sample after parsing. This tests true boundary independence rather than merely adding the third name to a whitelist.

## Installer test

- Read-only `--check` validated candidate against a test Live CSV, schema JSON and pinned contract, without changing files.
- `--apply` replaced only `processing/parser.py` and made an original-code backup.
- Repeat `--apply` was a no-op.
- `--rollback` restored the exact original parser hash.
- An unknown modified parser version was rejected.

All tests were offline. The final test against the user's **actual W: share, SAP GUI and controller** must be done on the user PC. This patch does not backfill history or alter Power BI.
