# Data Hub KPI parser layout fix v1.2 — 10 November 2026

**Purpose:** Add recognition of exactly two new SAP TXT formats discovered during Logistics KPI cutover. This patch changes only `processing/parser.py` in an existing Data Hub installation that already has the **v1.1 KPI layout fix**. It does not change `app.py`, exporters, the SAP automation, scheduling, the Data Hub History engine, existing CSVs, or any Power BI queries.

## Why these two errors occurred

- **ZMM4TR093** (`unexpected table line 11 (26 columns)`): compared with the previous 25-slot header, the 10 November file has one additional *empty* tab position before `TO Number`, now at slot 7. The old `_is_data()` test looked at slot 6. Two captions changed: `User`→`Name(QNAME)` and `Unl. Point`→`Unloading Point`. The patch validates the extra position is blank for **every record** and preserves the original `user` and `unl_point` canonical field names. The uploaded file declares 623 records, all of which passed the corrected parse.
- **ZSD3TR009** (`Could not identify expected header`): new 10 November file has a 98-slot main header and 33-slot continuation, compared with earlier 97+32 and 97+30 variants. The existing v1.1 code already maps `Date`→`Created on`, but only when the main header has 97 slots. This patch allows the verified 98+33 combination without shifting or deleting any populated fields.

## Test results against supplied originals

| Source | Rows | Canonical columns | Result |
|---|---:|---:|---|
| ZMM4TR093, 10 Nov 11:02 | 623 | 23 | PASS |
| ZMM4TR093, old 21 Oct | 247 | 23 | PASS |
| ZSD3TR009, 10 Nov 11:01 | 236 | 95 | PASS |
| ZSD3TR009, 10 Nov 09:43 | 226 | 95 | PASS |
| ZSD3TR009, old 21 Oct | 182 | 95 | PASS |

Canonical column **names and ordering** were identical between the older and newer formats for each report. This avoids triggering the controller's strict schema-change protection or breaking current Power BI field references. The patch retains strict validation of unlabelled fields, currency totals, records and row counts; unexpected new layouts still fail closed.

## Installation on the Data Hub PC

1. Save the **failed raw TXT files** to a convenient local folder, for example `C:\KPI_Test\zmm4tr093.txt` and `C:\KPI_Test\zsd3tr009.txt`. Keep copies for diagnosis.
2. Back up your Data Hub folder and the existing Live CSV/JSON for both reports. **Pause the Data Hub scheduler**, let any active SAP reports finish, then close the Data Hub controller. Do not patch running Python code.
3. Extract the ZIP to `C:\KPI_Parser_Fix_v1_2` and open Command Prompt there:

   ```bat
   cd /d C:\KPI_Parser_Fix_v1_2
   py -3 install_parser_fix_v1_2.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --check
   ```

   This checks source compatibility and syntax without modifying anything. If it fails, **do not force it**; the local parser differs from the expected v1.1 code.

4. Apply only after the compatibility check passes:

   ```bat
   py -3 install_parser_fix_v1_2.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --apply
   ```

   The installer automatically backs up the original parser to `runtime\kpi_layout_fix_backups\v1_2_<timestamp>\parser.py` and modifies no other Data Hub file.

5. Test both exact failed raw files **without publishing**:

   ```bat
   py -3 verify_parser_fix_v1_2.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --zmm093 "C:\KPI_Test\zmm4tr093.txt" --zsd "C:\KPI_Test\zsd3tr009.txt"
   ```

   On the supplied files, expect **623 rows / 23 columns** and **236 rows / 95 columns**, respectively. If verification fails, do not resume scheduled exports.

6. Restart Data Hub with scheduling still paused. Run one fresh ZMM4TR093 export and one ZSD3TR009 export. Check that both Live CSVs and their corresponding History partitions publish and that the column counts are still 23 and 95. Then enable scheduling.

## Rollback

With scheduling paused and the Data Hub controller fully closed, copy `parser.py` back from the timestamped backup into `processing\parser.py`. Existing Live/History data is not overwritten or deleted by this installer.

## Operational follow-up

If the SAP ALV export layout continues changing, stabilising the SAP column variant/selection in the exporter is preferable to routinely expanding the accepted formats. The parser intentionally does **not** infer a field by shifting columns blindly.
