"""Install a minimal, fail-closed parser-only patch for two verified SAP layouts.

Preserves Data Hub controller, scheduling, config, history and existing data.
Requires the v1.1 parser fix already installed. No network/dependencies.
"""
from __future__ import annotations

import argparse
import datetime as dt
import os
from pathlib import Path
import shutil

TAG = "KPI_LAYOUT_FIX_20261110_V2"


def replace_once(s: str, old: str, new: str, label: str) -> str:
    count = s.count(old)
    if count != 1:
        raise RuntimeError(
            f"{label}: expected exactly one compatible code location, got {count}. "
            "No changes applied; do not force the patch."
        )
    return s.replace(old, new)


ZMM093_NORMALISE = '''    # KPI_LAYOUT_FIX_20261110_V2: SAP may insert one *empty* tab position
    # between Conf.t. and TO Number in ZMM4TR093. Only accept the verified
    # 26-position variant; validate every record before removing that spacer.
    # Canonicalise two equivalent field labels to preserve the published schema.
    if job_id == "zmm4tr093":
        for candidate_i, candidate_line in enumerate(lines[:160]):
            fields = candidate_line.split("\\t")
            if (len(fields) == 26 and
                    fields[1].strip() == "Conf. Date" and
                    fields[2].strip() == "Name(QNAME)" and
                    fields[4].strip() == "Conf.t." and
                    fields[6].strip() == "TO Number" and
                    fields[24].strip() == "Unloading Point" and
                    fields[25].strip() == "StorageBin"):
                if fields[5].strip():
                    raise ParseError("ZMM4TR093 expected spacer heading is populated")
                fields.pop(5)
                fields[2] = "User"
                fields[23] = "Unl. Point"
                lines[candidate_i] = "\\t".join(fields)
                for row_i in range(candidate_i + 1, len(lines)):
                    raw = lines[row_i]
                    if not raw.strip() or any(m in raw.casefold() for m in NO_DATA_MARKERS):
                        continue
                    row = raw.split("\\t")
                    if (len(row) < 7 or row[5].strip() or
                            not DATE_DMY.fullmatch(row[1].strip()) or
                            not row[6].strip().isdigit()):
                        raise ParseError(
                            f"ZMM4TR093 widened row at line {row_i + 1} is invalid; "
                            "original TXT was not published")
                    row.pop(5)
                    lines[row_i] = "\\t".join(row)
                break
'''


def patch_parser(s: str) -> str:
    if TAG in s:
        raise RuntimeError("v1.2 fix already installed; no changes made")
    if "KPI_LAYOUT_FIX_20261110_V1" not in s:
        raise RuntimeError("Expected parser v1.1 fix is missing; no changes made")
    s = replace_once(
        s,
        'if (len(fields) == 97 and\n                    fields[2].strip() == "ShPnt"',
        'if (len(fields) in (97, 98) and\n                    fields[2].strip() == "ShPnt"',
        "ZSD3TR009 main header 97/98",
    )
    s = replace_once(
        s,
        'if (len(continuation) not in (30, 32) or',
        'if (len(continuation) not in (30, 32, 33) or',
        "ZSD3TR009 continuation 30/32/33",
    )
    s = replace_once(
        s,
        '    header_i, main_head = _get_header(lines, job_id)',
        ZMM093_NORMALISE + '    header_i, main_head = _get_header(lines, job_id)',
        "ZMM4TR093 spacer/heading canonicalisation",
    )
    compile(s, "processing/parser.py", "exec")
    return s


def main() -> None:
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument("--hub-root", required=True, type=Path)
    mode = a.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = a.parse_args()

    target = args.hub_root / "processing" / "parser.py"
    if not target.is_file():
        raise SystemExit(f"Missing installed parser: {target}")
    original = target.read_text(encoding="utf-8-sig")
    updated = patch_parser(original)
    print("PASS: existing parser supports the narrow v1.2 changes; syntax check passed")
    if args.check:
        print("Check only: no files changed")
        return

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = args.hub_root / "runtime" / "kpi_layout_fix_backups" / f"v1_2_{stamp}"
    backup_dir.mkdir(parents=True, exist_ok=False)
    backup = backup_dir / "parser.py"
    shutil.copy2(target, backup)

    staged = target.with_name(".parser.py.kpi_v12.tmp")
    try:
        staged.write_text(updated, encoding="utf-8", newline="\n")
        os.replace(staged, target)
    finally:
        staged.unlink(missing_ok=True)
    print(f"INSTALLED: {target}")
    print(f"BACKUP: {backup}")
    print("Test using verify_parser_fix_v1_2.py before restarting automatic schedules")


if __name__ == "__main__":
    main()
