"""Read-only test of Data Hub parser on the two actual failed raw exports.

Does not export from SAP, change files, or publish History / Live CSVs.
"""
from __future__ import annotations
import argparse
import importlib.util
from pathlib import Path
import sys


def load_parser(path: Path):
    spec = importlib.util.spec_from_file_location("live_datahub_parser_v12", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--hub-root", required=True, type=Path)
    p.add_argument("--zmm093", required=True, type=Path, help="Exact failed zmm4tr093.txt")
    p.add_argument("--zsd", required=True, type=Path, help="Exact failed zsd3tr009 TXT")
    a = p.parse_args()
    m = load_parser(a.hub_root / "processing" / "parser.py")

    for job, path, count, required in [
        ("zmm4tr093", a.zmm093, 23, {"conf_date", "user", "to_number", "unl_point", "storagebin"}),
        ("zsd3tr009", a.zsd, 95, {"shpnt", "created_on", "delv_item"}),
    ]:
        parsed = m.parse_file(path, job)
        missing = required.difference(parsed.headers)
        if missing or len(parsed.headers) != count:
            raise RuntimeError(
                f"{job}: schema mismatch: {len(parsed.headers)} columns, missing {sorted(missing)}"
            )
        print(f"PASS {job}: {parsed.row_count:,} rows, {len(parsed.headers)} canonical fields; {path}")
        if job == "zmm4tr093":
            print("  'user', 'to_number', 'unl_point' preserved under prior field names")
        else:
            print("  'created_on' preserved; currency totals excluded:", parsed.ignored_total_lines)
    print("Read-only verification passed. No Live or History files were written.")


if __name__ == "__main__":
    main()
