"""Read-only verification of local Data Hub parser with the two failed TXT files.

Example:
  py -3 verify_kpi_layout_fix.py --hub-root "C:\\Users\\...\\DataHub-main" --zsd "C:\\KPI_Test\\zsd3tr009.txt" --tr012 "C:\\KPI_Test\\zmm4tr012.txt"
"""
from __future__ import annotations
import argparse
import importlib.util
from pathlib import Path
import sys


def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--hub-root',required=True,type=Path)
    a.add_argument('--zsd',required=True,type=Path)
    a.add_argument('--tr012',required=True,type=Path)
    args=a.parse_args()
    parser_path=args.hub_root/'processing'/'parser.py'
    spec=importlib.util.spec_from_file_location('installed_hub_parser',parser_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot import {parser_path}')
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)

    for jid,path,expected in [('zsd3tr009',args.zsd,95),('zmm4tr012',args.tr012,48)]:
        data=module.parse_file(path,jid)
        if len(data.headers) != expected:
            raise RuntimeError(f'{jid}: {len(data.headers)} columns, expected {expected}')
        if data.row_count == 0:
            raise RuntimeError(f'{jid}: provided sample has no data rows; test with the failing populated file')
        print(f'{jid}: PASS, {data.row_count} records, {len(data.headers)} columns')
        if jid=='zsd3tr009':
            if 'created_on' not in data.headers:
                raise RuntimeError('Missing canonical created_on field')
            first=data.rows[0][data.headers.index('created_on')]
            print(f'  canonical created_on sample: {first}')
        else:
            if data.headers[-1]!='sap_unlabelled_039':
                raise RuntimeError('Unnamed source field was not retained')
            retained=[r[-1] for r in data.rows if r[-1].strip()]
            if not retained:
                raise RuntimeError('The sample has no populated unnamed field; check exact file')
            print(f'  preserved unnamed position 39: {len(retained)} nonblank, first value {retained[0]!r}')
    print('Both files passed in read-only mode; nothing was published or changed on W:.')

if __name__=='__main__':main()
