# KPI parser + Power Query compatibility repair (10 November 2026)

**For the existing Shared SAP Data Hub v0.6.1 installation (including the subsequent daily-snapshot additions).** This is a deliberately narrow compatibility patch: it does not replace the controller, change scheduling, change configuration, remove historical files, or modify the Power BI fact tables.

## Diagnosed against the supplied raw TXT files

- `zsd3tr009.txt` (10 Nov): 97-column main header, **32-column** secondary header, and `Date` in place of the old `Created on`. The last lines also contain **30-column currency-total records**. The old successful sample (21 Oct) has 30 continuation columns and 31-column currency totals. Parsed successfully after the fix: **226 records / 95 canonical columns**, with four totals intentionally ignored. Older sample still parses: 182 / 95.
- `zmm4tr012.txt` (10 Nov): **one actual data row**, and tab position **39** has value `0` despite a blank heading. The old `.xlsx` export has an equivalent unnamed value after `Picked carton Ind`. Fix retains the unknown field at the **end of the CSV** as `sap_unlabelled_039` instead of deleting it. Renames three widened headings to legacy-compatible canonical names: `Ship-to-party`→`ship_to_pa`, `Product Desc`→`product_de`, `Profit centre name`→`profit_cen__2`. Both new and old variant produce the same **48-column schema** (47 existing business columns plus the preserved extra). Old no-data sample remains valid.
- **Schema guard remains on.** `app.py` is amended solely to approve the one verified, additive ZMM4TR012 47→48-column schema upgrade. All unrelated schema changes still block publication. Before publishing, preserve your existing Live CSV and schema JSON for rollback. When the new schema has been approved, future runs of either verified ZMM4TR012 layout produce 48 columns.
- `FactCycleCount`: the Power Query helper in this ZIP checks the shared History root is accessible, then allows a missing *job-specific* History folder to behave as an empty set of new partitions; legacy cached rows still load. All other errors continue propagating. It cannot create a missing SAP export or fill a missing reporting day.

## Install steps

1. Back up the entire **DataHub-main** folder, plus the Live CSV/JSON for `zmm4tr012` and `zsd3tr009`. Save a copy of your working `.pbix`.
2. Pause Data Hub scheduling, let any active exports finish, and close the Data Hub controller completely. Do not modify any installed code while it is running.
3. Extract this ZIP to `C:\KPI_Parser_Fix_v1_1` (any convenient location). In Command Prompt, run:

   ```bat
   cd /d C:\KPI_Parser_Fix_v1_1
   py -3 install_kpi_layout_fix.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --check
   ```

   If it reports an unexpected code anchor, **stop**: do not replace app.py or parser.py manually. This installer is conservative about unknown local changes.
4. If check passes:

   ```bat
   py -3 install_kpi_layout_fix.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --apply
   ```

   It backs up **only the two touched code files** in `DataHub-main\runtime\kpi_layout_fix_backups\<timestamp>`. It never overwrites config/state or historical data.
5. Syntax-check, if desired:

   ```bat
   cd /d "C:\Users\EB013665\DataHub\DataHub-main"
   py -3 -m py_compile app.py processing\parser.py
   ```

6. **Read-only parse verification:** if the two failing raw TXT files are saved to `C:\KPI_Test\zsd3tr009.txt` and `C:\KPI_Test\zmm4tr012.txt`, run from the extracted patch folder:

   ```bat
   py -3 verify_kpi_layout_fix.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --zsd "C:\KPI_Test\zsd3tr009.txt" --tr012 "C:\KPI_Test\zmm4tr012.txt"
   ```

   Expected: **226 / 95** for ZSD3TR009, **1 / 48** for ZMM4TR012, including the previously blocked zero value. These exact row counts apply only to the uploaded 10 November raw files. This verification does not change W:.
7. Restart Data Hub with scheduling still paused. Execute full **SAP exports**, one at a time, for ZSD3TR009 and ZMM4TR012. A *Parse raw* operation updates Live only; a full successful export is needed to publish date-driven History or capture a daily snapshot. Confirm latest `Live/<job>/*_latest.csv` + schema JSON, and corresponding History files for the report dates. If a strict-schema error persists, **stop and provide the new error**; do not disable global strict-schema checks.
8. Resume scheduling after checking those two exports and another previously working report. Existing older exports/history remain untouched unless the controller legitimately publishes the relevant report date; normal date-driven History is designed to replace a day's partition.

## Power Query fix for `FactCycleCount`

In your *backup* Logistics KPI Power BI file, open **Transform data** → select the helper query **`fnKpiHistory`**, open **Advanced Editor**, and replace only that helper with `PowerQuery/01_fnKpiHistory.pq` from this ZIP. Do **not** edit `FactCycleCount`, its mapping, any measures, or the cutover date. Refresh `FactCycleCount` and compare to the existing report. If ZMM4TR003 History hasn't published yet, this loads the pre-cutover legacy data without reporting a folder-not-found error. Missing post-cutover records remain genuinely missing, not synthetic zeros.

**Important:** An SAP report with zero data can still be published as a valid header-only History CSV under Data Hub v0.6.1. If the folder remains absent after a *successful* ZMM4TR003 export, inspect that job's `history_last_error` and log rather than assuming this is normal. The query fallback merely accommodates the initial absence.

## Expected Data Hub output

| Report | Published canonical schema | Key tests |
|---|---|---|
| ZSD3TR009 | 95 columns, unchanged | `created_on`, `delv_item`, 226 rows in uploaded file |
| ZMM4TR012 | 48 columns, one additive field | `picked_car__2` and `sap_unlabelled_039` both retained |

`ZMM4TR012` additional field's business meaning is not yet established. Keep it in the central CSV and exclude it from KPIs until the SAP column is identified. Confirm that the new `Date` label in ZSD3TR009 represents the same business date as the old `Created on` field by checking representative SAP records.

## Rollback

With the Data Hub stopped, restore `app.py` and `processing/parser.py` from the timestamped backup folder. Restore prior Live CSV/JSON only if you intentionally want the prior published schemas; do **not** remove newly captured History until reviewed. Restart, leaving the scheduler paused until verified. The existing Power BI helper can likewise be restored from the `.pbix` backup.
