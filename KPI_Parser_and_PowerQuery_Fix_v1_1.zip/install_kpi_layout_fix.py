"""Conservative repair for the 2026-11-10 ZSD3TR009 and ZMM4TR012 SAP layouts.

Checks all anchors and syntax before applying. Works on Data Hub v0.6.1 with
existing app.py snapshot/retention additions; never replaces whole source files.
"""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import sys

TAG = 'KPI_LAYOUT_FIX_20261110_V1'


def replace_once(text: str, old: str, new: str, label: str) -> str:
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f'{label}: expected one supported anchor, found {n}. No changes applied.')
    return text.replace(old, new)


ZSD_NORMALISE = '''    # KPI_LAYOUT_FIX_20261110_V1: accept "Date" as the created-on date
    # only at the exact ZSD3TR009 delivery-header position.
    if job_id == "zsd3tr009":
        for candidate_i, candidate_line in enumerate(lines[:160]):
            fields = candidate_line.split("\\t")
            if (len(fields) == 97 and
                    fields[2].strip() == "ShPnt" and
                    fields[4].strip() == "Delv/Item"):
                date_label = fields[3].strip()
                if date_label == "Date":
                    fields[3] = "Created on"
                    lines[candidate_i] = "\\t".join(fields)
                elif date_label != "Created on":
                    raise ParseError(f"Unknown ZSD3TR009 date heading: {date_label!r}")
                break
'''

ZMM_NORMALISE = '''    # KPI_LAYOUT_FIX_20261110_V1: SAP uses wider labels in the November layout.
    # Retain the established CSV field identifiers used by Power BI.
    if job_id == "zmm4tr012":
        header = [{"Ship-to-party": "Ship-to-pa",
                   "Product Desc": "Product De",
                   "Profit centre name": "Profit cen"}.get(item, item)
                  for item in header]
        # The historical Excel file also has a numeric value in an unlabelled
        # position after "Picked carton Ind". Keep it, never discard it.
        if (len(header) == 51 and not header[38] and
                header[37].strip().casefold() == "picked car" and
                header[39].strip().casefold() == "shipper le"):
            header[38] = "sap_unlabelled_039"
'''

ZMM_CONTRACT = '''    # KPI_LAYOUT_FIX_20261110_V1: normalize both verified ZMM layouts into a
    # stable additive schema. The extra unnamed SAP field is always LAST.
    # This is deliberately not mapped to any business measure until identified.
    if job_id == "zmm4tr012":
        legacy_columns = (
            "profit_cen", "order_item", "po_no", "delivery_p", "delivery_c",
            "ship_to_pa", "ship_to_cu", "sold_to_cu", "material", "product_de",
            "delv_item", "delv_creat", "delv_creat__2", "planned_gd",
            "shipment_n", "ship_point", "ship_cond", "distr_cha", "ship_qty",
            "sales_unit", "ship_value", "docu_curre", "cartons_st", "line_item",
            "delivery_hu", "3s_lts", "ship_date", "profit_cen__2", "plant_name",
            "picked_car", "full_carto", "partials_p", "full_palle", "cartons_on",
            "picked_car__2", "shipper_le", "shipper_wi", "shipper_he",
            "dimension", "shipper_vo", "volume_uom", "plant", "unique_ord",
            "unique_del", "ship_value__2", "storage_lo", "building_n")
        extra_col = "sap_unlabelled_039"
        if tuple(n for n in published_names if n != extra_col) != legacy_columns:
            raise ParseError("ZMM4TR012 unrecognised business-column layout; "
                             "the file was not published")
        if extra_col in published_names:
            extra_idx = published_names.index(extra_col)
            preserved = [row.pop(extra_idx) for row in published_rows]
            published_names.pop(extra_idx)
            published_header.pop(extra_idx)
        else:
            preserved = [""] * len(published_rows)
        published_names.append(extra_col)
        published_header.append("Unlabelled SAP column 39 (unverified)")
        for row, value in zip(published_rows, preserved):
            row.append(value)
'''


def patch_parser(s: str) -> str:
    if TAG in s:
        raise RuntimeError('Parser already contains this fix. No changes made.')
    s = replace_once(s,
        '    lines = txt.splitlines()\n    header_i, main_head = _get_header(lines, job_id)',
        '    lines = txt.splitlines()\n' + ZSD_NORMALISE + '    header_i, main_head = _get_header(lines, job_id)',
        'ZSD3TR009 header recognition')
    # Compatible with v0.6.1 extra-trailing-tab trimming; the 32-column layout
    # retains an actual "Expedite" heading at position 32.
    s = replace_once(s,
        'if (len(continuation) != 30 or\n                    "sold to party address 3" not in continuation[0].casefold()):',
        'if (len(continuation) not in (30, 32) or\n                    "sold to party address 3" not in continuation[0].casefold() or\n                    continuation[-1].strip().casefold() != "expedite"):',
        'ZSD3TR009 continuation guard')
    s = replace_once(s,
        '                if len(cells) == 31 and not _is_data(job_id, cells):\n                    ignored_totals += 1\n                    continue',
        '''                # KPI_LAYOUT_FIX_20261110_V1: SAP totals use 30 or 31 slots.
                # Require a numeric amount + three-letter currency, with no
                # delivery fields; never hide a malformed delivery record.
                nonblank_positions = {i for i, value in enumerate(cells) if value.strip()}
                is_currency_total = (
                    len(cells) in (30, 31) and
                    nonblank_positions.issubset({1, len(cells) - 3, len(cells) - 1}) and
                    bool(NUM.fullmatch(cells[-3].strip())) and
                    bool(re.fullmatch(r"[A-Z]{3}", cells[-1].strip())))
                if is_currency_total:
                    ignored_totals += 1
                    continue''',
        'ZSD3TR009 currency totals')
    s = replace_once(s,
        '    names = _columns(header)\n',
        ZMM_NORMALISE + '    names = _columns(header)\n',
        'ZMM4TR012 header normalisation')
    s = replace_once(s,
        '    return Parsed(job_id, published_names, published_header, published_rows, enc,',
        ZMM_CONTRACT + '    return Parsed(job_id, published_names, published_header, published_rows, enc,',
        'ZMM4TR012 stable schema')
    compile(s, 'processing/parser.py', 'exec')
    return s


def patch_app(s: str) -> str:
    if TAG in s:
        raise RuntimeError('App already contains this fix. No changes made.')
    s = replace_once(s,
        '            if prior_headers and prior_headers != current_headers:\n                raise ParseError("Column layout changed since prior published export; last good CSV retained. "',
        '''            if prior_headers and prior_headers != current_headers:
                # KPI_LAYOUT_FIX_20261110_V1: permit only this verified ADDITIVE
                # ZMM4TR012 upgrade; all other schema changes still fail closed.
                approved_extra = (jid == "zmm4tr012" and
                                  current_headers == prior_headers + ["sap_unlabelled_039"])
                if not approved_extra:
                    raise ParseError("Column layout changed since prior published export; last good CSV retained. "''',
        'Live strict-schema guard')
    # The existing second line of the raise must also be nested one level deeper.
    # A direct single-block anchor keeps unrelated controller edits untouched.
    s = replace_once(s,
        '                    raise ParseError("Column layout changed since prior published export; last good CSV retained. "\n                                 "Check layout and schema JSON before enabling a new schema")',
        '                    raise ParseError("Column layout changed since prior published export; last good CSV retained. "\n                                     "Check layout and schema JSON before enabling a new schema")',
        'Live exception indentation')
    s = replace_once(s,
        '            if old_cols and old_cols != details["columns"]:\n                raise ParseError("History schema changed: previous dated CSV retained")',
        '''            if old_cols and old_cols != details["columns"]:
                # KPI_LAYOUT_FIX_20261110_V1: one additive, recorded ZMM schema change.
                approved_extra = (jid == "zmm4tr012" and
                                  details["columns"] == old_cols + ["sap_unlabelled_039"])
                if not approved_extra:
                    raise ParseError("History schema changed: previous dated CSV retained")''',
        'History strict-schema guard')
    compile(s, 'app.py', 'exec')
    return s


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--hub-root', required=True, type=Path)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--check', action='store_true')
    g.add_argument('--apply', action='store_true')
    args = p.parse_args()
    src = {"parser.py": args.hub_root/'processing'/'parser.py',
           "app.py": args.hub_root/'app.py'}
    for f in src.values():
        if not f.is_file():
            raise SystemExit(f'Expected Data Hub source file missing: {f}')
    originals = {n: p.read_text(encoding='utf-8-sig') for n,p in src.items()}
    updated = {'parser.py': patch_parser(originals['parser.py']),
               'app.py': patch_app(originals['app.py'])}
    print('Compatibility check passed: both source files support the targeted fix.')
    if args.check: return
    stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_dir = args.hub_root/'runtime'/'kpi_layout_fix_backups'/stamp
    backup_dir.mkdir(parents=True, exist_ok=False)
    for name,path in src.items():
        shutil.copy2(path, backup_dir/name)
    try:
        for name,path in src.items():
            tmp=path.with_name('.'+path.name+'.kpi_layout.tmp')
            try:
                tmp.write_text(updated[name], encoding='utf-8', newline='\n')
                os.replace(tmp,path)
            finally:
                tmp.unlink(missing_ok=True)
    except Exception:
        for name,path in src.items():
            shutil.copy2(backup_dir/name,path)
        raise
    print(f'Installed. Original files saved in {backup_dir}')
    print('Restart the Data Hub with scheduling paused; parse the two saved raw files first.')


if __name__ == '__main__':
    main()
