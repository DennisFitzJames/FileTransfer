# Verification — MB51 compatibility patch

Tested against the user's 11-Nov-2026 MB51 TXT and the original Data Hub parser's known MB51 CSV output fields. The source TXT has **51 data records, 22 fields**, and its current parsed CSV and JSON agree.

| Test | Result |
|---|---|
| Simulated 22-field previously published Live schema with `user` / `unl_point` | PASS |
| Raw TXT parser produces current `user_name` / `unloading_point` | PASS |
| Read-only compatibility check | PASS |
| Approve two aliases and stage through the installed central compatibility layer | PASS |
| Every row value retained in original column order | PASS |
| Other job aliases preserved | PASS |
| Re-running installer is a no-op | PASS |
| Refuses conflicting alias assignments | PASS |
| Refuses inconsistent Live CSV and JSON | PASS |
| Alias backup and verified rollback | PASS |

**Tests used a synthetic published Live fixture**, not your actual W: drive. Your own `--check` requires and verifies the real published Live CSV, Live schema JSON, pinned MB51 contract, installed parser and the supplied raw TXT. No untested alias will be installed automatically.

Power BI helper source was inspected from the supplied original Logistics KPI cutover package: `FactMB51.pq` references `KPI_AllowMB51MissingItem`; that package's helper was `false`. The original `FactMB51.pq` was intentionally not replaced.
