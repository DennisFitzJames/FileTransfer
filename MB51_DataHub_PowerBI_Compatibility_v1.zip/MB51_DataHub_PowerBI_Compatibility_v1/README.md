# MB51 Data Hub + Power BI compatibility correction

**Scope:** Resolve the two confirmed MB51 name-only mismatches in the **already-installed Shared SAP Data Hub Schema Contracts v2** layer and provide the missing `KPI_AllowMB51MissingItem` Power Query setting. This is a targeted correction, **not a replacement** for the consolidated Data Hub installation.

## Diagnosis (11 November 2026)

The uploaded `mb51.txt` parses as **51 rows / 22 columns**. Its corresponding CSV/schema JSON agree with the parsed layout. They are **candidate output**, not proof of the currently published Live layout.

The actual Data Hub rejection reports exactly two name differences, both position-preserving:

| 1-based column | Already-published Live | New parser output | Approved equivalence |
|---|---|---|---|
| 14 | `user` | `user_name` | SAP `User` / `User name` |
| 21 | `unl_point` | `unloading_point` | SAP `Unl. Point` / `Unloading Point` |

No other new columns appear in the user's error. The installer independently verifies that W: Live CSV, W: Live JSON, the locally pinned contract and the provided raw parser result match the **exact verified 22-column layouts** before approving anything.

The Power BI `Expression.Error: The import KPI_AllowMB51MissingItem matches no exports` is independent. That query is an intentionally disabled approval gate for the **genuinely missing** `Sales order item` column in newer MB51 exports. Adding the helper with `false` resolves the *missing reference* but **does not approve the migration**: `FactMB51` will then show the intentional approval error instead. Do not toggle to `true` without checking relevant model relationships/measures, because new records will have null for that field.

## Part A: Data Hub — first check only

1. Pause Data Hub scheduling; allow active jobs to finish and close the controller. Back up the Data Hub root folder.
2. Extract this ZIP to `C:\KPI_MB51_Compatibility`.
3. Save **the same actual failed MB51 TXT** as `C:\KPI_Test\mb51.txt`.
4. Open Command Prompt and run:

```bat
cd /d "C:\KPI_MB51_Compatibility"
py -3 install_mb51_aliases.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\mb51.txt" --check
```

Expected: 51 rows, 22 columns (if using the uploaded 11-Nov sample); agreement between Live CSV/JSON and pinned contract; only the two reviewed name aliases; no reordered columns. `--check` writes nothing.

**If it fails, stop.** Send the console output; your actual Live schema or installed parser may differ from the one diagnosed. Do not manually replace the Live schema or turn off strict validation.

## Part B: Approve the two aliases

```bat
py -3 install_mb51_aliases.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\mb51.txt" --apply
```

This updates **only** `DataHub-main\schema_contracts\aliases.json`, appending two report-scoped groups:

```json
"mb51": [["user", "user_name"], ["unl_point", "unloading_point"]]
```

It preserves existing groups for TR093, ZSD3TR009 and every other job. The script automatically backs up the old aliases file, runs a **temporary staged export** through the installed schema-contract code, and checks every CSV record was preserved. It restores the old aliases automatically if the staged test fails.

The installer is idempotent: a second run reports already approved and changes nothing. It never writes to W: Live, Raw, History, or your app/parser source code.

Restart Data Hub with scheduling paused; run **MB51 once**. Confirm the new Live CSV and JSON still have column 14 `user` and column 21 `unl_point` and the job publishes without a schema error. Then resume scheduling.

### Rollback

The installer prints a `.manifest.json` path under `DataHub-main\schema_contracts\backups`. Stop Data Hub first, then run:

```bat
py -3 install_mb51_aliases.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --rollback "FULL_PATH_TO_PRINTED_MANIFEST.json"
```

It refuses to overwrite any alias changes made since the patch was installed.

## Part C: Power BI — create the missing setting

In a **copy** of the Logistics KPIs PBIX:

1. Power BI Desktop -> **Transform data** -> **New Source** -> **Blank Query**.
2. Rename this query **exactly** `KPI_AllowMB51MissingItem` (no spaces).
3. Open **Advanced Editor** and paste the contents of `PowerQuery\00_KPI_AllowMB51MissingItem.pq`: `false`.
4. Disable **Enable load** for this small helper query.

This fixes the missing *symbol* error only. `FactMB51` will instead give the explicit warning about the new SAP source lacking `Sales order item`. **This is intentional.** The existing legacy data still includes its historic Sales order item values; the new source does not.

**To proceed with MB51 migration only after checking the DAX/relationships**: change the helper expression from `false` to `true`. The replacement `FactMB51` query (from the previous cutover ZIP) will then create `Sales order item = null` for new Data Hub dates. If the field is important, keep the existing MB51 Power Query source until a proper upstream solution exists instead of approving nulls.

If your version of the Power Query adapter has already been modified, don't overwrite it from an older ZIP. The alias fix restores the original Data Hub output names expected by the cutover `FactMB51` mapping (`user`).

## Important limitations

- The aliases resolve only two **proved header/name differences**, not an arbitrary SAP layout change. Any future physical column addition, deletion or ambiguous shift still fails safely.
- The provided MB51 TXT is not evidence of whether the historical `Sales order item` column can be reconstructed. It is absent from the new report: **do not substitute `Unloading Point`, `Order`, or another field**.
- Power BI's `KPI_AllowMB51MissingItem` error is unrelated to Data Hub schema validation. They require separate actions.
- If the latest MB51 export already published successfully, running again may replace its Live dataset normally; the installer itself never does so.
