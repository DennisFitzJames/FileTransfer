"""Review and approve exactly two verified MB51 column-name aliases.

Only updates DataHub-main/schema_contracts/aliases.json. NEVER writes Live,
History, Raw, config, app.py, parser.py or Power BI files.

Require the Shared SAP Data Hub consolidated schema-contracts layer to be
installed first. Strict fail-closed comparison against actual W: Live and
pinned contract plus the caller's failed MB51 TXT.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

JOB = "mb51"
EXPECTED_LIVE = [
    "material", "batch", "plnt", "sloc", "mvt", "s", "mat_doc", "item",
    "pstng_date", "time", "quantity", "eun", "text", "user", "amount_lc",
    "crcy", "cost_ctr", "vendor", "customer", "order", "unl_point",
    "material_description",
]
EXPECTED_PARSED = EXPECTED_LIVE.copy()
EXPECTED_PARSED[13] = "user_name"
EXPECTED_PARSED[20] = "unloading_point"
REQUIRED = [("user", "user_name"), ("unl_point", "unloading_point")]


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON must be an object: {path}")
    return value


def columns_from_json(path: Path) -> list[str]:
    fields = read_json(path).get("columns")
    if not isinstance(fields, list):
        raise ValueError(f"No columns in {path}")
    out = [field.get("name") if isinstance(field, dict) else field for field in fields]
    if not all(isinstance(x, str) and x for x in out) or len(set(out)) != len(out):
        raise ValueError(f"Invalid or duplicate names in {path}")
    return out


def csv_headers(path: Path) -> list[str]:
    with path.open("r", encoding="utf-8-sig", newline="") as file:
        return next(csv.reader(file))


def module_at(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load module: {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def plan_registry(registry: dict) -> tuple[dict, bool]:
    if registry.get("version") != 1 or not isinstance(registry.get("jobs"), dict):
        raise ValueError("Unsupported schema-contract alias registry format")
    output = json.loads(json.dumps(registry))
    groups = output["jobs"].setdefault(JOB, [])
    if not isinstance(groups, list) or any(
        not isinstance(g, list) or len(g) < 2 or not all(isinstance(x, str) and x for x in g)
        for g in groups
    ):
        raise ValueError("MB51 aliases are invalid; stop for manual review")
    seen = {}
    for i, group in enumerate(groups):
        for field in group:
            key = field.casefold().strip()
            if key in seen:
                raise ValueError(f"MB51 aliases conflict at {field}: groups {seen[key]} and {i}")
            seen[key] = i
    changed = False
    for left, right in REQUIRED:
        if any({left, right}.issubset(set(g)) for g in groups):
            continue
        if left in seen or right in seen:
            raise ValueError(f"MB51 aliases overlap existing group: {left}, {right}")
        groups.append([left, right])
        seen[left] = seen[right] = len(groups) - 1
        changed = True
    return output, changed


def check(root: Path, raw: Path):
    config_path = root / "config.json"
    registry_path = root / "schema_contracts" / "aliases.json"
    contract_path = root / "schema_contracts" / "mb51.json"
    module_path = root / "processing" / "schema_contracts.py"
    parser_path = root / "processing" / "parser.py"
    app_path = root / "app.py"
    for path in [config_path, registry_path, contract_path, module_path, parser_path, app_path, raw]:
        if not path.is_file():
            raise ValueError(f"Missing required file: {path}")
    if "from processing.schema_contracts import align_staged_to_live" not in app_path.read_text(encoding="utf-8-sig"):
        raise ValueError("Data Hub controller does not appear to call the central schema-contract layer")
    cfg = read_json(config_path)
    publish = Path(cfg.get("storage", {}).get("publish_root", ""))
    if not publish.is_dir():
        raise ValueError(f"Cannot access configured publish root: {publish}. Check your W: mapping")
    live_dir = publish / "Live" / JOB
    live_schema = live_dir / f"{JOB}_schema.json"
    live_csv = live_dir / f"{JOB}_latest.csv"
    if not live_schema.is_file() or not live_csv.is_file():
        raise ValueError("MB51 Live schema/CSV pair missing; cannot safely approve aliases")
    live = columns_from_json(live_schema)
    if csv_headers(live_csv) != live:
        raise ValueError("MB51 Live CSV and Live JSON have inconsistent column names")
    if live != EXPECTED_LIVE:
        raise ValueError(f"Unexpected existing MB51 Live schema.\n  expected={EXPECTED_LIVE}\n  actual={live}")
    pin = read_json(contract_path)
    if pin.get("job_id") != JOB or pin.get("contract_version") != 1 or columns_from_json(contract_path) != live:
        raise ValueError("Pinned MB51 contract differs from current Live schema")
    parser = module_at(parser_path, "_installed_mb51_parser_preview")
    parsed = parser.parse_file(raw, JOB)
    if parsed.no_data or not parsed.rows:
        raise ValueError("Raw MB51 file is empty; use a populated failing TXT for verification")
    if parsed.headers != EXPECTED_PARSED:
        raise ValueError(f"MB51 parsed layout differs from verified file:\n  expected={EXPECTED_PARSED}\n  actual={parsed.headers}")
    if [x.strip() for x in parsed.source_headers][13] != "User name" or [x.strip() for x in parsed.source_headers][20] != "Unloading Point":
        raise ValueError("Expected SAP source headings not found at positions 14 and 21")
    if any(len(row) != len(EXPECTED_PARSED) for row in parsed.rows):
        raise ValueError("Inconsistent MB51 parsed row width")
    layer = module_at(module_path, "_installed_mb51_schema_layer_preview")
    for key in ("_mapping", "_known_alias_groups", "align_staged_to_live"):
        if not hasattr(layer, key):
            raise ValueError(f"Installed compatibility layer is missing {key}; refuse unknown version")
    registry = read_json(registry_path)
    proposed, changed = plan_registry(registry)
    aliases = [[layer.canonical(v) for v in group] for group in proposed["jobs"][JOB]]
    if layer._mapping(parsed.headers, live, aliases, JOB) != list(range(len(live))):
        raise ValueError("Alias mapping would move data columns; refusing to approve")
    print("MB51 source TXT:", raw)
    print("MB51 records / fields:", len(parsed.rows), "/", len(parsed.headers))
    print("Live CSV and JSON: exact 22-field match")
    print("Pinned contract: exact Live match")
    print("Reviewed aliases: user_name -> user; unloading_point -> unl_point")
    print("Data positions: unchanged (no reorder and no dropped fields)")
    print("Existing aliases: preserved")
    print("Action:", "APPROVE 2 aliases" if changed else "ALREADY APPROVED; no change")
    return registry_path, registry, proposed, changed, parser, layer, publish


def atomic_save(path: Path, data: dict):
    payload = (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    fd, tmppath = tempfile.mkstemp(dir=path.parent, prefix=".mb51_aliases_", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmppath, path)
    finally:
        if os.path.exists(tmppath):
            os.unlink(tmppath)


def verify_after(root: Path, raw: Path, parser, layer, publish: Path):
    # Write ONLY to a temporary local staging directory. No Live/History writes.
    with tempfile.TemporaryDirectory(prefix="mb51_alias_test_") as name:
        stage = Path(name)
        csv_out, json_out = stage / "mb51_stage.csv", stage / "mb51_stage.json"
        summary = parser.process_to_csv(raw, JOB, csv_out, json_out)
        corrected = layer.align_staged_to_live(root, publish, JOB, csv_out, json_out, summary)
        if csv_headers(csv_out) != EXPECTED_LIVE or [c["name"] for c in corrected["columns"]] != EXPECTED_LIVE:
            raise ValueError("Post-install MB51 staging does not reproduce the published contract")
        if columns_from_json(json_out) != EXPECTED_LIVE:
            raise ValueError("Post-install MB51 metadata does not reproduce the published contract")
        # Confirm row payload is exactly the parsed data, same order; no value dropped.
        with csv_out.open(encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.reader(handle))[1:]
        if len(rows) != len(parsed_rows := parser.parse_file(raw, JOB).rows):
            raise ValueError("Post-install row count changed")
        # Normalised CSV values may differ in formatting from raw parse data;
        # verify only the two changed fields against their original staged values
        # by re-processing to another temporary file and comparing complete rows.
        orig_csv = stage / "original.csv"
        orig_meta = stage / "original.json"
        parser.process_to_csv(raw, JOB, orig_csv, orig_meta)
        with orig_csv.open(encoding="utf-8-sig", newline="") as handle:
            original_rows = list(csv.reader(handle))[1:]
        if original_rows != rows:
            raise ValueError("Post-install staging altered MB51 row values")
        print("PASS: Staged MB51 CSV + JSON use stable Live fields; row values unchanged")


def apply(root: Path, raw: Path):
    target, old, proposed, changed, parser, layer, publish = check(root, raw)
    if not changed:
        verify_after(root, raw, parser, layer, publish)
        print("NO-OP: MB51 aliases were already installed")
        return
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backups = target.parent / "backups"
    backups.mkdir(exist_ok=True)
    backup = backups / f"mb51_aliases_before_{timestamp}.json"
    shutil.copy2(target, backup)
    old_hash = sha256(target)
    try:
        atomic_save(target, proposed)
        verify_after(root, raw, parser, layer, publish)
    except BaseException:
        # Restore the exact original bytes if the new alias configuration fails.
        shutil.copy2(backup, target)
        print("ROLLBACK COMPLETE: original alias registry restored", file=sys.stderr)
        raise
    manifest = backups / f"mb51_aliases_before_{timestamp}.manifest.json"
    manifest.write_text(json.dumps({
        "source_backup": str(backup), "target": str(target),
        "before_sha256": old_hash, "after_sha256": sha256(target),
    }, indent=2), encoding="utf-8")
    print("APPLIED: MB51 aliases approved in central registry")
    print("BACKUP:", backup)
    print("ROLLBACK MANIFEST:", manifest)
    print("No Live/History/Raw/Power BI or parser/controller code changed")


def rollback(root: Path, manifest: Path):
    data = read_json(manifest)
    target = root / "schema_contracts" / "aliases.json"
    backup = Path(data.get("source_backup", ""))
    if Path(data.get("target", "")) != target:
        raise ValueError("Rollback manifest belongs to a different Data Hub")
    if not backup.is_file() or sha256(backup) != data["before_sha256"]:
        raise ValueError("Backup is missing or was modified")
    if not target.is_file() or sha256(target) != data["after_sha256"]:
        raise ValueError("Current aliases changed since install; refusing to overwrite later edits")
    shutil.copy2(backup, target)
    print("RESTORED previous alias configuration; restart Data Hub controller")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--hub-root", type=Path, required=True)
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--apply", action="store_true")
    mode.add_argument("--rollback", type=Path, metavar="MANIFEST")
    ap.add_argument("--raw", type=Path, help="The actual failed MB51 SAP TXT (required for --check/--apply)")
    a = ap.parse_args()
    root = a.hub_root.resolve()
    try:
        if a.rollback is not None:
            rollback(root, a.rollback.resolve())
            return
        if a.raw is None:
            ap.error("--raw is required with --check/--apply")
        raw = a.raw.resolve()
        if a.check:
            check(root, raw)
            print("CHECK ONLY: no files changed")
        else:
            apply(root, raw)
    except Exception as exc:
        print("FAILED:", exc, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
