# Shared SAP Data Hub — ZSD3TR009 semantic-layout fix v1.4

## Why this is different from v1.1–v1.3

SAP dynamically redistributes tabs and sometimes moves a *named* column across the first/second-line split of the ZSD3TR009 TXT report. The 10 November 2026 15:03 export moves `Sold to party Address 3` from the start of the continuation header to the end of the first header line. The continuation line starts with `Telephone1` instead. In the same source, `Delv/Item` moved to physical position 6, although its logical output position remains 3.

The report retains exactly **95 named business fields in the same order**. The parser should recognise that semantic sequence, not insist on specific tab coordinates or the previous wrapped-panel boundary. This package hardens **only ZSD3TR009** and does not suppress the strict Live/History schema guards.

## Files

- `install_zsd_semantic_layout_v14.py`: read-only candidate validation (`--check`), then guarded in-place install (`--apply`); built-in backup and Live schema comparison.
- `TEST_RESULTS.md`: tested file counts, data alignment checks, regression tests and negative tests.

## Installation — do not skip the check

1. **Stop/pause the Data Hub scheduler and controller** and let running exports finish. Back up the Data Hub folder and your published Live/History data. In particular preserve `Live\zsd3tr009\zsd3tr009_latest.csv` and `Live\zsd3tr009\zsd3tr009_schema.json`.
2. Extract the ZIP to `C:\KPI_ZSD_Fix_v1_4`.
3. Copy the **latest failing** ZSD3TR009 TXT (`zsd3tr009 2.txt`, the 15:03 export supplied in chat) to `C:\KPI_Test\zsd3tr009.txt`.
4. In Command Prompt:

   ```bat
   cd /d C:\KPI_ZSD_Fix_v1_4

   py -3 install_zsd_semantic_layout_v14.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\zsd3tr009.txt" --check
   ```

   Expected for this exact TXT: **119 records, 95 columns, 4 excluded currency totals**. It should also say that the *actual* W: Live schema and CSV contain the same 95 names. **If it prints `FAILED`, do not apply.** Send the console output; it will identify any mismatch between the real published contract and the candidate output. (This matters because the reported error was a strict schema mismatch, whereas this particular uploaded TXT is rejected at header recognition by the reconstructed v1.3 parser.)
5. If, and **only if**, all checks pass:

   ```bat
   py -3 install_zsd_semantic_layout_v14.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\zsd3tr009.txt" --apply
   ```

   The installer updates **only** `processing\parser.py`, using exact matching anchors. It saves the previous parser under `DataHub-main\runtime\kpi_layout_fix_backups\zsd_semantic_v14_<timestamp>\parser.py`. It neither edits `app.py` nor touches any existing CSV, JSON, Raw TXT, History, Power BI query or config.
6. Restart the Data Hub **with scheduling still paused**. Run a fresh **ZSD3TR009** SAP export once. Inspect the Live CSV/JSON timestamps and one representative record. For this snapshot-type job, confirm the daily History snapshot according to your current policy; an existing daily snapshot may intentionally remain unchanged. Then resume scheduling after the job is healthy.

## What the patch changes

- Recognises the ZSD3TR009 `ShPnt` + `Date` / `Created on` + `Delv/Item` header by its named fields, not the physical tab index of `Delv/Item`.
- Treats `Date` as the existing published `created_on` field, **without assuming the business meaning**. Confirm this mapping with SAP when possible.
- Approves **only** the verified ordered set of 95 named headers. Unexpected named fields or reordered fields still raise a parse error.
- Handles two-panel layouts whether `Sold to party Address 3` is in panel one or two. Validates all physical data positions and refuses populated unnamed columns and populated overhangs.
- Recognises 30-/31-position currency summary rows with a shifted amount position, but only when there are no delivery keys or other business data.

**Important:** This does **not** fix MB51. The MB51 Live schema difference remains unverified. Nor does it automatically authorise arbitrary schema changes for other reports. We should use the existing all-report read-only schema toolkit to assemble approved per-job contracts for the whole Data Hub after this incident is stable.

## When the check refuses installation

- **Live schema mismatch:** The tool prints the specific differing names and refuses to change the parser. Provide its console output and, if needed, the `Live\zsd3tr009\zsd3tr009_schema.json` (not just the Raw TXT).
- **Parser code anchors differ:** The current parser has a different version or local edits; no code is changed. Provide the console output and existing `processing\parser.py` for a custom compatibility patch.
- **W: not accessible:** Open the W: drive from the same user session or investigate the Windows network mapping; do not bypass schema validation.
- **No Live schema yet:** The check warns that it cannot compare the prior contract; review before publishing the first Live export.
- **Already installed:** The script exits without changes. Do not reapply.

## Rollback

Stop the controller, copy the backed-up `parser.py` from the printed backup path over `DataHub-main\processing\parser.py`, and restart with scheduling paused. Existing Live and History data were not changed by the installer. If you already ran a successful export, review the resulting published files separately before attempting any rollback of data.
