"""Data Hub ZSD3TR009 semantic layout hardening v1.4.

Only edits processing/parser.py. Refuses unexpected source code or published
Live schemas. Runs an in-memory parse against supplied actual SAP TXT files
before any installation. Always backs up before applying.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import io
import json
import os
from pathlib import Path
import shutil
import sys
import types

TAG = "KPI_ZSD_SEMANTIC_LAYOUT_V14"
REQUIRES = ("KPI_LAYOUT_FIX_20261110_V1", "KPI_LAYOUT_FIX_20261110_V2")

# Intentionally require exact known anchors; don't overwrite local modifications.
PATCHES = [
    ('add stable ZSD contract', 'NO_DATA_MARKERS = ', "# ZSD3TR009 approved semantic output contract (in published order).\nZSD3TR009_STABLE_FIELDS = ('shpnt', 'created_on', 'delv_item', 'delivery_item_category', 'sales_item', 'sales_ord_item_category', 'trans_item', 'po', 'material', 'storage_lo', 'cust_mat_no', 'net_value', 'cur', 'cust', 'cust_name', 'soff', 'sgrp', 'ind', 'route', 'country', 'description', 'batch', 'qty', 'su', 'wgt_in_kg', 'moq', 'dly_unit', 'shipperq', 'db', 'm', 'i', 'a', 'or', 'pack_dt', 'late', 'status', 'pgi_date', 'mrp', 'profit_cen', 'prodcom', 'pc_descrip', 'hs_code', 'pc_cn_desc', 'customer', 'ship_to_name', 'ctr', 'name', 'shipment_n', 'high_lv_shpmnt', 'overallsta', 'carrier_no', 'carrier_name', 'del_type', 'specprocid', 'container', 'ext_id_1', 'ext_id_2', 'haz_matl', 'vol', 'vol_un', 'grs_wt', 'wt_un', 'mdq_sales', 'customer_po_number', 'estimated_number_of_boxes', 'weight_source', 'city', 'pickable_items', 'open_picks', 'main_items', 'delivery', 'item', 'ship_to_party_address_1', 'ship_to_party_address_2', 'ship_to_party_address_3', 'telephone1', 'post_code', 'sold_to_party_address_1', 'sold_to_party_address_2', 'sold_to_party_address_3', 'telephone1__2', 'city__2', 'post_code__2', 'net_price', 'unit', 'unit__2', 'dlv_prior', 'extra_mark', 'time', 'bldg_nbr', 'transfer_agent', 'load_id', 'old_loadid', 'extrn_load', 'expedite')\n\nNO_DATA_MARKERS = "),
    ('ZSD header recognition', '    # KPI_LAYOUT_FIX_20261110_V1: accept "Date" as the created-on date\n    # only at the exact ZSD3TR009 delivery-header position.\n    if job_id == "zsd3tr009":\n        for candidate_i, candidate_line in enumerate(lines[:160]):\n            fields = candidate_line.split("\\t")\n            if (len(fields) in (97, 98) and\n                    fields[2].strip() == "ShPnt" and\n                    fields[4].strip() == "Delv/Item"):\n                date_label = fields[3].strip()\n                if date_label == "Date":\n                    fields[3] = "Created on"\n                    lines[candidate_i] = "\\t".join(fields)\n                elif date_label != "Created on":\n                    raise ParseError(f"Unknown ZSD3TR009 date heading: {date_label!r}")\n                break\n', '    # KPI_ZSD_SEMANTIC_LAYOUT_V14: SAP changes tab spacing and even which\n    # physical line holds Sold to party Address 3. Match the *named fields*\n    # rather than assuming Delv/Item occupies one fixed tab position.\n    if job_id == "zsd3tr009":\n        for candidate_i, candidate_line in enumerate(lines[:160]):\n            fields = candidate_line.split("\\t")\n            stripped = [x.strip() for x in fields]\n            if "ShPnt" not in stripped or "Delv/Item" not in stripped:\n                continue\n            if (len(fields) < 85 or len(fields) > 120 or len(fields) <= 3 or\n                    stripped[2] != "ShPnt" or stripped[3] not in ("Date", "Created on")):\n                raise ParseError("ZSD3TR009 unapproved header anchors or physical width")\n            if stripped.count("ShPnt") != 1 or stripped.count("Delv/Item") != 1:\n                raise ParseError("ZSD3TR009 ambiguous duplicate report header markers")\n            fields[3] = "Created on"\n            lines[candidate_i] = "\\t".join(fields)\n            break\n'),
    ('ZSD continuation wrapping', '        if job_id == "zsd3tr009":\n            # Accept a harmless extra trailing tab, but do not alter the\n            # positions of any populated continuation-header fields.\n            while len(continuation) > 30 and not continuation[-1].strip():\n                continuation.pop()\n            if (len(continuation) not in (30, 32, 33) or\n                    "sold to party address 3" not in continuation[0].casefold() or\n                    continuation[-1].strip().casefold() != "expedite"):\n                raise ParseError(\n                    f"ZSD3TR009 continuation header at line {continuation_i + 1}: "\n                    f"expected 30 tab positions beginning \'Sold to party Address 3\', "\n                    f"got {len(continuation)} positions and "\n                    f"first field={continuation[0][:80]!r} if available. "\n                    "Check the exact Raw file from the failed run."\n                )\n', '        if job_id == "zsd3tr009":\n            # The wrapped panel may begin with Sold to party Address 3, OR\n            # with Telephone1 if SAP fitted the address onto the first panel.\n            # Width is intentionally not fixed: only approved semantic order\n            # and fully validated (non-dropped) data positions are accepted.\n            while len(continuation) > 45 and not continuation[-1].strip():\n                continuation.pop()\n            main_named = [v.strip() for v in main_head if v.strip()]\n            second_named = [v.strip() for v in continuation if v.strip()]\n            if (not 24 <= len(continuation) <= 45 or\n                    not second_named or second_named[-1].casefold() != "expedite" or\n                    (second_named[0].casefold() not in\n                     ("sold to party address 3", "telephone1")) or\n                    ("sold to party address 3" not in\n                     [x.casefold() for x in main_named + second_named])):\n                raise ParseError("ZSD3TR009 unapproved continuation panel or missing Expedite")\n            full_header = main_head + [_clean(v) for v in continuation]\n            semantic = [_columns(full_header)[idx] for idx, h in enumerate(full_header) if h.strip()]\n            if tuple(semantic) != ZSD3TR009_STABLE_FIELDS:\n                first = next((i for i,(actual,approved) in enumerate(zip(semantic, ZSD3TR009_STABLE_FIELDS),1)\n                              if actual != approved), None)\n                raise ParseError(\n                    f"ZSD3TR009 unapproved business-column layout: first mismatch at {first}; "\n                    f"actual named fields={len(semantic)}, approved={len(ZSD3TR009_STABLE_FIELDS)}")\n'),
    ('ZSD currency totals', '                # KPI_LAYOUT_FIX_20261110_V1: SAP totals use 30 or 31 slots.\n                # Require a numeric amount + three-letter currency, with no\n                # delivery fields; never hide a malformed delivery record.\n                nonblank_positions = {i for i, value in enumerate(cells) if value.strip()}\n                is_currency_total = (\n                    len(cells) in (30, 31) and\n                    nonblank_positions.issubset({1, len(cells) - 3, len(cells) - 1}) and\n                    bool(NUM.fullmatch(cells[-3].strip())) and\n                    bool(re.fullmatch(r"[A-Z]{3}", cells[-1].strip())))\n', '                # KPI_ZSD_SEMANTIC_LAYOUT_V14: SAP shifts the currency\n                # summary amount by a tab when widening the header. Only\n                # skip rows containing NO delivery key and nothing except\n                # the explicit total amount, ISO currency and optional \'*\'.\n                currency = cells[-1].strip() if cells else ""\n                candidates = [i for i in range(max(0, len(cells) - 4), len(cells) - 1)\n                              if NUM.fullmatch(cells[i].strip())]\n                amount_pos = candidates[0] if len(candidates) == 1 else -1\n                is_currency_total = (\n                    25 <= len(cells) <= 40 and\n                    bool(re.fullmatch(r"[A-Z]{3}", currency)) and\n                    len(candidates) == 1 and\n                    cells[1].strip() in ("", "*") and\n                    all((not value.strip() or i in (1, amount_pos, len(cells)-1))\n                        for i, value in enumerate(cells)))\n'),
    ('ZSD empty tab overhang', '            if len(cells) > continuation_limit:\n                raise ParseError(f"ZSD3TR009 continuation too wide at line {line_no}")\n            row = pending + _check_row(cells, continuation_limit, job_id, line_no)\n', '            # _check_row rejects populated overhangs while safely trimming\n            # trailing empty SAP tabs (a formatting-only difference).\n            row = pending + _check_row(cells, continuation_limit, job_id, line_no)\n'),
 ]


def patch(source: str) -> str:
    if TAG in source:
        raise RuntimeError("v1.4 already installed; nothing changed")
    for tag in REQUIRES:
        if tag not in source:
            raise RuntimeError(f"Required prior parser patch missing: {tag}")
    for label, old, new in PATCHES:
        count = source.count(old)
        if count != 1:
            raise RuntimeError(f"{label}: expected one code anchor, found {count}; no changes made")
        source = source.replace(old, new, 1)
    compile(source, "processing/parser.py", "exec")
    return source


def load_in_memory(source: str):
    module = types.ModuleType("_kpi_zsd_semantic_v14_preview")
    module.__file__ = "processing/parser.py"
    sys.modules[module.__name__] = module
    exec(compile(source, module.__file__, "exec"), module.__dict__)
    return module


def names_from_schema(path: Path):
    doc = json.loads(path.read_text(encoding="utf-8-sig"))
    return [c["name"] if isinstance(c, dict) else c for c in doc["columns"]]


def check_live_contract(root: Path, expected: list[str]):
    cfg = json.loads((root / "config.json").read_text(encoding="utf-8-sig"))
    publish = Path(cfg["storage"]["publish_root"])
    schema = publish / "Live" / "zsd3tr009" / "zsd3tr009_schema.json"
    csvfile = publish / "Live" / "zsd3tr009" / "zsd3tr009_latest.csv"
    print(f"Configured publish root: {publish}")
    if not publish.is_dir():
        raise RuntimeError(f"W: publish root is not accessible: {publish}")
    if schema.exists():
        old = names_from_schema(schema)
        if old != expected:
            mismatches = [(i, a, b) for i,(a,b) in enumerate(zip(old,expected),1) if a!=b]
            print(f"Live schema mismatch: stored={len(old)} expected={len(expected)}")
            for i,a,b in mismatches[:15]:print(f"  Column {i}: live={a!r}, candidate={b!r}")
            if len(old) != len(expected):print("  Field count changed: manual review required")
            raise RuntimeError("Published schema differs from approved 95-field contract; supply Live schema JSON before changing anything")
        print("PASS: current Live schema matches all 95 approved field names")
    else:
        print("WARNING: no existing published Live schema; cannot check historic contract")
    if csvfile.exists():
        with csvfile.open("r", encoding="utf-8-sig", newline="") as h:
            actual = next(csv.reader(h))
        if actual != expected:
            raise RuntimeError("Published Live CSV headers do not match the approved schema; manual review required")
        print("PASS: current Live CSV header matches approved contract")
    elif schema.exists():
        raise RuntimeError("Live schema exists, but matching Live CSV is missing")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hub-root", required=True, type=Path)
    parser.add_argument("--raw", required=True, action="append", type=Path,
                        help="Actual ZSD3TR009 TXT to test; may be repeated")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    target = args.hub_root / "processing" / "parser.py"
    if not target.is_file():
        raise SystemExit(f"FAILED: parser.py not found at {target}")
    try:
        original = target.read_text(encoding="utf-8-sig")
        candidate = patch(original)
        module = load_in_memory(candidate)
        expected = list(module.ZSD3TR009_STABLE_FIELDS)
        if len(expected) != 95 or len(set(expected)) != 95:
            raise RuntimeError("Approved ZSD3TR009 contract is invalid")
        for path in args.raw:
            if not path.is_file():
                raise RuntimeError(f"Raw SAP TXT not found: {path}")
            result = module.parse_file(path, "zsd3tr009")
            if result.headers != expected or result.no_data or not result.rows:
                raise RuntimeError(f"Parser output does not match expected populated dataset: {path}")
            print(f"PASS: {path.name}: {len(result.rows)} rows, {len(result.headers)} columns, "
                  f"{result.ignored_total_lines} excluded currency totals")
        check_live_contract(args.hub_root, expected)
    except Exception as e:
        raise SystemExit(f"FAILED (no files modified): {e}") from None
    print("PASS: source anchors, code syntax, raw alignment, and Live schema contract")
    if args.check:
        print("CHECK ONLY: no files were modified")
        return
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_dir = args.hub_root / "runtime" / "kpi_layout_fix_backups" / ("zsd_semantic_v14_"+timestamp)
    backup_dir.mkdir(parents=True, exist_ok=False)
    backup = backup_dir / "parser.py"
    shutil.copy2(target, backup)
    staged = target.with_name(".parser.py.zsd_v14.tmp")
    try:
        staged.write_text(candidate, encoding="utf-8", newline="\n")
        os.replace(staged, target)
    finally:
        staged.unlink(missing_ok=True)
    print(f"INSTALLED: {target}")
    print(f"BACKUP: {backup}")
    print("No config, app.py, Live, History, Raw or Power BI files were changed")


if __name__ == "__main__":
    main()
