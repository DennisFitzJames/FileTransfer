# ZSD3TR009 v1.4 test record

Validated with the reconstructed Data Hub parser based on v0.6 + hotfix v0.6.1 + parser fixes v1.1, v1.2 and v1.3. The installed Windows parser and W: Live schema must still pass the installer `--check` before use.

| Raw SAP sample | Parsed records | Output business fields | Excluded currency totals |
|---|---:|---:|---:|
| 21 Oct working ZSD3TR009 export | 182 | 95 | 5 |
| 10 Nov earlier export | 226 | 95 | 4 |
| 10 Nov second export | 236 | 95 | 4 |
| 10 Nov latest 15:03 export | 119 | 95 | 4 |

- All samples produce the **same ordered 95 output column identifiers**; `Date` is published as `created_on`, preserving the historic contract.
- Among 93 deliveries common to the 236-row and 119-row exports, all 93 matched across 18 important fields: shipping point, date, delivery/item, customer, customer name, material, six ship-to/sold-to address lines, second telephone, second city/postcode, delivery priority, time and building number. These are a regression check on column alignment, not a substitute for business-signoff.
- **17/17** existing Data Hub job raw samples produced **identical rows, columns and no-data flags** before versus after this patch, including MB51, ZMM4TR093, ZMM4TR012, LINEUP and FOOT jobs.
- Deliberately populated blank SAP spacer: **rejected**, with position information.
- Deliberately renamed business heading: **rejected** as an unapproved contract change.
- Installer `--check`/`--apply` passed against a simulated matching Live CSV + JSON, with automatic source backup.
- Installer refused to modify code against a simulated incompatible Live schema, identifying the differing field.

## Remaining environmental checks

These tests do not prove the deployed W: Live schema has the expected 95 identifiers; the installer checks that explicitly on your PC. The TXT export being provided may not be identical to the run that generated the reported strict-schema error. MB51 is a separate pending schema mismatch and is not modified by this package.
