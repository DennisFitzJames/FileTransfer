# FOOT — Data Hub to Power BI migration (v1)

Scope: Replace the **Advanced Editor** content of the three existing Power BI queries only. **Do not** delete/recreate the queries; that risks relationships/measures. Keep the Excel workbook and its SharePoint queries for `FactIssueLog` and `DimWorkCentre` unchanged.

## The source files

- `FactOrders.pq`: `W:\Departments\SAPTemplatesAndTools\Shared SAP Exports\Live\coois_production_foot\coois_production_foot_latest.csv`
- `FactConfirmations.pq`: `...\Live\coois_confirmations_foot\coois_confirmations_foot_latest.csv`
- `Fact_Capacity.pq`: `...\Live\coois_capacities_foot\coois_capacities_foot_latest.csv`

For enterprise refresh prefer a UNC path approved by IT, such as `\\SERVER\Share\...`, instead of a mapped W: drive. A Power BI service scheduled refresh of on-premises files requires an on-premises gateway with access and permissions to the same path. The current scripts use W: for Desktop tests.

## Prerequisites

1. Back up the current .pbix file.
2. On the Data Hub, enable the three FOOT reports, manually run them once, verify successful raw-to-CSV publication and check W: from the PC running Power BI Desktop. Leave the current Excel import path intact during this test.
3. In Power BI Desktop -> Transform data, check the current data types of `Order`, `Confirmation`, `Operation`, quantity/activity fields and their model relationships **before** changing any query.
4. Test one replacement at a time: keep the existing query name, open Advanced Editor, replace the code with the corresponding `.pq` file, click Done, inspect preview and column types, then Close & Apply. Compare row counts, dates, measures, relationships and visuals against the current workbook-backed model.
5. Refresh a second time after another Data Hub export and confirm data changes without clicking the old Excel SAP-export button.

## Important assumptions

- The provided queries assume Power BI currently uses numeric whole-number Order and Confirmation keys, as commonly imported from Excel. All sample FOOT Orders were 12-digit numeric identifiers; this is not guaranteed for every future SAP system. If your model's Order/Confirmation keys were **text**, remove the `AsOrder` conversion in the relevant query and explicitly use `type text` for all related keys across tables. Ensure joins remain consistent. If leading zeroes matter, use text keys everywhere.
- `Operation` remains text to preserve SAP's `0001` style codes. If the old model uses a numeric operation field and relies on it for relationships, align both queries before applying.
- ISO date strings are converted explicitly to date values, not left as text. Selected measures are converted to numbers.
- The Capacity query handles `24:00:00` finish times by carrying them to the following day at 00:00:00. This occurred in eight rows of the supplied sample.
- The Data Hub exports have extra columns not present in the previous Excel sheets. This migration deliberately selects exactly the old 13, 16 and 14 columns respectively; it does not delete any column in the Data Hub output.
- Samples from the earlier Raw.zip contained 2,055 Production, 6,313 Confirmations and 5,095 Capacities records. These are not promises of today's live counts.

## Keep the SharePoint Excel workbook

Keep `FactIssueLog` and `DimWorkCentre` connected to the existing workbook; do not remove its SharePoint data source. The FOOT Power BI file will then have mixed SharePoint and on-premises file sources. You can continue manually maintaining/saving the workbook for those two tables, but you should stop relying on the Excel SAP-export button for the three COOIS tables once the migration has been validated.

## Acceptance checks

- FactOrders: all scheduled/actual date fields have type Date and correct non-null counts; quantities numeric; Order keys intact.
- FactConfirmations: dates Date, times Time, activity/yield numeric; Order+Confirmation and Operation values correctly match the old model.
- Fact Capacity: hours numeric; category text (including `002`); start/finish date/time correct, including end-of-day rollover.
- Verify row counts, cardinality and all DAX measures and relationships.
- Confirm `FactIssueLog`, `DimWorkCentre` and all existing SharePoint refreshes still succeed.
- Power BI Desktop refresh succeeds; separately verify gateway setup before attempting automated cloud refresh.

## Rollback

Restore the previous .pbix backup, or restore the previous Advanced Editor code in each query. No Data Hub exporter changes are required for rollback.
