# Shared SAP Data Hub — ZMM4TR093 strict-schema diagnostic

This read-only diagnostic compares the **installed** parser's output for the failed TXT with the existing **published** schema and CSV on W:. It reproduces the column-name and column-order comparison performed in `app.py`. It does **not** change any code, data, configuration, or schemas.

The provided November 10 TXT, CSV and JSON have already been independently checked: all 767 rows parse to 23 columns, and the JSON source fingerprint matches the TXT. The submitted JSON therefore describes a parsed version of the supplied TXT, **not necessarily the actual prior Live schema that the controller's guard compared against**.

## Run on the Data Hub PC

1. Extract this ZIP to a folder, e.g. `C:\KPI_TR093_Diagnostic`.
2. Save the failed raw TXT in `C:\KPI_Test\zmm4tr093.txt`. Preserve the original file.
3. Open Command Prompt and run:

```bat
cd /d C:\KPI_TR093_Diagnostic
py -3 diagnose_tr093_schema.py --hub-root "C:\Users\EB013665\DataHub\DataHub-main" --raw "C:\KPI_Test\zmm4tr093.txt"
```

If you have also saved a staged schema file locally, add the optional flag:

```bat
--candidate-schema "C:\KPI_Test\zmm4tr093_schema.json"
```

**Note:** The raw file must be the exact TXT from the failed run. You can run this while the Data Hub is stopped to avoid a race with live publishing. The script imports the installed `processing\parser.py` and reads the `storage.publish_root` from the actual local `config.json`.

## Send back

Copy the console output, particularly the `STRICT LIVE SCHEMA CHECK` section and `CONCLUSION`. If the current Live schema matches the parsed file, we will investigate the worker/process or another raw export instead of modifying the schemas. If it differs, we will fix the exact names or order with a narrow backward-compatible adapter.

**Do not set `processing.strict_schema` to false, delete the existing Live schema, or copy a staged schema over it.** Those changes can hide a real data-column misalignment.
