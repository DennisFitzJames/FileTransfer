"""Read-only ZMM4TR093 schema mismatch diagnosis for Shared SAP Data Hub.

Requires Python 3.10+ and the installed Data Hub parser. No writes to source files.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

JOB = 'zmm4tr093'


def load_json(path: Path, label: str):
    if not path.is_file():
        print(f'{label}: MISSING  ({path})')
        return None
    try:
        with path.open(encoding='utf-8-sig') as f:
            return json.load(f)
    except (OSError, ValueError) as exc:
        raise RuntimeError(f'Unable to read {label} at {path}: {exc}') from exc


def names(meta):
    if not meta:
        return []
    cols = meta.get('columns', [])
    return [c['name'] for c in cols]


def compare(label: str, old: list[str], new: list[str]):
    print(f'\n--- {label} ---')
    print('Previously published columns:', len(old))
    print('Current parsed columns:     ', len(new))
    if not old:
        print('NO PRIOR SCHEMA AVAILABLE: cannot approve a change without review')
        return None
    if old == new:
        print('MATCH: column names and order are IDENTICAL')
        return True
    print('MISMATCH: exact differences by position (1-based):')
    for idx in range(max(len(old), len(new))):
        a = old[idx] if idx < len(old) else '<MISSING>'
        b = new[idx] if idx < len(new) else '<MISSING>'
        if a != b:
            print(f'  {idx + 1:>2}: Live={a!r}  Parsed={b!r}')
    missing = [n for n in old if n not in new]
    added = [n for n in new if n not in old]
    if missing:
        print('Only in Live:', missing)
    if added:
        print('Only in Parsed:', added)
    return False


def first_csv_header(path: Path, label: str):
    if not path.is_file():
        print(f'{label}: MISSING ({path})')
        return []
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        fields = next(csv.reader(f), [])
    print(f'{label}: {len(fields)} columns')
    return fields


def load_parser(path: Path):
    if not path.is_file():
        raise RuntimeError(f'Installed parser not found: {path}')
    spec = importlib.util.spec_from_file_location('datahub_tr093_parser_diagnostic', path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Could not load parser: {path}')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--hub-root', type=Path, required=True,
                    help='Folder containing existing Data Hub app.py, config.json and processing/parser.py')
    ap.add_argument('--raw', type=Path, required=True,
                    help='The exact TXT exported during the failure (not an older successful Raw/latest file)')
    ap.add_argument('--candidate-schema', type=Path, default=None,
                    help='Optional staged zmm4tr093_schema.json you would like to cross-check')
    a = ap.parse_args()
    cfg = load_json(a.hub_root / 'config.json', 'Installed config')
    if not cfg:
        raise RuntimeError('Data Hub config.json is required')
    root = cfg.get('storage', {}).get('publish_root')
    if not root:
        raise RuntimeError('config.json storage.publish_root is missing')
    live_dir = Path(root) / 'Live' / JOB
    live_meta = live_dir / f'{JOB}_schema.json'
    live_csv = live_dir / f'{JOB}_latest.csv'
    print('Data Hub folder:       ', a.hub_root)
    print('Configured publish root:', root)
    print('Live schema path:      ', live_meta)
    print('Raw file:              ', a.raw)
    print('Raw exists:            ', a.raw.is_file())
    if not a.raw.is_file():
        raise RuntimeError('Cannot inspect missing raw file')
    raw_bytes = a.raw.read_bytes()
    raw_sha = hashlib.sha256(raw_bytes).hexdigest()
    print('Raw bytes / SHA-256:   ', len(raw_bytes), '/', raw_sha)

    old = load_json(live_meta, 'Actual LIVE schema')
    if old:
        print('Live schema row count: ', old.get('row_count', 'unknown'))
        print('Live source SHA-256:   ', old.get('source_sha256', 'unknown'))
        print('Live schema source == supplied raw:', old.get('source_sha256') == raw_sha)
    live_csv_names = first_csv_header(live_csv, 'Actual LIVE CSV')
    live_schema_names = names(old)
    if live_csv_names and live_schema_names:
        if live_csv_names == live_schema_names:
            print('Live CSV and Live schema headers AGREE')
        else:
            print('WARNING: Live CSV header and Live schema disagree; do not approve publication')
            compare('Live CSV header vs Live schema', live_schema_names, live_csv_names)

    mod = load_parser(a.hub_root / 'processing' / 'parser.py')
    parsed = mod.parse_file(a.raw, JOB)
    parsed_names = list(parsed.headers)
    print('\nInstalled parser produced:', parsed.row_count, 'records,', len(parsed_names), 'columns')
    result = compare('STRICT LIVE SCHEMA CHECK (this is the guard in app.py)',
                     live_schema_names, parsed_names)
    if a.candidate_schema:
        candidate = load_json(a.candidate_schema, 'Candidate staged schema')
        if candidate:
            print('\nCandidate source SHA matches TXT:', candidate.get('source_sha256') == raw_sha)
            compare('Candidate staged schema vs actual parse', names(candidate), parsed_names)

    print('\nCONCLUSION:')
    if result is True:
        print('The specified TXT, installed parser, and CURRENT Live schema match.')
        print('This file would not trigger the original name/order guard.')
        print('Check whether the failed run used a DIFFERENT raw TXT, parser process,')
        print('or publish root. Restart the controller only after safeguarding logs.')
    elif result is False:
        print('The exact changes above are what the strict-schema guard rejects.')
        print('Do not disable strict_schema or overwrite Live until these names')
        print('are mapped back to the existing Power BI contract and verified.')
    else:
        print('Live schema missing; investigate the configured location and job status.')
    print('\nRead-only diagnosis complete. No Live, History, Raw, config or code files changed.')


if __name__ == '__main__':
    try:
        main()
    except Exception as err:
        print(f'DIAGNOSTIC FAILED: {err}', file=sys.stderr)
        sys.exit(1)
